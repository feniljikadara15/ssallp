<GlobalFunctions>
  <SqlQueryUnified
    id="getAllLoadingSlipItems"
    notificationDuration={4.5}
    query={include("./lib/getAllLoadingSlipItems.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getCustomers"
    isHidden={false}
    query={include("./lib/getCustomers.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getWarehouseKeepers"
    isHidden={false}
    notificationDuration={4.5}
    query={include("./lib/getWarehouseKeepers.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getProducts"
    cacheKeyTtl="3600"
    enableCaching={true}
    isHidden={false}
    isMultiplayerEdited={false}
    query={include("./lib/getProducts.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getWarehouses"
    isHidden={false}
    query={include("./lib/getWarehouses.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getTransporters"
    isHidden={false}
    query={include("./lib/getTransporters.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getOrders"
    isHidden={false}
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("./lib/getOrders.sql", "string")}
    queryDisabled="{{ !['orders', 'cashBills'].includes(retoolContext.currentPage) }}"
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getEnquiries"
    isHidden={false}
    query={include("./lib/getEnquiries.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getAddresses"
    isHidden={false}
    isMultiplayerEdited={false}
    query={include("./lib/getAddresses.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getSites"
    isHidden={false}
    query={include("./lib/getSites.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    runWhenPageLoads={true}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <State id="transporterSerachVariable" />
  <State id="warehouseSearchVariable" />
  <SqlQueryUnified
    id="getStateCodes"
    cacheKeyTtl="3600"
    enableCaching={true}
    query={include("./lib/getStateCodes.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
</GlobalFunctions>
