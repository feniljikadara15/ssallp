<App>
  <Include src="./functions.rsx" />
  <Include src="./src/enquiries.rsx" />
  <CustomAppTheme
    id="$appTheme"
    _migrated={true}
    automatic={[
      "#fde68a",
      "#eecff3",
      "#a7f3d0",
      "#bfdbfe",
      "#c7d2fe",
      "#fecaca",
      "#fcd6bb",
    ]}
    borderRadius="16px"
    canvas="#ffffff"
    danger="#590004"
    defaultFont={{ size: "12px", fontWeight: "400" }}
    defaultFontId="adb05669"
    fontIds={["adb05669"]}
    fontMap={{
      adb05669: {
        name: "Roboto",
        source:
          "https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900",
        fontWeights: ["100", "300", "400", "500", "700", "900"],
      },
    }}
    h1Font={{ size: "36px", fontWeight: "700" }}
    h2Font={{ size: "28px", fontWeight: "700" }}
    h3Font={{ size: "24px", fontWeight: "500" }}
    h4Font={{ size: "18px", fontWeight: "500" }}
    h5Font={{ size: "16px", fontWeight: "500" }}
    h6Font={{ size: "14px", fontWeight: "500" }}
    highlight="#f9cb40"
    info="#33658a"
    labelEmphasizedFont={{ size: "12px", fontWeight: "500" }}
    labelFont={{ size: "12px", fontWeight: "400" }}
    primary="#f26222"
    secondary="#292f45"
    success="#306b34"
    surfacePrimary="#ffffff"
    surfacePrimaryBorder="rgba(0, 0, 0, 0.35)"
    surfaceSecondary="#ffffff"
    surfaceSecondaryBorder=""
    tertiary="rgba(242, 98, 34, 0.05)"
    textDark="#0d0d0d"
    textLight="#ffffff"
    warning="#cd6f00"
  />
  <Include src="./src/orders.rsx" />
  <Include src="./src/warehouses.rsx" />
  <Include src="./src/transporters.rsx" />
  <Include src="./src/cashBills.rsx" />
  <Include src="./src/products.rsx" />
  <Include src="./src/warehouseKeepers.rsx" />
  <Include src="./src/Customers.rsx" />
  <Include src="./src/transporterVehicleDetails.rsx" />
  <Include src="./src/Dashboard.rsx" />
  <Include src="./src/LoadingSlips.rsx" />
  <Include src="./sidebar.rsx" />
</App>
