SELECT COUNT(*) AS count
FROM loading_slip_items lsi
LEFT JOIN loading_slips ls
  ON lsi.loading_slip_id = ls.loading_slip_id
LEFT JOIN orders o
  ON ls.order_id = o.order_id
LEFT JOIN warehouses w
  ON ls.warehouse_id = w.warehouse_id
WHERE lsi.is_active = TRUE
  AND (
    NULLIF({{ searchLoadingSlips.value }}::text, '') IS NULL
    OR lsi.loading_slip_file_name ILIKE '%' || {{ searchLoadingSlips.value }}::text || '%'
  )
  AND (
    NULLIF({{ loadingslipBrandFilter.value }}::text, '') IS NULL
    OR LOWER(lsi.brand) = LOWER({{ loadingslipBrandFilter.value }}::text)
  )
  AND (
    NULLIF({{ loadingslipwarehouseFilter.value }}::text, '') IS NULL
    OR LOWER(w.name) = LOWER({{ loadingslipwarehouseFilter.value }}::text)
    OR ls.warehouse_id::text = {{ loadingslipwarehouseFilter.value }}::text
  )
  AND (
    NULLIF({{ loadingslipDaterangeFilter.value?.start || '' }}::text, '') IS NULL
    OR o.order_date >= NULLIF({{ loadingslipDaterangeFilter.value?.start || '' }}::text, '')::date
  )
  AND (
    NULLIF({{ loadingslipDaterangeFilter.value?.end || '' }}::text, '') IS NULL
    OR o.order_date < (NULLIF({{ loadingslipDaterangeFilter.value?.end || '' }}::text, '')::date + INTERVAL '1 day')
  )