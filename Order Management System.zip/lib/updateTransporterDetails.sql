UPDATE transporters
SET name = {{ transporterNameInput.value }},
    phone_number = {{ transporterPhoneInput.value }},
    additional_mobile_number = {{ transporterAdditionalPhoneInput.value }}
WHERE
transporter_id = {{ selectedTransporterId.value }}