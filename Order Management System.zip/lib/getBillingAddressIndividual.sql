SELECT * FROM addresses WHERE customer_id = {{ isNaN(Number(customerNameInput.value)) 
    ? 0 
    : (
        getCustomers.data.customer_id.includes(customerNameInput.value) 
          ? customerNameInput.value 
          : 0
      )  }}  AND is_active = TRUE AND type = 'billing'