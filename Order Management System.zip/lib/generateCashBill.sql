UPDATE orders
SET total_amount = {{ getTotalAmount.data }},
    payment_type = 'cash',
    updated_at = CURRENT_TIMESTAMP,
    order_status = 2
WHERE order_id = {{ selectedOrderId.value }}