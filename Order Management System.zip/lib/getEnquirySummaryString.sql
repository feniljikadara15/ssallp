SELECT 
    STRING_AGG(
        CONCAT(
            p.category, ' - ', 
            p.brand, ' - ', 
            p.grade, ' for ', 
            ei.quantity, ' ', 
            p.unit
        ), ' ; '
    ) AS output_string
FROM 
    enquiry_items ei
JOIN 
    products p ON ei.product_id = p.product_id
WHERE 
    ei.enquiry_id = {{ selectedEnquiryId.value }}
    AND ei.quantity IS NOT NULL;
