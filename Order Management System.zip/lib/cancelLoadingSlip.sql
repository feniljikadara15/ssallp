UPDATE loading_slip_items SET status = 'Cancelled'
WHERE loading_slip_item_id = {{ loadingSlipItemsTable.selectedSourceRow.loading_slip_item_id }} 
RETURNING loading_slip_item_id;