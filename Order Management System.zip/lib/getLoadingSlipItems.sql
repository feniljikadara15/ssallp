SELECT 
    lsi.*, 
    COALESCE(wk.name, '') AS warehouse_keeper_name, 
    COALESCE(wk.phone, '') AS warehouse_keeper_phone
FROM loading_slip_items lsi
LEFT JOIN warehouse_brands wb 
    ON LOWER(lsi.brand) = LOWER(wb.brand)
LEFT JOIN warehouse_keepers wk 
    ON wb.warehouse_keeper_id = wk.warehouse_keeper_id
WHERE lsi.loading_slip_id = {{ getLoadingSlips.data.loading_slip_id[0] }}  
AND lsi.is_active = TRUE 
  AND wb.warehouse_id = (SELECT warehouse_id FROM orders WHERE order_id = {{ selectedOrderId.value }}) ;