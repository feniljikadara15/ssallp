WITH cash_summary AS (
    SELECT
        order_id,
        SUM(amount) AS total_collected
    FROM cash_collected
    WHERE is_active = TRUE
    GROUP BY order_id
),
loading_slip_agg AS (
    SELECT
        o.order_id,
        STRING_AGG(
            DISTINCT lsi.loading_slip_number::text,
            ', '
            ORDER BY lsi.loading_slip_number::text
        ) AS loading_slip_numbers
    FROM orders o
    JOIN loading_slip_items lsi
        ON lsi.loading_slip_id = o.loading_slip_id
       AND lsi.is_active = TRUE
    GROUP BY o.order_id
),
base_rows AS (
    SELECT
        o.order_id,
        o.order_date,
        p.brand,
        p.grade,
        oi.quantity,
        oi.total_price,
        c.name AS party_name,
        s.site_name,
        t.name AS transporter_name,
        wk.name AS warehouse_keeper,
        o.sub_dealer,
        lsa.loading_slip_numbers,
        o.delivery_terms,
        ROW_NUMBER() OVER (PARTITION BY o.order_id ORDER BY p.brand) AS rn
    FROM orders o
    LEFT JOIN cash_summary cs
        ON cs.order_id = o.order_id
    JOIN order_items oi
        ON o.order_id = oi.order_id
    JOIN products p
        ON oi.product_id = p.product_id
    LEFT JOIN customers c
        ON o.customer_id = c.customer_id
    LEFT JOIN sites s
        ON o.site_id = s.site_id
    LEFT JOIN transporters t
        ON o.transporter_id = t.transporter_id
    LEFT JOIN warehouse_brands wb
        ON LOWER(wb.brand) = LOWER(p.brand)
       AND wb.warehouse_id = o.warehouse_id
       AND wb.is_active = TRUE
    LEFT JOIN warehouse_keepers wk
        ON wk.warehouse_keeper_id = wb.warehouse_keeper_id
    LEFT JOIN loading_slip_agg lsa
        ON lsa.order_id = o.order_id
    WHERE
        o.payment_type = 'cash'
        AND (
            cs.total_collected IS NULL
            OR cs.total_collected < o.total_amount
        )
        AND (
            (
              COALESCE(NULLIF({{ pendingCashBillsDateRange.value.start }}, ''), NULL) IS NULL 
              OR o.order_date::date >= COALESCE(NULLIF({{ pendingCashBillsDateRange.value.start }}, ''), NULL)::date
            )
            AND
            (
              COALESCE(NULLIF({{ pendingCashBillsDateRange.value.end }}, ''), NULL) IS NULL 
              OR o.order_date::date <= COALESCE(NULLIF({{ pendingCashBillsDateRange.value.end }}, ''), NULL)::date
            )
        )
)

SELECT
    CASE WHEN rn = 1 THEN order_id::text ELSE '' END AS "Order No",
    TO_CHAR(order_date::date, 'DD-MM-YYYY') AS "Order Date",
    brand        AS "Brand Name",
    grade        AS "Brand Grade",
    quantity     AS "Number of Bags",
    total_price  AS "Price",
    party_name   AS "Party Name",
    site_name    AS "Site Name",
    transporter_name AS "Assigned Transporter",
    warehouse_keeper AS "Warehouse Keeper",
    sub_dealer   AS "Sub Dealer",
    loading_slip_numbers AS "Loading Slip Number",
    delivery_terms AS "Delivery Terms"
FROM base_rows
ORDER BY order_id DESC, brand;