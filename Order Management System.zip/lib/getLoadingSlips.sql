SELECT ls.*, MAX(lsi.status) AS status
FROM loading_slips ls
LEFT JOIN loading_slip_items lsi ON lsi.loading_slip_id = ls.loading_slip_id AND lsi.is_active = TRUE
WHERE ls.order_id = {{  selectedOrderId.value }} AND ls.is_active = TRUE
  GROUP BY ls.loading_slip_id