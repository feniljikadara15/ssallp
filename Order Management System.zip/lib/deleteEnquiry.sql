UPDATE enquiries
SET enquiry_status = '5'
WHERE enquiry_id = {{ selectedEnquiryId.value }}