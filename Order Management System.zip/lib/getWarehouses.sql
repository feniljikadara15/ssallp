SELECT *
FROM warehouses
WHERE is_active = TRUE
  AND (
    {{ !warehouseSearchVariable.value }} 
    OR name ILIKE {{ '%' + warehouseSearchVariable.value + '%' }}
  )
ORDER BY warehouse_id ASC;
