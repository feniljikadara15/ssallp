UPDATE orders
SET otp = {{ `${Math.floor(100000 + Math.random() * 900000)}`
 }}
WHERE order_id = {{ selectedOrderId.value }}

RETURNING otp