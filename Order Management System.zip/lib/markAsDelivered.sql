UPDATE orders
SET order_status = 3
WHERE order_id = {{ selectedOrderId.value }}