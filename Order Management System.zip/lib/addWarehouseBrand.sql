INSERT INTO warehouse_brands (
    warehouse_brands_id, 
    warehouse_id, 
    warehouse_keeper_id, 
    brand, 
    created_at, 
    updated_at, 
    is_active
) 
VALUES 
(DEFAULT,  -- Auto-incrementing primary key
  {{ selectedWarehouseId.value }},       
  {{ selectWarehouseKeeper.value }},       
  {{selectWarehouseBrand.value}},
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP,
  TRUE
);