UPDATE warehouse_brands
SET 
    warehouse_keeper_id = {{ editWarehouseKeeper.value }},
    brand = {{ editWarehouseBrand.value }},
    updated_at = CURRENT_TIMESTAMP
WHERE warehouse_brands_id = {{ warehouseBrandsTable.selectedSourceRow.warehouse_brands_id }};