INSERT INTO products (
    product_id,
    product_name,
    category,
    description,
    brand,
    grade,
    unit,
    sku,
    hsn,
    gst_rate,
    mrp,
    is_active,
    created_at,
    updated_at,
    zb_item_id
)
VALUES (
    DEFAULT,
    {{ newProductName.value }},
    {{ newProductCategory.value }},
    {{ newProductDescription.value }},
    {{ newProductBrand.value }},
    {{ newProductGrade.value }},
    {{ newProductUnit.value }},
    {{ newProductSKU.value }},
    {{ newProductHSN.value }},
    {{ Number(newProductGST.value) }},
    {{ Number(newProductMRP.value) }},
    TRUE,
    NOW(),
    NOW(),
    {{ new_zb_item_id }}
)
RETURNING product_id;
