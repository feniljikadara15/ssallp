INSERT INTO cash_collected (
    order_id,
    collection_date,
    amount,
    payment_mode,
    receipt_number,
    created_at,
    updated_at,
    is_active
) VALUES 
(
    {{selectedCashBillId.value}}, -- Replace with the actual order_id
    {{collectionDateInput.value}}, -- Current timestamp for collection_date
    {{ amountCollectedInput.value }}, -- Replace with the amount collected
    'Cash', -- Replace with the actual payment mode ('Cash', 'Cheque', 'Online', etc.)
    {{ receiptNumberInput.value }}, -- Replace with the receipt number
    NOW(), -- Current timestamp for created_at
    NOW(), -- Current timestamp for updated_at
    TRUE -- Mark as active
);