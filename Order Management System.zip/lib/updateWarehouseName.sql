UPDATE warehouses
SET 
  name = {{ editWarehouseNameInput.value }},
  location = {{ editWarehouseLocationInput.value }},
  updated_at = NOW()
WHERE
warehouse_id = {{ editwarehouseID.value }};
