SELECT site_id, customer_id, address_id, site_name, site_person_name, site_person_contact, is_active
FROM sites
WHERE is_active = TRUE