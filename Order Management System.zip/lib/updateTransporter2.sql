UPDATE orders
SET transporter_id = {{ selectTransporter2.value }}
WHERE order_id = {{ selectedOrderId.value }}