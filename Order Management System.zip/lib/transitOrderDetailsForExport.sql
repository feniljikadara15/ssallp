SELECT
    CASE 
        WHEN ROW_NUMBER() OVER (PARTITION BY o.order_id ORDER BY p.brand) = 1 
        THEN o.order_id::text 
        ELSE '' 
    END AS "Order No",
    p.brand AS "Brand Name",
    p.grade AS "Brand Grade",
    oi.quantity AS "Number of Bags",
    o.total_amount AS "Total Price",
    c.name AS "Party Name",
    s.site_person_contact AS "Site Person Number",
    s.site_name AS "Site Name",
    a.line2 AS "Location Line 2",
    t.name AS "Assigned Transporter",

     (
        SELECT STRING_AGG(wk.name, ', ')
        FROM loading_slip_items lsi
        LEFT JOIN warehouse_brands wb 
            ON LOWER(lsi.brand) = LOWER(wb.brand)
           AND wb.warehouse_id = o.warehouse_id
        LEFT JOIN warehouse_keepers wk 
            ON wk.warehouse_keeper_id = wb.warehouse_keeper_id
        WHERE lsi.loading_slip_id = o.loading_slip_id
          AND lsi.is_active = TRUE
    ) AS "Warehouse Keepers",

    o.sub_dealer AS "Sub Dealer",

    (
        SELECT STRING_AGG(lsi.loading_slip_file_name, ', ')
        FROM loading_slip_items lsi
        WHERE lsi.loading_slip_id = o.loading_slip_id
          AND lsi.is_active = TRUE
    ) AS "Loading Slip Number",

    o.delivery_terms AS "Delivery Terms"
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
LEFT JOIN sites s ON o.site_id = s.site_id
LEFT JOIN customers c ON o.customer_id = c.customer_id
LEFT JOIN addresses a ON s.address_id = a.address_id
LEFT JOIN transporters t ON o.transporter_id = t.transporter_id
WHERE 
    o.order_status = '2'
    AND (
        (
          COALESCE(NULLIF({{ transitOrdersDateRange.value.start }}, ''), NULL) IS NULL 
          OR o.order_date::date >= COALESCE(NULLIF({{ transitOrdersDateRange.value.start }}, ''), NULL)::date
        )
        AND
        (
          COALESCE(NULLIF({{ transitOrdersDateRange.value.end }}, ''), NULL) IS NULL 
          OR o.order_date::date <= COALESCE(NULLIF({{ transitOrdersDateRange.value.end }}, ''), NULL)::date
        )
    )
ORDER BY 
    o.order_id DESC, 
    p.brand;
