SELECT enquiry_id, customer_id, enquiry_date, enquiry_status, type, billing_address_id,
       delivery_address_id, site_id, remarks, warehouse_id, transporter_id, delivery_date, is_active
FROM enquiries
WHERE is_active = TRUE
ORDER BY enquiry_date DESC