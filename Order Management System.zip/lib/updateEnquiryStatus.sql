UPDATE enquiries
SET enquiry_status = '1'
WHERE enquiry_id = {{ selectedEnquiryId.value }}