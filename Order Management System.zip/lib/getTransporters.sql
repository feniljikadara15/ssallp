SELECT *
FROM transporters
WHERE is_active = TRUE
  AND (
    {{ !transporterSerachVariable.value }} 
    OR name ILIKE {{ '%' + transporterSerachVariable.value + '%' }}
  )
ORDER BY transporter_id ASC;
