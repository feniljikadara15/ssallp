SELECT 
    tw.transporter_warehouse_id,
    w.warehouse_id,
    w.name AS warehouse_name,
    w.location AS warehouse_location,
    w.created_at,
    w.updated_at,
    w.is_active
FROM 
    transporter_warehouses tw
JOIN 
    warehouses w
ON 
    tw.warehouse_id = w.warehouse_id
WHERE 
    tw.transporter_id = {{selectedTransporterId.value}};
