WITH loading_slip_numbers AS (
    SELECT
        o.order_id,
        STRING_AGG(DISTINCT lsi.loading_slip_file_name, ', ') AS loading_slip_numbers
    FROM orders o
    JOIN loading_slips ls 
        ON o.loading_slip_id = ls.loading_slip_id
    JOIN loading_slip_items lsi 
        ON ls.loading_slip_id = lsi.loading_slip_id
       AND lsi.is_active = TRUE
    GROUP BY o.order_id
),
warehouse_keepers_agg AS (
    SELECT
        o.order_id,
        STRING_AGG(DISTINCT wk.name, ', ') AS warehouse_keepers
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN products p ON oi.product_id = p.product_id
    JOIN warehouse_brands wb
        ON LOWER(wb.brand) = LOWER(p.brand)
       AND wb.warehouse_id = o.warehouse_id
    JOIN warehouse_keepers wk
        ON wb.warehouse_keeper_id = wk.warehouse_keeper_id
    GROUP BY o.order_id
),
detail AS (
    SELECT
        c.order_id,

        CASE 
            WHEN ROW_NUMBER() OVER (
                PARTITION BY c.order_id 
                ORDER BY c.collection_date DESC, p.brand
            ) = 1 
            THEN (c.order_id::text || ' - ' || cu.name)
            ELSE '' 
        END AS "Order",

        c.collection_date::text AS "Collection Date",
        c.amount AS "Amount",
        c.payment_mode AS "Payment Mode",
        c.receipt_number AS "Receipt Number",

        p.brand AS "Brand Name",
        p.grade AS "Brand Grade",
        oi.quantity AS "Number of Bags",
        oi.total_price AS "Price",

        s.site_name AS "Site Name",
        t.name AS "Assigned Transporter",
        o.sub_dealer AS "Sub Dealer",
        o.delivery_terms AS "Delivery Terms",

        lsn.loading_slip_numbers AS "Loading Slip Number",
        wka.warehouse_keepers AS "Warehouse Keeper"

    FROM cash_collected c
    JOIN orders o 
        ON c.order_id = o.order_id
       AND o.payment_type = 'cash'

    JOIN customers cu 
        ON o.customer_id = cu.customer_id

    JOIN order_items oi 
        ON o.order_id = oi.order_id

    JOIN products p 
        ON oi.product_id = p.product_id

    LEFT JOIN sites s 
        ON o.site_id = s.site_id

    LEFT JOIN transporters t 
        ON o.transporter_id = t.transporter_id

    LEFT JOIN loading_slip_numbers lsn
        ON o.order_id = lsn.order_id

    LEFT JOIN warehouse_keepers_agg wka
        ON o.order_id = wka.order_id

    WHERE c.payment_mode = 'Cash'
),
totals AS (
    SELECT
        c.order_id,
        ''::text AS "Order",
        'Total'::text AS "Collection Date",
        SUM(c.amount)::numeric AS "Amount",
        ''::text AS "Payment Mode",
        ''::text AS "Receipt Number",
        ''::text AS "Brand Name",
        ''::text AS "Brand Grade",
        NULL::numeric AS "Number of Bags",
        NULL::numeric AS "Price",
        ''::text AS "Site Name",
        ''::text AS "Assigned Transporter",
        ''::text AS "Sub Dealer",
        ''::text AS "Delivery Terms",
        ''::text AS "Loading Slip Number",
        ''::text AS "Warehouse Keeper"
    FROM cash_collected c
    JOIN orders o 
        ON c.order_id = o.order_id
       AND o.payment_type = 'cash'
    WHERE c.payment_mode = 'Cash'
    GROUP BY c.order_id
)

SELECT *
FROM (
    SELECT * FROM detail
    UNION ALL
    SELECT * FROM totals
) combined
ORDER BY
    order_id DESC,
    ("Collection Date" = 'Total') ASC,
    "Collection Date" DESC NULLS LAST;
