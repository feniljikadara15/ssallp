INSERT INTO order_items (order_id, product_id, quantity, unit_price, remarks, created_at, updated_at, is_active)
SELECT 
    o.order_id, 
    ei.product_id, 
    ei.quantity, 
    ei.unit_price, 
    'No remarks', -- Example remark
    NOW(), 
    NOW(), 
    true
FROM enquiry_items ei
JOIN orders o ON o.enquiry_id = ei.enquiry_id
WHERE ei.enquiry_id = {{ selectedEnquiryId.value }};
