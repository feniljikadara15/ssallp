SELECT DISTINCT 
    tw.transporter_id, 
    t.name AS transporter_name, 
    t.phone_number AS transporter_phone
FROM transporter_warehouses tw
JOIN transporters t 
    ON tw.transporter_id = t.transporter_id
WHERE tw.warehouse_id = {{ selectWarehouse2.value || 0 }}
ORDER BY tw.transporter_id ASC;