UPDATE orders
SET delivery_terms = {{ selectDeliveryTerms.value}}
WHERE order_id = {{ selectedOrderId.value }}