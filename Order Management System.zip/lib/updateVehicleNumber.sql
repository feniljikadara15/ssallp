UPDATE orders
SET vehicle_id = {{ selectVehicleNumber.value }}
WHERE order_id = {{ selectedOrderId.value }}