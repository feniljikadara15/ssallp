UPDATE loading_slip_items SET status = 'Sent'
WHERE loading_slip_item_id = {{ row?.loading_slip_item_id ?? loadingSlipItemsTable.selectedSourceRow?.loading_slip_item_id }}
RETURNING loading_slip_item_id;