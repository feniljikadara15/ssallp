INSERT INTO transporters (transporter_id, name, phone_number, additional_mobile_number, created_at, updated_at, is_active)
VALUES (
  DEFAULT,
  {{ newTransporterNameInput.value }},
  {{ newTransporterPhoneInput.value }},
  {{ newTransporterAdditionalPhoneInput.value }},
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP,
  TRUE
)
RETURNING transporter_id