WITH months AS (
  SELECT 
    DATE_TRUNC('month', created_at) AS month_start,
    COUNT(*) AS enquiry_count
  FROM enquiries
  GROUP BY DATE_TRUNC('month', created_at)
),
latest_month AS (
  SELECT MAX(month_start) AS max_month
  FROM months
),
current_last AS (
  SELECT
    m1.enquiry_count AS current_month_enquiries,
    COALESCE(m2.enquiry_count, 0) AS last_month_enquiries
  FROM latest_month lm
  JOIN months m1 
    ON m1.month_start = lm.max_month
  LEFT JOIN months m2 
    ON m2.month_start = lm.max_month - INTERVAL '1 month'
),
totals AS (
  SELECT COUNT(*) AS total_enquiries
  FROM enquiries
)
SELECT
  t.total_enquiries,
  CASE 
    WHEN c.last_month_enquiries = 0 THEN NULL
    ELSE ROUND(((c.current_month_enquiries - c.last_month_enquiries)::decimal
                / c.last_month_enquiries) * 100, 2)
  END AS this_month_percentage_increase
FROM totals t
CROSS JOIN current_last c;
