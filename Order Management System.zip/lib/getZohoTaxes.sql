SELECT * FROM zoho_taxes
WHERE is_active = TRUE;