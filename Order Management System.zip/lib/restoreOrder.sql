UPDATE orders
SET order_status = 1
WHERE order_id = {{ selectedOrderId.value }}