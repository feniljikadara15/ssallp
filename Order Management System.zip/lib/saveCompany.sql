INSERT INTO warehouse_companies
(
  warehouse_id,
  company_name,
  address_line1,
  address_line2,
  city,
  state,
  pincode,
  country,
  is_active,
  created_at
)
VALUES 
(
  {{ selectwarehouseid.value }},
  {{ companyNameInput.value }},
  {{ companyAddressLine1.value }},
  {{ companyAddressLine2.value }},
  {{ companyCIty.value }},
  {{ companyState.value }},
  {{ companyPincode.value }},
  {{ companyCountry.value }},
  true,
  NOW()
);
