SELECT 
    tw.transporter_warehouse_id,
    t.transporter_id,
    t.name AS transporter_name,
    v.vehicle_number,
    t.phone_number,
    t.additional_mobile_number,
    t.created_at,
    t.updated_at,
    t.is_active
FROM 
    transporter_warehouses tw
JOIN 
    transporters t
ON 
    tw.transporter_id = t.transporter_id
JOIN 
    vehicles v
ON 
    t.transporter_id = v.transporter_id
WHERE 
    tw.warehouse_id = {{ selectedWarehouseId.value }};