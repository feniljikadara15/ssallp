WITH months AS (
  SELECT 
    DATE_TRUNC('month', created_at) AS month_start,
    COUNT(*) AS customer_count
  FROM customers
  GROUP BY DATE_TRUNC('month', created_at)
),
latest_month AS (
  SELECT MAX(month_start) AS max_month
  FROM months
),
current_last AS (
  SELECT
    m1.customer_count AS current_month_customers,
    COALESCE(m2.customer_count, 0) AS last_month_customers
  FROM latest_month lm
  JOIN months m1 
    ON m1.month_start = lm.max_month
  LEFT JOIN months m2 
    ON m2.month_start = lm.max_month - INTERVAL '1 month'
),
totals AS (
  SELECT COUNT(*) AS total_customers
  FROM customers
)
SELECT
  t.total_customers,
  CASE 
    WHEN c.last_month_customers = 0 THEN NULL
    ELSE ROUND(((c.current_month_customers - c.last_month_customers)::decimal
                / c.last_month_customers) * 100, 2)
  END AS this_month_percentage_increase
FROM totals t
CROSS JOIN current_last c;
