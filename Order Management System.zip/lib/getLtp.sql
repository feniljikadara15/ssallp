SELECT oi.*, o.order_date 
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders o ON oi.order_id = o.order_id
JOIN customers c ON o.customer_id = c.customer_id
WHERE p.brand = {{ selectBrand.value }}
AND p.grade = {{ selectGrade.value }}
AND p.category = {{ selectCategory.value }}
AND c.phone = {{ customerPhoneInput.value }}
ORDER BY o.order_date DESC LIMIT 1