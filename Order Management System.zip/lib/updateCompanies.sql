UPDATE warehouse_companies
SET
  company_name   = {{ editCompanyNameInput.value }},
  address_line1  = {{ editCompanyAddressLine1.value }},
  address_line2  = {{ editcompanyAddressLine2.value }},
  city           = {{ editCompanyCity.value }},
  state          = {{ editCompanyState.value }},
  pincode        = {{ editCompanyPincode.value }},
  country        = {{ editCompanyCountry.value }},
  updated_at     = NOW()
WHERE warehouse_company_id = {{ getWarehouseCompaniesDetails.selectedSourceRow.warehouse_company_id }};
