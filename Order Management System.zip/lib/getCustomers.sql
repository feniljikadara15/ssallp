SELECT customer_id, name, email, phone, additional_phone_1, additional_phone_2, gstin, pan,
       tcs_status, customer_type, zb_customer_id, remarks, is_active
FROM customers
WHERE is_active = true