UPDATE warehouse_keepers
SET 
  name = {{ editWarehouseKeeperNameInput.value }},
  phone = {{ editWarehouseKeeperPhoneInput.value }},
  warehouse_id = {{ editSelectKeeperWarehouse.value }},
  updated_at = NOW()
WHERE
warehouse_keeper_id = {{ table1.selectedSourceRow.warehouse_keeper_id }};
