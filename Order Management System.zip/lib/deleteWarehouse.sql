UPDATE warehouses
SET is_active = FALSE
WHERE warehouse_id = {{ selectedWarehouseId.value }}