SELECT invoice_id, order_id, zb_invoice_id, zb_invoice_number, zb_invoice_url
FROM invoices
WHERE is_active = TRUE