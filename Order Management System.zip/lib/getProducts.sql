SELECT product_id, product_name, category, brand, grade, unit, zb_item_id, is_active
FROM products
WHERE is_active = TRUE