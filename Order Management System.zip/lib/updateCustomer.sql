UPDATE customers
  SET
name = {{ customerName.value }},
phone = {{ customerPhoneNumber.value }},
additional_phone_1 = {{ customerAdditionalPhone1.value }},
additional_phone_2 = {{ customerAdditionalPhone2.value }},
gstin = {{ customerGST.value }},
pan = {{ customerPAN.value }},
customer_type = {{ customerType.value }},
remarks = {{ customerRemarks.value }},
tcs_status = {{ customerTCS.value }},
is_active = {{ customerActive.value }}
WHERE
customer_id = {{ customersTable.selectedSourceRow.customer_id }}