SELECT 
    STRING_AGG(
        CONCAT(
            p.category, ' - ', 
            p.brand, ' - ', 
            p.grade, ' for ', 
            oi.quantity, ' ', 
            p.unit
        ), ' ; '
    ) AS output_string
FROM 
    order_items oi
JOIN 
    products p ON oi.product_id = p.product_id
WHERE 
    oi.order_id = {{ selectedOrderId.value }}
    AND oi.quantity IS NOT NULL
    AND LOWER(p.brand) = LOWER({{ loadingSlipItemsTable.selectedSourceRow.brand }})
    