UPDATE invoices
SET pdf_invoice_url = {{ storeInvoice.data.url }}
WHERE invoice_id = {{ getInvoices.data.invoice_id[getInvoices.data.order_id.indexOf(selectedOrderId.value)] }}
RETURNING invoice_id;