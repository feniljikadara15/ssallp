SELECT * FROM enquiry_items WHERE enquiry_id = {{ selectedEnquiryId.value }}
