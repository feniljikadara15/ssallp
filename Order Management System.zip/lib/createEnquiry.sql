INSERT INTO enquiries (
    customer_id, 
    enquiry_date, 
    enquiry_status, 
    type, 
    billing_address_id, 
    delivery_address_id, 
    site_id, 
    transporter_id, 
    warehouse_id, 
    remarks, 
    is_active
) 
VALUES (
    ?, -- Customer ID
    ?, -- Enquiry Date
    ?, -- Enquiry Status
    ?, -- Type
    ?, -- Billing Address ID
    ?, -- Delivery Address ID
    ?, -- Site ID
    ?, -- Transporter ID
    ?, -- Warehouse ID
    ?, -- Remarks
    ?  -- Is Active
);