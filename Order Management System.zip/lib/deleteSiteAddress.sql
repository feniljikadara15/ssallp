UPDATE
  sites
SET
  is_active = false -- or 'Y' / 1 / 'deleted'   -- optional timestamp
WHERE
  site_id = {{ customerSitesTable.selectedSourceRow.site_id }}