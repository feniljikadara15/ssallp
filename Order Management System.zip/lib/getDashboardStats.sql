-- Combined dashboard stats (replaces getTotalOrders, getTotalEnquiries, getTotalCustomers)
-- Each block is the original query's logic, unchanged.
WITH
o_months AS (
  SELECT DATE_TRUNC('month', created_at) AS month_start, COUNT(*) AS cnt
  FROM orders GROUP BY DATE_TRUNC('month', created_at)
),
o_stats AS (
  SELECT
    (SELECT COUNT(*) FROM orders) AS total_orders,
    CASE WHEN COALESCE(m2.cnt, 0) = 0 THEN NULL
         ELSE ROUND(((m1.cnt - COALESCE(m2.cnt, 0))::decimal / COALESCE(m2.cnt, 0)) * 100, 2)
    END AS orders_pct
  FROM (SELECT MAX(month_start) AS max_month FROM o_months) lm
  JOIN o_months m1 ON m1.month_start = lm.max_month
  LEFT JOIN o_months m2 ON m2.month_start = lm.max_month - INTERVAL '1 month'
),
e_months AS (
  SELECT DATE_TRUNC('month', created_at) AS month_start, COUNT(*) AS cnt
  FROM enquiries GROUP BY DATE_TRUNC('month', created_at)
),
e_stats AS (
  SELECT
    (SELECT COUNT(*) FROM enquiries) AS total_enquiries,
    CASE WHEN COALESCE(m2.cnt, 0) = 0 THEN NULL
         ELSE ROUND(((m1.cnt - COALESCE(m2.cnt, 0))::decimal / COALESCE(m2.cnt, 0)) * 100, 2)
    END AS enquiries_pct
  FROM (SELECT MAX(month_start) AS max_month FROM e_months) lm
  JOIN e_months m1 ON m1.month_start = lm.max_month
  LEFT JOIN e_months m2 ON m2.month_start = lm.max_month - INTERVAL '1 month'
),
c_months AS (
  SELECT DATE_TRUNC('month', created_at) AS month_start, COUNT(*) AS cnt
  FROM customers GROUP BY DATE_TRUNC('month', created_at)
),
c_stats AS (
  SELECT
    (SELECT COUNT(*) FROM customers) AS total_customers,
    CASE WHEN COALESCE(m2.cnt, 0) = 0 THEN NULL
         ELSE ROUND(((m1.cnt - COALESCE(m2.cnt, 0))::decimal / COALESCE(m2.cnt, 0)) * 100, 2)
    END AS customers_pct
  FROM (SELECT MAX(month_start) AS max_month FROM c_months) lm
  JOIN c_months m1 ON m1.month_start = lm.max_month
  LEFT JOIN c_months m2 ON m2.month_start = lm.max_month - INTERVAL '1 month'
)
SELECT o.total_orders, o.orders_pct, e.total_enquiries, e.enquiries_pct, c.total_customers, c.customers_pct
FROM o_stats o CROSS JOIN e_stats e CROSS JOIN c_stats c;
