UPDATE enquiries
SET enquiry_status = '0'
WHERE enquiry_id = {{ selectedEnquiryId.value }}