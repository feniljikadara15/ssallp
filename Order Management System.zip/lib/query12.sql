SELECT 
  v.vehicle_id,
  v.vehicle_number,
  v.vehicle_type,
  v.capacity,
  v.is_active AS vehicle_active,
  v.created_at AS vehicle_created_at,
  t.transporter_id,
  t.name AS transporter_name,
  t.phone_number AS transporter_phone,
  t.additional_mobile_number,
  t.is_active AS transporter_active,
  t.created_at AS transporter_created_at
FROM vehicles v
JOIN transporters t 
  ON v.transporter_id = t.transporter_id
WHERE 
  {{ transportersSearchinput.value }} = '' 
  OR v.vehicle_number ILIKE '%' || {{ transportersSearchinput.value }} || '%'
  OR t.name ILIKE '%' || {{ transportersSearchinput.value }} || '%'
ORDER BY t.name, v.vehicle_number;
