INSERT INTO warehouses (warehouse_id, name, location, created_at, updated_at, is_active)
VALUES (
  DEFAULT,
  {{ newWarehouseNameInput.value }},
  {{ newWarehouseLocationInput.value }},
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP,
  TRUE
)
RETURNING warehouse_id