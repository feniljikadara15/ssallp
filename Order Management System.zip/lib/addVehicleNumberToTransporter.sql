INSERT INTO vehicles (vehicle_number, transporter_id, created_at, updated_at, is_active)
VALUES (UPPER({{ storeVehicleNumber.value?.toString().toUpperCase().replace(/[^A-Z0-9]/g, '').trim() }}), {{ selectTransporter2.value }}, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, TRUE)
RETURNING vehicle_id