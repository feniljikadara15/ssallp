UPDATE sites
SET 
    site_name = {{ customerSiteName.value }},
    site_person_contact = {{ customerSitePersonContact.value }},
    site_person_name = {{ customerSItePersonName.value }}
WHERE site_id = {{ customerSitesTable.selectedSourceRow.site_id }};
