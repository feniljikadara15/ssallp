INSERT INTO addresses (
    state,
  city,
    pincode,
    line1,
    line2,
    maps_link,
    type,
  customer_id,
    created_at,
    updated_at,
    is_active
)
VALUES (
    {{ addSiteState.value }},
    {{ addSiteCity.value }},
    {{ addSItePincode.value }},
    {{ addSiteAddressLane1.value }},
    {{ addSiteAddressLane2.value }},
    {{ addSiteMapLink.value }},
    'shipping',
    {{ customersTable.selectedSourceRow.customer_id }},
    NOW(),
    NOW(),
    TRUE
)
RETURNING address_id;
