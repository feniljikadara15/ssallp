SELECT 
    s.site_id,
  s.is_active,
    s.site_name,
    s.site_person_contact,
    s.site_person_name,
    a.city,
    a.maps_link,
    a.state,
    a.pincode,
    a.line1,
    a.line2
FROM sites s
JOIN addresses a 
    ON s.address_id = a.address_id
WHERE s.customer_id = {{ customersTable.selectedSourceRow.customer_id }}
  AND s.is_active = true;     -- Filter only active records
