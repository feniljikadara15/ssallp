UPDATE orders
SET warehouse_id = {{ selectWarehouse2.value }}
WHERE order_id = {{ selectedOrderId.value }}