SELECT order_id, order_number, enquiry_id, order_date, payment_type, order_status, total_amount,
       billing_address_id, shipping_address_id, site_id, otp, invoice_id, transporter_id,
       customer_id, warehouse_id, po_number, vehicle_id, sub_dealer, loading_slip_id,
       delivery_terms, is_active
FROM orders
WHERE is_active = TRUE
ORDER BY order_date DESC