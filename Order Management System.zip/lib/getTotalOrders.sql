WITH months AS (
  SELECT 
    DATE_TRUNC('month', created_at) AS month_start,
    COUNT(*) AS order_count
  FROM orders
  GROUP BY DATE_TRUNC('month', created_at)
),
latest_month AS (
  SELECT MAX(month_start) AS max_month
  FROM months
),
current_last AS (
  SELECT
    m1.order_count AS current_month_orders,
    COALESCE(m2.order_count, 0) AS last_month_orders
  FROM latest_month lm
  JOIN months m1 
    ON m1.month_start = lm.max_month
  LEFT JOIN months m2 
    ON m2.month_start = lm.max_month - INTERVAL '1 month'
),
totals AS (
  SELECT COUNT(*) AS total_orders
  FROM orders
)
SELECT
  t.total_orders,
  CASE 
    WHEN c.last_month_orders = 0 THEN NULL
    ELSE ROUND(((c.current_month_orders - c.last_month_orders)::decimal
                / c.last_month_orders) * 100, 2)
  END AS this_month_percentage_increase
FROM totals t
CROSS JOIN current_last c;
