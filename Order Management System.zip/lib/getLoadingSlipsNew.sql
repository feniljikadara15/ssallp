
SELECT
lsi.*,
ls.order_id,
ls.transporter_id,
ls.warehouse_id,
o.*,
(o.order_date AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') AS order_date_ist,
w.name AS warehouse_name,
COALESCE(wk.name, '') AS warehouse_keeper_name,
COALESCE(wk.phone, '') AS warehouse_keeper_phone
FROM loading_slip_items lsi
LEFT JOIN loading_slips ls
ON lsi.loading_slip_id = ls.loading_slip_id
LEFT JOIN orders o
ON ls.order_id = o.order_id
LEFT JOIN warehouses w
ON ls.warehouse_id = w.warehouse_id
LEFT JOIN warehouse_brands wb
ON LOWER(lsi.brand) = LOWER(wb.brand)
AND wb.warehouse_id = ls.warehouse_id
LEFT JOIN warehouse_keepers wk
ON wb.warehouse_keeper_id = wk.warehouse_keeper_id
WHERE lsi.is_active = TRUE
AND (
NULLIF({{ searchLoadingSlips.value }}::text, '') IS NULL
OR lsi.loading_slip_file_name ILIKE '%' || {{ searchLoadingSlips.value }}::text || '%'
)
AND (
NULLIF({{ loadingslipBrandFilter.value }}::text, '') IS NULL
OR LOWER(lsi.brand) = LOWER({{ loadingslipBrandFilter.value }}::text)
)
AND (
NULLIF({{ loadingslipwarehouseFilter.value }}::text, '') IS NULL
OR LOWER(w.name) = LOWER({{ loadingslipwarehouseFilter.value }}::text)
OR ls.warehouse_id::text = {{ loadingslipwarehouseFilter.value }}::text
)
AND (
NULLIF({{ loadingslipDaterangeFilter.value?.start || '' }}::text, '') IS NULL
OR (o.order_date AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= NULLIF({{ loadingslipDaterangeFilter.value?.start || '' }}::text, '')::date
)
AND (
NULLIF({{ loadingslipDaterangeFilter.value?.end || '' }}::text, '') IS NULL
OR (o.order_date AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < (NULLIF({{ loadingslipDaterangeFilter.value?.end || '' }}::text, '')::date + INTERVAL '1 day')
)
ORDER BY order_date_ist DESC
LIMIT {{ loadingSlipsTable.pagination.pageSize }}
OFFSET {{ loadingSlipsTable.pagination.offset }}
