UPDATE orders
SET po_number = {{ poNumberInput.value }}
WHERE order_id = {{ selectedOrderId.value }}