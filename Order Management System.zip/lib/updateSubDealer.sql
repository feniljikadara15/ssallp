UPDATE orders
SET sub_dealer = {{ subDealerInput.value }}
WHERE order_id = {{ selectedOrderId.value }}