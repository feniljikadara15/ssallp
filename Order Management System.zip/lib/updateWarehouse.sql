UPDATE enquiries
SET warehouse_id = {{ selectWarehouse.value }}
WHERE enquiry_id = {{ selectedEnquiryId.value }}