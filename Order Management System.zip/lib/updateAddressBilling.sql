UPDATE addresses
SET 
    line1 = {{ editBillingAddressLine1.value }},
    line2 = {{ editBillingAddressLine2.value }},
    city = {{ billingAddressCIty.value }},
    state = {{billingAddressState.value }},
    pincode = {{ billingAddressPincode.value }}

WHERE address_id = {{ getCustomerBillingAddress.data.address_id[0] }}
  AND type = 'billing';
