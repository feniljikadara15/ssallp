UPDATE warehouse_keepers
SET is_active = FALSE
WHERE warehouse_keeper_id = {{ table1.selectedSourceRow.warehouse_keeper_id }}