UPDATE warehouse_companies
SET 
  is_active  = false,
  updated_at = NOW()
WHERE warehouse_company_id = {{ getWarehouseCompaniesDetails.selectedSourceRow.warehouse_company_id }};
