SELECT
  ls.order_id,
  lsi.loading_slip_number,
  lsi.loading_slip_file_name
FROM loading_slip_items lsi
JOIN loading_slips ls
  ON lsi.loading_slip_id = ls.loading_slip_id;
