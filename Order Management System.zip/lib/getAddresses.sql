SELECT address_id, customer_id, type, line1, line2, city, state, country, pincode,
       maps_link, zb_address_id, state_code, is_active
FROM addresses
WHERE is_active = TRUE