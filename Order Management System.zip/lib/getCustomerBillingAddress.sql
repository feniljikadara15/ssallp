SELECT 
    a.address_id,
    a.line1,
    a.line2,
    a.city,
    a.state,
    a.pincode,
    a.country,
    a.maps_link,
    a.customer_id
FROM addresses a
WHERE a.customer_id = {{ customersTable.selectedSourceRow.customer_id }}
AND a.type = 'billing';
