SELECT 
    o.*, 
    lsi.loading_slip_file_name, 
    lsi.loading_slip_number
FROM orders o

JOIN (
    SELECT 
        order_id, 
        SUM(amount) AS total_collected
    FROM cash_collected
    WHERE is_active = TRUE
    GROUP BY order_id
) cc 
ON o.order_id = cc.order_id

LEFT JOIN loading_slips ls 
    ON ls.order_id = o.order_id 
    AND ls.is_active = TRUE

LEFT JOIN (
    SELECT DISTINCT ON (loading_slip_id) 
        loading_slip_id, 
        loading_slip_file_name, 
        loading_slip_number
    FROM loading_slip_items
    WHERE is_active = TRUE
    ORDER BY loading_slip_id, loading_slip_item_id ASC
) lsi 
ON lsi.loading_slip_id = ls.loading_slip_id

WHERE o.total_amount = cc.total_collected
AND o.is_active = TRUE

AND (
    {{
        !collectedCashBillsDateRange.value?.start
        || !collectedCashBillsDateRange.value?.end
    }}
    OR (
        o.order_date >= {{ collectedCashBillsDateRange.value.start || null }}
        AND o.order_date <= {{ collectedCashBillsDateRange.value.end || null }}
    )
)

ORDER BY o.order_date DESC;