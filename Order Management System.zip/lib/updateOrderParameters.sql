UPDATE orders
SET 
  warehouse_id = {{ selectWarehouse2.value }},
  transporter_id = {{ selectTransporter2.value }},
  vehicle_id = {{ selectVehicleNumber.value }},
  delivery_terms = {{ selectDeliveryTerms.value }},
  po_number = {{ poNumberInput.value }},
  sub_dealer = {{ subDealerInput.value }}
WHERE order_id = {{ selectedOrderId.value }}