UPDATE addresses
SET 
    state = {{ customersState.value}},
    pincode = {{ customerPincode.value }},
    city = {{ cityState.value }},
    line1 = {{ customerAddressLane1.value }},
    line2 = {{ customerAddressLane2.value }},
    maps_link = {{ siteMapLink.value }}

WHERE address_id = {{ customerSitesTable.selectedSourceRow.address_id }}
AND type = 'shipping';
