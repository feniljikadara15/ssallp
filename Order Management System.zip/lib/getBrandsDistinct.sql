SELECT DISTINCT (p.brand) AS brand
FROM products p
WHERE p.is_active = TRUE
AND NOT EXISTS (
    SELECT 1 
    FROM warehouse_brands wb
    WHERE wb.warehouse_id = {{ selectedWarehouseId.value }}
    AND LOWER(wb.brand) = LOWER(p.brand)
);