UPDATE transporters
SET is_active = FALSE
WHERE transporter_id = {{ selectedTransporterId.value }}