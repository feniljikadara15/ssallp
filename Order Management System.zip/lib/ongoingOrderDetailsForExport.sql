SELECT
    CASE 
        WHEN ROW_NUMBER() OVER (PARTITION BY o.order_id ORDER BY p.brand) = 1 
        THEN o.order_id::text 
        ELSE '' 
    END AS "Order No",
    p.brand AS "Brand Name",
    p.grade AS "Brand Grade",
    oi.quantity AS "Number of Bags",
    c.name AS "Party Name",
    s.site_person_contact AS "Site Person Number",
    s.site_name AS "Site Name",
    a.line2 AS "Location Line 2",
    t.name AS "Assigned Transporter"
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
LEFT JOIN sites s ON o.site_id = s.site_id
LEFT JOIN addresses a ON s.address_id = a.address_id
LEFT JOIN customers c ON o.customer_id = c.customer_id
LEFT JOIN transporters t ON o.transporter_id = t.transporter_id
WHERE 
    o.order_status = '1'
    AND (
        (
          COALESCE(NULLIF({{ ongoingOrdersDateRange.value.start }}, ''), NULL) IS NULL 
          OR o.order_date::date >= COALESCE(NULLIF({{ ongoingOrdersDateRange.value.start }}, ''), NULL)::date
        )
        AND
        (
          COALESCE(NULLIF({{ ongoingOrdersDateRange.value.end }}, ''), NULL) IS NULL 
          OR o.order_date::date <= COALESCE(NULLIF({{ ongoingOrdersDateRange.value.end }}, ''), NULL)::date
        )
    )
ORDER BY 
    o.order_id DESC, 
    p.brand;
