SELECT DISTINCT w.warehouse_id, w.name
FROM warehouses w
WHERE w.is_active = TRUE
AND NOT EXISTS (
    SELECT 1 
    FROM transporter_warehouses tw
    WHERE tw.transporter_id = {{ selectedTransporterId.value }}
    AND tw.warehouse_id = w.warehouse_id
);