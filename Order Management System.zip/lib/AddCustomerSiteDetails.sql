INSERT INTO sites (
    site_name,
    site_person_name,
    site_person_contact,
   customer_id,
   address_id,
    created_at,
    updated_at,
    is_active
)
VALUES (
    {{ AddCustomerSiteName.value }},
    {{ addCustomerSItePersonName.value }},
    {{ addCustomerSItePersonContact.value}},
    {{ customersTable.selectedSourceRow.customer_id }},
    {{ AddCustomerAdress.data.address_id[0] }},
    NOW(),
    NOW(),
    TRUE
);
