UPDATE enquiries
SET transporter_id = {{ selectTransporter.value }}
WHERE enquiry_id = {{ selectedEnquiryId.value }}