UPDATE products
SET 
    product_name = {{ productName.value }} ,
    category = {{ productCategory.value }} ,
    description =  {{ productDescription.value }},
    brand = {{ productBrand.value }} ,
    grade = {{ productGrade.value }},
    unit = {{ productUnit.value }},
    sku = {{ productSKU.value }},
    hsn = {{ productHSN.value }} ,
    gst_rate = {{ Number(productGST.value) }} ,
    mrp = {{ Number(productMRP.value) }} ,
    is_active = {{ Boolean(productActive.value) }} ,
    updated_at = NOW()
WHERE product_id = {{ productsTable.selectedSourceRow.product_id }}
RETURNING product_id;
