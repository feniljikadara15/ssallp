UPDATE orders
SET order_status = 5
WHERE order_id = {{ selectedOrderId.value }}