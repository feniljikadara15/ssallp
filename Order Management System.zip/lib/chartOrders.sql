SELECT
  DATE_TRUNC('month', created_at) AS month_start,
  TO_CHAR(DATE_TRUNC('month', created_at), 'Mon YYYY') AS month_label,
  COUNT(*) AS order_count
FROM orders
WHERE created_at >= DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '12 months'
GROUP BY DATE_TRUNC('month', created_at)
ORDER BY month_start;
