<SidebarFrame
  id="sidebarFrame1"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  isHiddenOnMobile={true}
  padding="8px 12px"
  showFooter={true}
  style={{ ordered: [{ background: "secondary" }] }}
  styleContext={{ ordered: [] }}
  width="large"
>
  <Body>
    <Image
      id="image1"
      fit="contain"
      heightType="fixed"
      horizontalAlign="center"
      retoolStorageFileId="a3e53c83-9077-4848-b1ab-f16bbcfadda4"
      src="https://picsum.photos/id/1025/800/600"
      srcType="retoolStorageFileId"
    />
    <Text
      id="text18"
      value="###### Sambhavnath Agencies LLP"
      verticalAlign="center"
    />
    <Divider id="divider19" text="Dashboard" />
    <Navigation
      id="navigation7"
      appTargetByIndex=""
      captionByIndex=""
      data=""
      disabledByIndex=""
      hiddenByIndex=""
      highlightByIndex=""
      iconByIndex=""
      iconPositionByIndex=""
      itemMode="static"
      itemTypeByIndex=""
      keyByIndex=""
      labels=""
      orientation="vertical"
      parentKeyByIndex=""
      retoolFileObject={{ ordered: [] }}
      screenTargetByIndex=""
      screenTargetIdByIndex=""
      style={{ pillRadius: "16px", highlightBackground: "primary" }}
      tooltipByIndex=""
    >
      <Option
        id="da3ad"
        icon="bold/interface-dashboard-layout-3"
        iconPosition="left"
        itemType="page"
        label="Dashboard"
        screenTargetId="Dashboard"
      />
      <Event
        id="611f4d6d"
        event="click"
        method="openPage"
        params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Navigation>
    <Divider id="divider2" text="ORDER MANAGEMENT" />
    <Navigation
      id="navigation2"
      appTargetByIndex=""
      captionByIndex=""
      data=""
      disabledByIndex=""
      hiddenByIndex=""
      highlightByIndex=""
      iconByIndex=""
      iconPositionByIndex=""
      itemMode="static"
      itemTypeByIndex=""
      keyByIndex=""
      labels=""
      orientation="vertical"
      parentKeyByIndex=""
      screenTargetByIndex=""
      screenTargetIdByIndex=""
      src={null}
      srcType={null}
      style={{
        ordered: [{ highlightBackground: "primary" }, { pillRadius: "16px" }],
      }}
      tooltipByIndex=""
    >
      <Option
        id="9f7c7"
        icon="line/mail-chat-two-bubbles-oval"
        iconPosition="left"
        itemType="page"
        label="Enquiries"
        screenTargetId="enquiries"
      />
      <Option
        id="6c255"
        disabled={false}
        hidden={false}
        highlight={false}
        icon="line/interface-file-clipboard-check"
        iconPosition="left"
        itemType="page"
        label="Orders"
        screenTargetId="orders"
      />
      <Event
        id="003887f2"
        event="click"
        method="openPage"
        params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Navigation>
    <Divider id="divider5" text="ACCOUNTING" />
    <Navigation
      id="navigation4"
      appTargetByIndex=""
      captionByIndex=""
      data=""
      disabledByIndex=""
      hiddenByIndex=""
      highlightByIndex=""
      iconByIndex=""
      iconPositionByIndex=""
      itemMode="static"
      itemTypeByIndex=""
      keyByIndex=""
      labels=""
      orientation="vertical"
      parentKeyByIndex=""
      retoolFileObject={{ ordered: [] }}
      screenTargetByIndex=""
      screenTargetIdByIndex=""
      style={{
        ordered: [{ highlightBackground: "primary" }, { pillRadius: "16px" }],
      }}
      tooltipByIndex=""
    >
      <Option
        id="ac46f"
        icon="line/money-cash-bag-share"
        iconPosition="left"
        itemType="page"
        label="Cash Bills"
        screenTargetId="cashBills"
      />
      <Event
        id="e9c48ab5"
        event="click"
        method="openPage"
        params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Navigation>
    <Divider id="divider4" text="LOGISTICS" />
    <Navigation
      id="navigation3"
      appTargetByIndex=""
      captionByIndex=""
      data=""
      disabledByIndex=""
      hiddenByIndex=""
      highlightByIndex=""
      iconByIndex=""
      iconPositionByIndex=""
      itemMode="static"
      itemTypeByIndex=""
      keyByIndex=""
      labels=""
      orientation="vertical"
      parentKeyByIndex=""
      retoolFileObject={{ ordered: [] }}
      screenTargetByIndex=""
      screenTargetIdByIndex=""
      style={{
        ordered: [{ highlightBackground: "primary" }, { pillRadius: "16px" }],
      }}
      tooltipByIndex=""
    >
      <Option
        id="e538c"
        icon="line/shipping-transfer-cart"
        iconPosition="left"
        itemType="page"
        label="Warehouses"
        screenTargetId="warehouses"
      />
      <Option
        id="20a81"
        icon="line/shipping-transfer-truck"
        iconPosition="left"
        itemType="page"
        label="Transporters"
        screenTargetId="transporters"
      />
      <Option
        id="6a338"
        disabled={false}
        hidden={false}
        highlight={false}
        icon="line/travel-map-location-user-pin"
        iconPosition="left"
        itemType="page"
        label="Warehouse Keepers"
        screenTargetId="warehouseKeepers"
      />
      <Option
        id="037c2"
        disabled={false}
        hidden={false}
        highlight={false}
        icon="bold/shipping-transfer-truck"
        iconPosition="left"
        itemType="page"
        label="Transporter Vehicle Details"
        screenTargetId="transporterVehicleDetails"
      />
      <Event
        id="4345503f"
        event="click"
        method="openPage"
        params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Navigation>
    <Divider id="divider6" text="PRODUCTS" />
    <Navigation
      id="navigation5"
      appTargetByIndex=""
      captionByIndex=""
      data=""
      disabledByIndex=""
      hiddenByIndex=""
      highlightByIndex=""
      iconByIndex=""
      iconPositionByIndex=""
      itemMode="static"
      itemTypeByIndex=""
      keyByIndex=""
      labels=""
      orientation="vertical"
      parentKeyByIndex=""
      retoolFileObject={{ ordered: [] }}
      screenTargetByIndex=""
      screenTargetIdByIndex=""
      style={{
        ordered: [{ highlightBackground: "primary" }, { pillRadius: "16px" }],
      }}
      tooltipByIndex=""
    >
      <Option
        id="da3ad"
        icon="bold/money-cashier-tag"
        iconPosition="left"
        itemType="page"
        label="Products"
        screenTargetId="products"
      />
      <Event
        id="a96fb6f2"
        event="click"
        method="openPage"
        params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Navigation>
    <Divider id="divider8" text="CUSTOMERS" />
    <Navigation
      id="navigation6"
      appTargetByIndex=""
      captionByIndex=""
      data=""
      disabledByIndex=""
      hiddenByIndex=""
      highlightByIndex=""
      iconByIndex=""
      iconPositionByIndex=""
      itemMode="static"
      itemTypeByIndex=""
      keyByIndex=""
      labels=""
      orientation="vertical"
      parentKeyByIndex=""
      retoolFileObject={{ ordered: [] }}
      screenTargetByIndex=""
      screenTargetIdByIndex=""
      style={{ pillRadius: "16px", highlightBackground: "primary" }}
      tooltipByIndex=""
    >
      <Option
        id="da3ad"
        icon="bold/interface-user-single"
        iconPosition="left"
        itemType="page"
        label="Customers"
        screenTargetId="Customers"
      />
      <Option
        id="d73e1"
        disabled={false}
        hidden="true"
        highlight={false}
        iconPosition="left"
        itemType="page"
        label="Orders Test"
      />
      <Option
        id="f8688"
        disabled={false}
        hidden={false}
        highlight={false}
        icon="bold/shipping-box-1-alternate"
        iconPosition="left"
        itemType="page"
        label="Loading Slips"
        screenTargetId="LoadingSlips"
      />
      <Event
        id="611f4d6d"
        event="click"
        method="openPage"
        params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Navigation>
  </Body>
  <Footer>
    <Avatar
      id="avatar1"
      fallback="{{ current_user.fullName }}"
      imageSize={32}
      label="{{ current_user.fullName }}"
      labelCaption="{{ current_user.email }}"
      margin="4px 4px"
      src="{{ current_user.profilePhotoUrl }}"
      style={{ ordered: [{ background: "automatic" }] }}
    />
    <Button
      id="button5"
      iconAfter="bold/interface-link-circle-alternate"
      style={{ ordered: [{ background: "info" }] }}
      text="External Form"
    >
      <Event
        id="655f4b61"
        event="click"
        method="openUrl"
        params={{
          ordered: [
            { url: "https://wordpress-511305-4547121.cloudwaysapps.com/" },
          ],
        }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</SidebarFrame>
