<ModalFrame
  id="addWarehouseBrandModal"
  footerPadding="8px 12px"
  headerPadding="12px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showHeaderBorder={false}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="modalTitle3"
      value="### Add Warehouse Brand"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton3"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ ordered: [{ border: "transparent" }] }}
      styleVariant="outline"
    >
      <Event
        id="50fb9798"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await addWarehouseBrandModal.setHidden();\nawait selectWarehouseBrand.clearValue();\nawait selectWarehouseKeeper.clearValue();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Select
      id="selectWarehouseBrand"
      data="{{ getBrandsDistinct.data }}"
      emptyMessage="No options"
      label="Brand"
      labelPosition="top"
      labels="{{ item.brand }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      values="{{ item.brand }}"
    />
    <Select
      id="selectWarehouseKeeper"
      captionByIndex=""
      data="{{ getWarehouseKeepersWarehouse.data }}"
      emptyMessage="No options"
      label="Warehouse Keeper"
      labelPosition="top"
      labels="{{ item.name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      values="{{ item.warehouse_keeper_id }}"
    />
  </Body>
  <Footer>
    <Button
      id="addWarehouseBrandButton"
      disabled="{{ selectWarehouseBrand.value == null || selectWarehouseKeeper.value == null }}"
      loaderPosition="right"
      loading="{{ getWarehouseBrands.isFetching || addWarehouseBrand.isFetching }}"
      text="Save"
    >
      <Event
        id="d8956fac"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await addWarehouseBrandButton.setDisabled();\nawait addWarehouseBrand.trigger();\nawait warehouseBrandsTable.refresh();\nawait addWarehouseBrandButton.setDisabled(false);\nawait addWarehouseBrandModal.hide();\nawait selectWarehouseBrand.clearValue();\nawait selectWarehouseKeeper.clearValue();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
