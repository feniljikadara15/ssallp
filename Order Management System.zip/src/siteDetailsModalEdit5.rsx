<ModalFrame
  id="siteDetailsModalEdit5"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="large"
>
  <Header>
    <Text
      id="modalTitle39"
      value="### Edit Site Details"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton40"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="6ef7f88f"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="siteDetailsModalEdit5"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <PhoneNumberInput
      id="customerSitePersonContact5"
      label="Site Person Contact"
      labelPosition="top"
      lockedCountryCode="US"
      value="{{ customerSitesTable5.selectedSourceRow.site_person_contact }}"
    />
    <TextInput
      id="customerSiteName5"
      label="Site Name"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ customerSitesTable5.selectedSourceRow.site_name }}"
    />
    <TextInput
      id="customerSItePersonName5"
      label="Site Person Name"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ customerSitesTable5.selectedSourceRow.site_person_name }}"
    />
    <TextInput
      id="cityState4"
      label="City"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ customerSitesTable5.selectedSourceRow.city }}"
    />
    <TextInput
      id="customersState5"
      label="State"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ customerSitesTable5.selectedSourceRow.state }}"
    />
    <TextArea
      id="customerAddressLane9"
      autoResize={true}
      label="Address Lane 1"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
      value="{{ customerSitesTable5.selectedSourceRow.line1 }}"
    />
    <TextArea
      id="customerAddressLane10"
      autoResize={true}
      label="Address Lane 2"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
      value="{{ customerSitesTable5.selectedSourceRow.line2 }}"
    />
    <NumberInput
      id="customerPincode5"
      currency="USD"
      inputValue={0}
      label="Pincode"
      labelPosition="top"
      placeholder="Enter value"
      preventScroll={true}
      value="{{ customerSitesTable5.selectedSourceRow.pincode }}"
    />
    <TextInput
      id="siteMapLink5"
      label="Map Link"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ customerSitesTable5.selectedSourceRow.maps_link }}"
    />
  </Body>
  <Footer>
    <Button
      id="deleteSiteDetailsButton4"
      loading="{{ deleteSiteAddress3.isFetching }}"
      style={{ map: { background: "rgba(246, 4, 4, 1)" } }}
      text="Delete"
    >
      <Event
        id="88c01e49"
        event="click"
        method="run"
        params={{
          map: {
            src: "await deleteSiteAddress3.trigger();\nawait siteDetailsModalEdit5.setHidden();\nawait getCustomersSItes3.trigger();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button id="editSiteDetailsButton5" text="Save">
      <Event
        id="cda24814"
        event="click"
        method="run"
        params={{
          map: {
            src: "await updateSite3.trigger();\nawait siteUpdateAddress3.trigger();\nawait siteDetailsModalEdit5.setHidden();\nawait getCustomersSItes3.trigger();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
