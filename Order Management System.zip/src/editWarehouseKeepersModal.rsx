<ModalFrame
  id="editWarehouseKeepersModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showHeader={true}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="modalTitle18"
      value="### Edit warehouse Keepers"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton19"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="96ca5a67"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="editWarehouseKeepersModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="editWarehouseKeeperNameInput"
      label="Name"
      labelPosition="top"
      placeholder="Enter name"
      value="{{ table1.selectedSourceRow.name }}"
    />
    <PhoneNumberInput
      id="editWarehouseKeeperPhoneInput"
      _lockSelectedCountry={true}
      label="Phone"
      labelPosition="top"
      lockedCountryCode="IN"
      value="{{ table1.selectedSourceRow.phone }}"
    />
    <Select
      id="editSelectKeeperWarehouse"
      data="{{ getWarehouses.data }}"
      emptyMessage="No options"
      label="Warehouse"
      labelPosition="top"
      labels="{{ item.name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value="{{ table1.selectedSourceRow.warehouse_id }}"
      values="{{ item.warehouse_id }}"
    />
    <Button
      id="deleteWarehouseKeeperButton"
      disabled=""
      loading=""
      style={{ map: { hoverBackground: "tertiary" } }}
      styleVariant="outline"
      text="Delete"
    >
      <Event
        id="19741121"
        event="click"
        method="run"
        params={{
          map: {
            src: "await deleteWarehouseKeeper.trigger();\nawait editWarehouseKeepersModal.setHidden();\nawait getWarehouseKeepers.trigger();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="updateWarehouseKeeperButton"
      disabled=""
      loading="{{ updateWarehouseKeeper.isFetching }}"
      text="Update"
    >
      <Event
        id="12d84403"
        event="click"
        method="run"
        params={{
          map: {
            src: "await updateWarehouseKeeper.trigger();\nawait editWarehouseKeepersModal.setHidden();\nawait getWarehouseKeepers.trigger();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Body>
</ModalFrame>
