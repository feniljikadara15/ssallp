<ModalFrame
  id="addCompanyModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text id="modalTitle20" value="#### Add Company " verticalAlign="center" />
    <Button
      id="modalCloseButton21"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="eb75cd04"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="addCompanyModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="companyNameInput"
      label="Company Name"
      labelPosition="top"
      placeholder="Enter value"
    />
    <TextInput
      id="companyCountry"
      label="Country"
      labelPosition="top"
      placeholder="Enter value"
    />
    <TextInput
      id="companyState"
      label="State"
      labelPosition="top"
      placeholder="Enter value"
    />
    <TextInput
      id="companyCIty"
      label="City"
      labelPosition="top"
      placeholder="Enter value"
    />
    <TextArea
      id="companyAddressLine1"
      autoResize={true}
      label="Address Line 1"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
    />
    <TextArea
      id="companyAddressLine2"
      autoResize={true}
      label="Address Line 2"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
    />
    <TextInput
      id="companyPincode"
      label="Pincode"
      labelPosition="top"
      placeholder="Enter value"
    />
  </Body>
  <Footer>
    <Button id="button7" text="Save" />
  </Footer>
</ModalFrame>
