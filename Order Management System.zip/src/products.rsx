<Screen
  id="products"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={6}
  _searchParams={[{ ordered: [{ key: "_embed" }, { value: "true" }] }]}
  browserTitle=""
  title={null}
  urlSlug=""
  uuid="3b784c0a-e14f-48b1-b654-7e26be6697e4"
>
  <Folder id="ZohoBooks">
    <SqlQueryUnified
      id="getZohoTaxes"
      cacheKeyTtl="3600"
      enableCaching={true}
      query={include("../lib/getZohoTaxes.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <RESTQuery
      id="deleteProductZB"
      bodyType="json"
      query="items/{{ productsTable.selectedSourceRow.zb_item_id}}?organization_id=60031284196"
      resourceDisplayName="ZB v3"
      resourceName="c5058a3e-b80a-4586-a22f-88cbcba8ab5f"
      resourceTypeOverride=""
      runWhenModelUpdates={false}
      successMessage="Product Deleted in Zoho Books"
      type="DELETE"
    />
    <RESTQuery
      id="addProductZB"
      body={
        '{\n  "name" : {{ newProductName.value }},\n  "sku": {{ newProductSKU.value }} ,\n  "brand": {{ newProductBrand.value }} ,\n  "description": {{ newProductDescription.value }} ,\n  "rate": {{ newProductMRP.value }} ,\n  "hsn_or_sac": {{ newProductHSN.value }},\n  "status" :  "active" ,\n  "unit" : {{ newProductUnit.value }},\n  "item_tax_preferences": [\n                {\n                    "tax_specification": "inter",\n                    "tax_id": {{ getZohoTaxes.data.zb_tax_id[\n  getZohoTaxes.data.tax_rate.findIndex((rate, i) => \n    rate === newProductGST.value.toString() && \n    getZohoTaxes.data.tax_type[i] === "inter"\n  )\n] }} ,\n                },\n                {\n                    "tax_specification": "intra",\n                    "tax_id": {{ getZohoTaxes.data.zb_tax_id[\n  getZohoTaxes.data.tax_rate.findIndex((rate, i) => \n    rate === newProductGST.value.toString() && \n    getZohoTaxes.data.tax_type[i] === "intra"\n  )\n] }}\n                }\n            ]\n}'
      }
      bodyType="raw"
      query="items?organization_id=60031284196"
      resourceDisplayName="ZB v3"
      resourceName="c5058a3e-b80a-4586-a22f-88cbcba8ab5f"
      runWhenModelUpdates={false}
      successMessage="Product Added in Zoho Books"
      type="POST"
    />
    <RESTQuery
      id="updateProductZB"
      _additionalScope={[]}
      body={
        '{\n  "name" : {{ productName.value }},\n  "sku": {{ productSKU.value }} ,\n  "brand": {{ productBrand.value }} ,\n  "description": {{ productDescription.value }} ,\n  "rate": {{ productMRP.value }} ,\n  "hsn_or_sac": {{ productHSN.value }},\n  "status" : {{ productActive.value == true ? "active" : "inactive" }},\n  "unit" : {{ productUnit.value }},\n  "item_tax_preferences": [\n                {\n                    "tax_specification": "inter",\n                    "tax_id": {{ getZohoTaxes.data.zb_tax_id[\n  getZohoTaxes.data.tax_rate.findIndex((rate, i) => \n    rate === productGST.value.toString() && \n    getZohoTaxes.data.tax_type[i] === "inter"\n  )\n] }} ,\n                },\n                {\n                    "tax_specification": "intra",\n                    "tax_id": {{ getZohoTaxes.data.zb_tax_id[\n  getZohoTaxes.data.tax_rate.findIndex((rate, i) => \n    rate === productGST.value.toString() && \n    getZohoTaxes.data.tax_type[i] === "intra"\n  )\n] }}\n                }\n            ]\n}'
      }
      bodyType="raw"
      query="items/{{ productsTable.selectedSourceRow.zb_item_id }}?organization_id=60031284196"
      resourceDisplayName="ZB v3"
      resourceName="c5058a3e-b80a-4586-a22f-88cbcba8ab5f"
      runWhenModelUpdates={false}
      successMessage="Product Updated in Zoho Books"
      type="PUT"
    />
    <WorkflowRun
      id="upsertProductsZB"
      resourceName="WorkflowRun"
      successMessage="Products Synced with Zoho Books"
      workflowId="060aa1d9-ccef-490d-8f2b-a5ce7b3097d8"
    />
  </Folder>
  <Folder id="folder1">
    <SqlQueryUnified
      id="deleteProduct"
      isMultiplayerEdited={false}
      query={include("../lib/deleteProduct.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      successMessage="Product Deleted Successfully"
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="addProduct"
      query={include("../lib/addProduct.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      successMessage="New Product Added."
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updateProduct"
      notificationDuration={4.5}
      query={include("../lib/updateProduct.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="getAllProducts"
      notificationDuration={4.5}
      query={include("../lib/getAllProducts.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
  </Folder>
  <JavascriptQuery
    id="query13"
    notificationDuration={4.5}
    query={include("../lib/query13.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <Include src="./addProductModal.rsx" />
  <Include src="./deleteProductModal.rsx" />
  <Include src="./editProductModal.rsx" />
  <Frame
    id="$main7"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <Text id="text60" value="### Products" verticalAlign="center" />
    <Button
      id="addProductButton"
      iconAfter="bold/interface-add-circle-alternate"
      text="Add Product"
    >
      <Event
        id="84e98246"
        event="click"
        method="show"
        params={{}}
        pluginId="addProductModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Divider id="divider7" />
    <Statistic
      id="productStatistic"
      currency="USD"
      label="Product Count"
      labelCaption="Active Products"
      positiveTrend="{{ self.value >= 0 }}"
      secondaryCurrency="USD"
      secondaryEnableTrend={true}
      secondaryFormattingStyle="percent"
      secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
      secondaryShowSeparators={true}
      secondarySignDisplay="trendArrows"
      secondaryValue=""
      showSeparators={true}
      value="{{ getProducts.data.product_id.length }}"
    />
    <TextInput
      id="searchProducts"
      iconBefore="line/interface-edit-pin-3"
      label=""
      labelPosition="top"
      placeholder="Search Products..."
    />
    <Table
      id="productsTable"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ getAllProducts.data }}"
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      heightType="auto"
      primaryKeyColumnId="a3c68"
      rowHeight="medium"
      searchTerm="{{ searchProducts.value }}"
      showBorder={true}
      showColumnBorders={true}
      showFooter={true}
      showHeader={true}
      style={{ headerBackground: "rgba(255, 244, 239, 1)" }}
    >
      <Column
        id="a3c68"
        alignment="right"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="product_id"
        label="Product ID"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="e4473"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="product_name"
        label="Product Name"
        placeholder="Enter value"
        position="center"
        size={157.375}
        summaryAggregationMode="none"
      />
      <Column
        id="9a360"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="category"
        label="Category"
        placeholder="Enter value"
        position="center"
        size={68.609375}
        summaryAggregationMode="none"
      />
      <Column
        id="2dc47"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="brand"
        label="Brand"
        placeholder="Enter value"
        position="center"
        size={49.5}
        summaryAggregationMode="none"
      />
      <Column
        id="5786e"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="grade"
        label="Grade"
        placeholder="Enter value"
        position="center"
        size={50.578125}
        summaryAggregationMode="none"
      />
      <Column
        id="a45fe"
        alignment="center"
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="unit"
        label="Unit"
        placeholder="Select option"
        position="center"
        size={58.03125}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="47989"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="sku"
        label="SKU"
        placeholder="Enter value"
        position="center"
        size={122.4375}
        summaryAggregationMode="none"
      />
      <Column
        id="c5d98"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="hsn"
        label="HSN/SAC"
        placeholder="Enter value"
        position="center"
        size={70.3125}
        summaryAggregationMode="none"
      />
      <Column
        id="b2c84"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        key="gst_rate"
        label="GST Rate"
        placeholder="Enter value"
        position="center"
        size={69.375}
        summaryAggregationMode="none"
        valueOverride="{{ item/100 }}"
      />
      <Column
        id="8677d"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="mrp"
        label="MRP"
        placeholder="Enter value"
        position="center"
        size={41.953125}
        summaryAggregationMode="none"
      />
      <Column
        id="5410d"
        alignment="center"
        format="boolean"
        groupAggregationMode="none"
        key="is_active"
        label="Is active"
        placeholder="Enter value"
        position="center"
        size={62.9375}
        summaryAggregationMode="none"
      />
      <Column
        id="50906"
        alignment="center"
        format="button"
        formatOptions={{ variant: "solid" }}
        groupAggregationMode="none"
        label="Action"
        placeholder="Enter value"
        position="center"
        referenceId="edit"
        size={52.203125}
        summaryAggregationMode="none"
        valueOverride="Edit"
      >
        <Event
          id="858ae801"
          event="clickCell"
          method="show"
          pluginId="editProductModal"
          type="widget"
          waitMs={0}
          waitType="debounce"
        />
      </Column>
      <ToolbarButton
        id="1a"
        icon="bold/interface-text-formatting-filter-2"
        label="Filter"
        type="filter"
      />
      <ToolbarButton
        id="4d"
        icon="bold/interface-arrows-round-left"
        label="Refresh"
        type="custom"
      >
        <Event
          id="539539d5"
          event="clickToolbar"
          method="trigger"
          params={{ ordered: [] }}
          pluginId="getProducts"
          type="datasource"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
      <Event
        id="27896563"
        event="doubleClickRow"
        method="show"
        params={{}}
        pluginId="editProductModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Table>
  </Frame>
</Screen>
