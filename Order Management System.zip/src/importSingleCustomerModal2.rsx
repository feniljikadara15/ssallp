<ModalFrame
  id="importSingleCustomerModal2"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="modalTitle41"
      value="#### Import Single Customer from Zoho Books"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton42"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="e918f269"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="importSingleCustomerModal2"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="zbCustomerIDInput2"
      label="Zoho Books Customer ID"
      labelPosition="top"
      pattern="^\d{18,19}$"
      patternType="regex"
      placeholder="Enter value"
    />
    <TextInput
      id="zbCustomerImportCheck2"
      label="Import Check"
      labelPosition="top"
      placeholder="Enter value"
      readOnly="true"
      value={
        '{{ Number.isFinite(\n    getAllCustomers3.data.customer_id[\n      getAllCustomers3.data.zb_customer_id.indexOf(zbCustomerIDInput2.value)\n    ]\n  )\n    ? "Customer Already Exists in the DB. Please check and activate if required."\n    : "Ready for Import" }}'
      }
    />
    <Button
      id="checkNewZBCustomerValidityButton2"
      loading="{{ checkZBCustomerValidity2.isFetching }}"
      text="Check Validity"
    >
      <Event
        id="d14a0191"
        event="click"
        method="trigger"
        params={{}}
        pluginId="checkZBCustomerValidity2"
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Status
      id="ZBNewCustomerValidity2"
      hidden="{{ checkZBCustomerValidity2.data === null || checkZBCustomerValidity2.data.message.length <= 0 }}"
      itemMode="static"
      maintainSpaceWhenHidden={true}
      margin="6px 8px 0px 4px"
      style={{ fontSize: "h6Font", fontWeight: "h6Font", fontFamily: "h6Font" }}
      value={
        '{{ checkZBCustomerValidity2.data.message == "success" ? "valid" : "invalid" }}'
      }
    >
      <Option
        id="00030"
        color="{{ theme.success }}"
        icon="bold/interface-validation-check-circle"
        label="Valid"
        value="valid"
      />
      <Option
        id="00032"
        color="rgba(233, 0, 12, 1)"
        icon="bold/interface-delete-circle"
        label="Invalid"
        value="invalid"
      />
    </Status>
  </Body>
  <Footer>
    <Button
      id="importSingleZBCustomerWFButton2"
      disabled={
        '{{!(Number.isFinite(\n    getAllCustomers3.data.customer_id[\n      getAllCustomers3.data.zb_customer_id.indexOf(zbCustomerIDInput2.value)\n    ]\n  )) && ZBNewCustomerValidity2.value == "invalid" }}'
      }
      loading="{{ importSingleZBCustomer2.isFetching }}"
      text="Import"
    >
      <Event
        id="f71932c6"
        event="click"
        method="run"
        params={{
          map: {
            src: "await importSingleZBCustomerWFButton2.setDisabled();\nawait importSingleZBCustomer2.trigger();\nawait zbCustomerIDInput2.clearValue();\nawait importSingleCustomerModal2.setHidden();\nawait getCustomers.trigger();\nawait getAllCustomers3.trigger();\nawait loadingSlipsTable.refresh();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
