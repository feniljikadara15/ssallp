<Container
  id="manageTransporterContainer"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  hidden="{{ selectedTransporterId.value == null }}"
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
>
  <Header>
    <Text
      id="containerTitle23"
      value="#### Manage Transporter: {{ getTransporters.data.name[getTransporters.data.transporter_id.indexOf(selectedTransporterId.value)] }}"
      verticalAlign="center"
    />
    <Button
      id="deleteTransporterButton"
      iconBefore="bold/interface-delete-bin-1"
      loading="{{ deleteAllVehiclesForTransporter.isFetching || deleteAllWarehousesTransporter.isFetching || deleteTransporter.isFetching || getTransporters.isFetching }}"
      style={{ ordered: [{ background: "danger" }] }}
      text="Delete Transporter"
    >
      <Event
        id="0af5acda"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await deleteTransporterButton.setDisabled(true);\nawait deleteAllVehiclesForTransporter.trigger();\nawait deleteAllWarehousesTransporter.trigger();\nawait deleteTransporter.trigger()\nawait getTransporters.trigger();\nawait selectedTransporterId.setValue(null);\nawait deleteTransporterButton.setDisabled(false)",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <View id="d03e6" viewKey="View 1">
    <TextInput
      id="transporterNameInput"
      disabled="{{ getTransporters.isFetching || updateTransporterDetails.isFetching }}"
      label="Name"
      labelPosition="top"
      placeholder="Enter transporter name"
      value="{{ getTransporters.data.name[getTransporters.data.transporter_id.indexOf(selectedTransporterId.value)] }}"
    >
      <Event
        id="89c43693"
        event="blur"
        method="run"
        params={{
          ordered: [
            {
              src: "await updateTransporterDetails.trigger();\nawait getTransporters.trigger();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </TextInput>
    <PhoneNumberInput
      id="transporterPhoneInput"
      _lockSelectedCountry={true}
      disabled="{{ getTransporters.isFetching || updateTransporterDetails.isFetching }}"
      label="Phone Number"
      labelPosition="top"
      lockedCountryCode="IN"
      value="{{ getTransporters.data.phone_number[getTransporters.data.transporter_id.indexOf(selectedTransporterId.value)] }}"
    >
      <Event
        id="aa90aa23"
        event="blur"
        method="run"
        params={{
          ordered: [
            {
              src: "await updateTransporterDetails.trigger();\nawait getTransporters.trigger();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </PhoneNumberInput>
    <PhoneNumberInput
      id="transporterAdditionalPhoneInput"
      _lockSelectedCountry={true}
      disabled="{{ getTransporters.isFetching || updateTransporterDetails.isFetching }}"
      label="Additional Phone Number"
      labelPosition="top"
      lockedCountryCode="IN"
      value="{{ getTransporters.data.phone_number[getTransporters.data.transporter_id.indexOf(selectedTransporterId.value)] }}"
    >
      <Event
        id="1590d62d"
        event="blur"
        method="run"
        params={{
          ordered: [
            {
              src: "await updateTransporterDetails.trigger();\nawait getTransporters.trigger();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </PhoneNumberInput>
    <Table
      id="transporterVehiclesTable"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ getTransporterVehicles.data }}"
      defaultSelectedRow={{ mode: "none", indexType: "display", index: 0 }}
      defaultSort={[{ object: { columnId: "b38b5", direction: "asc" } }]}
      emptyMessage="No rows found"
      enableSaveActions={true}
      heightType="auto"
      primaryKeyColumnId="b38b5"
      rowHeight="small"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
    >
      <Column
        id="b38b5"
        alignment="right"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="vehicle_id"
        label="Vehicle ID"
        placeholder="Enter value"
        position="center"
        size={68.90625}
        summaryAggregationMode="none"
      />
      <Column
        id="2d99a"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="vehicle_number"
        label="Vehicles"
        placeholder="Enter value"
        position="center"
        size={87.484375}
        summaryAggregationMode="none"
      />
      <ToolbarButton
        id="4d"
        icon="bold/interface-arrows-round-left"
        label="Refresh"
        type="custom"
      >
        <Event
          id="a49e5a99"
          event="clickToolbar"
          method="refresh"
          pluginId="transporterVehiclesTable"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
      <ToolbarButton
        id="9a7ab"
        hidden="{{ transporterVehiclesTable.selectedRow == null }}"
        icon="bold/interface-delete-bin-1"
        label="Delete"
        type="custom"
      >
        <Event
          id="da42928a"
          event="clickToolbar"
          method="run"
          params={{
            ordered: [
              {
                src: "await deleteTransporterVehicle.trigger();\nawait transporterVehiclesTable.refresh();",
              },
            ],
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
    </Table>
    <Table
      id="transporterWarehousesTable"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ getTransporterWarehouses.data }}"
      defaultSelectedRow={{ mode: "none", indexType: "display", index: 0 }}
      defaultSort={[{ object: { columnId: "7c04b", direction: "asc" } }]}
      emptyMessage="No rows found"
      enableSaveActions={true}
      heightType="auto"
      primaryKeyColumnId="7c04b"
      rowHeight="small"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
    >
      <Column
        id="7c04b"
        alignment="right"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="transporter_warehouse_id"
        label="Transporter warehouse ID"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="7bf48"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="warehouse_id"
        label="Warehouse ID"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="b615d"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="warehouse_name"
        label="Warehouses"
        placeholder="Enter value"
        position="center"
        size={82.109375}
        summaryAggregationMode="none"
      />
      <ToolbarButton
        id="4d"
        icon="bold/interface-arrows-round-left"
        label="Refresh"
        type="custom"
      >
        <Event
          id="6605f2cd"
          event="clickToolbar"
          method="refresh"
          pluginId="transporterWarehousesTable"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
      <ToolbarButton
        id="584c3"
        hidden="{{ transporterWarehousesTable.selectedRow == null }}"
        icon="bold/interface-delete-bin-1"
        label="Delete"
        type="custom"
      >
        <Event
          id="33cccfe9"
          event="clickToolbar"
          method="run"
          params={{
            ordered: [
              {
                src: "await deleteTransporterWarehouse.trigger();\nawait transporterWarehousesTable.refresh();",
              },
            ],
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
    </Table>
    <TextInput
      id="transporterVehicleInput"
      disabled="{{ addTransporterVehicle.isFetching || getTransporterVehicles.isFetching }}"
      label="Vehicle Number"
      labelPosition="top"
      placeholder="Enter vehicle number"
    />
    <Select
      id="selectTransporterWarehouse"
      data="{{ getWarehousesForTransporter.data }}"
      disabled="{{ addTransporterWarehouse.isFetching || getTransporterWarehouses.isFetching }}"
      emptyMessage="No options"
      label="Warehouse"
      labelPosition="top"
      labels="{{ item.name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      values="{{ item.warehouse_id }}"
    />
    <Spacer id="spacer2" />
    <Spacer id="spacer1" />
    <Button
      id="addTransporterVehicleButton"
      disabled="{{ transporterVehicleInput.value.length == 0 }}"
      loading="{{ addTransporterVehicle.isFetching || getTransporterVehicles.isFetching }}"
      text="Add"
      tooltipText={
        '{{ transporterVehicleInput.value.length == 0? "Please enter a vehicle number": "" }}'
      }
    >
      <Event
        id="2347e906"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await addTransporterVehicleButton.setDisabled();\nawait addTransporterVehicle.trigger();\nawait transporterVehiclesTable.refresh();\nawait transporterVehicleInput.clearValue();\nawait addTransporterVehicleButton.setDisabled(false);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="addTransporterWarehouseButton"
      disabled="{{ selectTransporterWarehouse.value == null }}"
      loading="{{ addTransporterWarehouse.isFetching || getTransporterWarehouses.isFetching }}"
      text="Add"
      tooltipText={
        '{{ selectTransporterWarehouse.value == null?"Please select a warehouse": "" }}'
      }
    >
      <Event
        id="b4ce36aa"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await addTransporterWarehouseButton.setDisabled();\nawait addTransporterWarehouse.trigger();\nawait transporterWarehousesTable.refresh();\nawait selectTransporterWarehouse.clearValue();\nawait addTransporterWarehouseButton.setDisabled(false);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </View>
</Container>
