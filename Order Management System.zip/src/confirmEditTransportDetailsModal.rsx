<ModalFrame
  id="confirmEditTransportDetailsModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showOverlay={true}
>
  <Icon
    id="icon7"
    horizontalAlign="center"
    icon="bold/interface-alert-warning-triangle"
    style={{ map: { color: "highlight" } }}
  />
  <Text
    id="text77"
    horizontalAlign="center"
    value="##### Editing - Order-{{ selectedOrderId.value }}  _AFTER_   Invoice Creation"
    verticalAlign="center"
  />
  <Text
    id="text78"
    horizontalAlign="center"
    value="Are you sure you want to update the Order Details?
This action cannot be undone!

***It will regenerate Loading Slip and Update the existing Invoice***"
    verticalAlign="center"
  />
  <Button
    id="exitEditTransportDetailsButton"
    style={{}}
    styleVariant="outline"
    text="Exit"
  >
    <Event
      id="63d02d4d"
      event="click"
      method="hide"
      params={{}}
      pluginId="confirmEditTransportDetailsModal"
      type="widget"
      waitMs="0"
      waitType="debounce"
    />
  </Button>
  <Button
    id="editTransportDetailsConfirmButton"
    style={{ map: { background: "highlight" } }}
    text="Confirm"
  />
</ModalFrame>
