<ModalFrame
  id="collectPaymentModal"
  footerPadding="8px 12px"
  headerPadding="12px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showFooterBorder={false}
  showHeader={true}
  showHeaderBorder={false}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text id="modalTitle9" value="### Collect Payment" verticalAlign="center" />
    <Button
      id="modalCloseButton9"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ ordered: [{ border: "transparent" }] }}
      styleVariant="outline"
    >
      <Event
        id="73758f3c"
        event="click"
        method="setHidden"
        params={{ ordered: [{ hidden: true }] }}
        pluginId="collectPaymentModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <NumberInput
      id="amountCollectedInput"
      currency="INR"
      format="currency"
      inputValue={0}
      label="Amount Collected"
      labelPosition="top"
      max="{{ (getCashBillItems.data.total_price.reduce((sum, val) => sum + Number(val), 0)
) - (getCashPayments.data.amount.reduce((sum, val) => sum + Number(val), 0)) }}"
      placeholder="Enter value"
      preventScroll={true}
      showSeparators={true}
      value={0}
    />
    <TextInput
      id="receiptNumberInput"
      label="Receipt Number"
      labelPosition="top"
      placeholder="Enter receipt number"
    />
    <Date
      id="collectionDateInput"
      dateFormat="dd MMM yyyy"
      datePlaceholder="{{ self.dateFormat.toUpperCase() }}"
      iconBefore="bold/interface-calendar"
      label="Collection Date"
      labelPosition="top"
      value="{{ new Date() }}"
    />
  </Body>
  <Footer>
    <Button
      id="savePaymentButton"
      disabled={
        '{{ amountCollectedInput.value == 0 || receiptNumberInput.value == "" }}'
      }
      loaderPosition="right"
      loading="{{ addCashCollected.isFetching || getCashBillsPending.isFetching || getCashPayments.isFetching || getCashBillsCollected.isFetching}}"
      text="Save"
    >
      <Event
        id="54100143"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await savePaymentButton.setDisabled();\nawait addCashCollected.trigger();\nawait getCashBillsPending.trigger();\nawait cashCollectedTable.refresh();\nawait getCashBillsCollected.trigger()\nawait savePaymentButton.setDisabled(false);\nawait amountCollectedInput.clearValue();\nawait receiptNumberInput.clearValue();\nawait collectionDateInput.clearValue();\nawait collectPaymentModal.hide();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
