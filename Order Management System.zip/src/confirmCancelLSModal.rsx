<ModalFrame
  id="confirmCancelLSModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showOverlay={true}
>
  <Icon
    id="icon3"
    horizontalAlign="center"
    icon="bold/interface-alert-warning-triangle"
    style={{ map: { color: "danger" } }}
  />
  <Text
    id="text70"
    horizontalAlign="center"
    value="##### Cancel Loading Slip - LS-{{ loadingSlipItemsTable.selectedSourceRow.loading_slip_id }}"
    verticalAlign="center"
  />
  <Text
    id="text71"
    horizontalAlign="center"
    value="Are you sure you want to cancel the Loading Slip?
This action cannot be undone!"
    verticalAlign="center"
  />
  <Button
    id="cancelLoadingSlipConfirmButton"
    style={{ map: { background: "danger" } }}
    text="Cancel"
  >
    <Event
      id="3c01d8b5"
      event="click"
      method="run"
      params={{
        map: {
          src: "await cancelLoadingSlipConfirmButton.setDisabled();\nawait cancelLoadingSlip.trigger();\nawait cancelLoadingSlipNotification.trigger();\nawait getLoadingSlipItems.trigger();\nawait loadingSlipItemsTable.refresh();\nawait confirmCancelLSModal.setHidden();\nawait cancelLoadingSlipConfirmButton.setDisabled(false);",
        },
      }}
      pluginId=""
      type="script"
      waitMs="0"
      waitType="debounce"
    />
  </Button>
  <Button
    id="exitCancelLoadingSlipButton"
    style={{}}
    styleVariant="outline"
    text="Exit"
  >
    <Event
      id="63d02d4d"
      event="click"
      method="hide"
      params={{}}
      pluginId="confirmCancelLSModal"
      type="widget"
      waitMs="0"
      waitType="debounce"
    />
  </Button>
</ModalFrame>
