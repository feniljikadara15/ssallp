<Container
  id="tabbedContainer2"
  currentViewKey="{{ self.viewKeys[0] }}"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
  style={{ ordered: [] }}
>
  <Header>
    <Button
      id="exportOngoingButton"
      hidden="{{ orderStatusTabs.selectedLabel!='Ongoing' }}"
      iconBefore="bold/interface-download-button-2"
      text="Export"
      tooltipText="Export Ongoing Orders"
    >
      <Event
        id="1bf10bce"
        event="click"
        method="run"
        params={{
          map: {
            src: "const data = await ongoingOrderDetailsForExport.trigger();\nutils.exportData(\n  data,\n  `Ongoing Orders ${new Date().toLocaleString('en-GB', {\n    day: '2-digit', month: '2-digit', year: 'numeric',\n    hour: '2-digit', minute: '2-digit', hour12: true\n  })}`,\n  'csv'\n);",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Text id="text23" value="### Orders" verticalAlign="center" />
    <Button
      id="exportIntranitButton"
      hidden={'{{ orderStatusTabs.selectedLabel!="In-Transit" }}'}
      iconBefore="bold/interface-download-button-2"
      text="Export"
      tooltipText="Export In-Transit Orders"
    >
      <Event
        id="a8c7e799"
        event="click"
        method="run"
        params={{
          map: {
            src: "const data = await transitOrderDetailsForExport.trigger();\nutils.exportData(\n  data,\n  `In Transit Orders ${new Date().toLocaleString('en-GB', {\n    day: '2-digit', month: '2-digit', year: 'numeric',\n    hour: '2-digit', minute: '2-digit', hour12: true\n  })}`,\n  'csv'\n);",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="exportDeliveredButton"
      hidden={'{{ orderStatusTabs.selectedLabel!="Delivered" }}'}
      iconBefore="bold/interface-download-button-2"
      text="Export"
      tooltipText="Export Delivered Orders"
    >
      <Event
        id="80258221"
        event="click"
        method="run"
        params={{
          map: {
            src: "const data = await deliveredOrderDetailsForExport.trigger();\nutils.exportData(\n  data,\n  `Delivered Orders ${new Date().toLocaleString('en-GB', {\n    day: '2-digit', month: '2-digit', year: 'numeric',\n    hour: '2-digit', minute: '2-digit', hour12: true\n  })}`,\n  'csv'\n);",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Tabs
      id="orderStatusTabs"
      itemMode="static"
      navigateContainer={true}
      style={{}}
      targetContainerId="tabbedContainer2"
      value="{{ self.values[0] }}"
    >
      <Option id="57102" value="Tab 1" />
      <Option id="c4ff5" value="Tab 2" />
      <Option id="814f6" value="Tab 3" />
    </Tabs>
  </Header>
  <View id="a9d32" label="Ongoing">
    <DateRange
      id="ongoingOrdersDateRange"
      dateFormat="MMM d, yyyy"
      endPlaceholder="End date"
      iconBefore="bold/interface-calendar-remove"
      label="Filter By Date"
      labelPosition="top"
      maxDate="{{ new Date() }}"
      showClear={true}
      startPlaceholder="Start date"
      textBetween="-"
      value={{
        start: '{{ new Date().toISOString().split("T")[0] }}',
        end: '{{ new Date().toISOString().split("T")[0] }}',
      }}
    />
    <TextInput
      id="searchOngoingOrdersText"
      label=""
      labelPosition="top"
      placeholder="Search by Party Name"
    />
    <TextInput
      id="searchOngoingOrdersON"
      label=""
      labelPosition="top"
      pattern="^\d{4,5}$"
      patternType="regex"
      placeholder="Search by Order Number"
    />
    <TextInput
      id="searchOngoingOrdersLS"
      label=""
      labelPosition="top"
      pattern="^\d{4,5}$"
      patternType="regex"
      placeholder="Search by Loading Slip Number"
    />
    <ListViewBeta
      id="ordersOngoingListView"
      data={
        '{{\n  getOrders.data.order_id\n    .map((_, i) =>\n      Object.fromEntries(\n        Object.entries(getOrders.data).map(([key, value]) => [key, value[i]])\n      )\n    )\n    .filter(order => {\n      const startDate = ongoingOrdersDateRange.value?.start;\n      const endDate = ongoingOrdersDateRange.value?.end;\n\n      const searchText = (searchOngoingOrdersText.value || "")\n        .trim()\n        .toLowerCase();\n\n      const orderIdSearch = (searchOngoingOrdersON.value || "")\n        .trim();\n\n      const loadingSlipSearch = (searchOngoingOrdersLS.value || "")\n        .trim();\n\n      const ls_order_id =\n        loadingSlipSearch === ""\n          ? null\n          : getAllLoadingSlipItems.data.order_id[\n              getAllLoadingSlipItems.data.loading_slip_number.indexOf(\n                Number(loadingSlipSearch)\n              )\n            ];\n\n      const hasDirectSearch = orderIdSearch !== "" || loadingSlipSearch !== "";\n\n      const orderDate = new Date(order.order_date);\n      orderDate.setHours(0, 0, 0, 0);\n\n      const hasDates = startDate && endDate;\n      let start, end;\n\n      if (hasDates) {\n        start = new Date(startDate);\n        start.setHours(0, 0, 0, 0);\n        end = new Date(endDate);\n        end.setHours(23, 59, 59, 999);\n      }\n\n      const passesDateFilter =\n        hasDirectSearch || !hasDates || (orderDate >= start && orderDate <= end);\n\n      const customerIndex =\n        getCustomers.data.customer_id.indexOf(order.customer_id);\n\n      const customerName =\n        (getCustomers.data.name[customerIndex] || "").toLowerCase();\n\n      const passesCustomerSearch =\n        searchText === "" || customerName.includes(searchText);\n\n      const passesOrderIdSearch =\n        orderIdSearch === "" || String(order.order_id).includes(orderIdSearch);\n\n      const passesLoadingSlipSearch =\n        loadingSlipSearch === "" || order.order_id === ls_order_id;\n\n      const passesStatusFilter =\n        hasDirectSearch || String(order.order_status) === "1";\n\n      return (\n        order.order_status === "1" &&\n        passesStatusFilter &&\n        passesDateFilter &&\n        passesCustomerSearch &&\n        passesOrderIdSearch &&\n        passesLoadingSlipSearch\n      );\n    })\n}}'
      }
      itemWidth="200px"
      margin="0"
      maxHeight="100vh"
      numColumns={3}
      padding="0"
    >
      <Container
        id="container11"
        footerPadding="4px 12px"
        headerPadding="4px 12px"
        loading="false"
        padding="12px"
        showBody={true}
        style={{
          ordered: [
            {
              border:
                "{{ item.order_id == selectedOrderId.value?theme.primary:theme.surfacePrimaryBorder }}",
            },
            {
              background:
                "{{ item.order_id == selectedOrderId.value?theme.tertiary:theme.surfacePrimary }}",
            },
          ],
        }}
      >
        <Header>
          <Text
            id="containerTitle9"
            value="#### {{ item }}"
            verticalAlign="center"
          />
        </Header>
        <View id="77a98" viewKey="View 1">
          <IconText
            id="iconText4"
            icon="line/interface-file-clipboard-check"
            text="OD - {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(item.customer_id)] }} - {{ item.order_id }}"
          />
          <Text
            id="loadingSlipNumberOngoing"
            hidden=""
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="**{{getAllLoadingSlipItems.data.loading_slip_file_name[getAllLoadingSlipItems.data.order_id.indexOf(item.order_id)]}}**"
            verticalAlign="center"
          />
          <Text
            id="orderDateOngoing"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="**{{`${((d = item.order_date.split('T')[0].split('-')) && `${d[2]}-${d[1]}-${d[0]}`)}`}}**"
            verticalAlign="center"
          />
        </View>
        <Event
          id="5515770f"
          event="click"
          method="run"
          params={{
            ordered: [
              { src: "await selectedOrderId.setValue(item.order_id);" },
            ],
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </Container>
    </ListViewBeta>
  </View>
  <View id="e1ad8" label="In-Transit">
    <DateRange
      id="transitOrdersDateRange"
      dateFormat="MMM d, yyyy"
      endPlaceholder="End date"
      iconBefore="bold/interface-calendar-remove"
      label="Filter By Date"
      labelPosition="top"
      maxDate="{{ new Date() }}"
      showClear={true}
      startPlaceholder="Start date"
      textBetween="-"
      value={{
        start: '{{ new Date().toISOString().split("T")[0] }}',
        end: '{{ new Date().toISOString().split("T")[0] }}',
      }}
    />
    <TextInput
      id="searchTransitOrdersText"
      label=""
      labelPosition="top"
      placeholder="Search by Party Name"
    />
    <TextInput
      id="searchTransitOrdersON"
      label=""
      labelPosition="top"
      pattern="^\d{4,5}$"
      patternType="regex"
      placeholder="Search by Order Number"
    />
    <TextInput
      id="searchTransitOrdersLS"
      label=""
      labelPosition="top"
      pattern="^\d{4,5}$"
      patternType="regex"
      placeholder="Search by Loading Slip Number"
    />
    <ListViewBeta
      id="ordersTransitListView"
      data={
        '{{\n  getOrders.data.order_id\n    .map((_, i) =>\n      Object.fromEntries(\n        Object.entries(getOrders.data).map(([key, value]) => [key, value[i]])\n      )\n    )\n    .filter(order => {\n      const startDate = transitOrdersDateRange.value?.start;\n      const endDate = transitOrdersDateRange.value?.end;\n\n      const searchText = (searchTransitOrdersText.value || "")\n        .trim()\n        .toLowerCase();\n\n      const orderIdSearch = (searchTransitOrdersON.value || "")\n        .trim();\n\n      const ls_order_id =\n        getAllLoadingSlipItems.data.order_id[\n          getAllLoadingSlipItems.data.loading_slip_number.indexOf(\n            Number(searchTransitOrdersLS.value)\n          )\n        ];\n\n      // --- Date filtering ---\n      const orderDate = new Date(order.order_date);\n      orderDate.setHours(0, 0, 0, 0);\n\n      const hasDates = startDate && endDate;\n      let start, end;\n\n      if (hasDates) {\n        start = new Date(startDate);\n        start.setHours(0, 0, 0, 0);\n        end = new Date(endDate);\n        end.setHours(23, 59, 59, 999);\n      }\n\n      const passesDateFilter =\n        !hasDates || (orderDate >= start && orderDate <= end);\n\n      // --- Customer name lookup ---\n      const customerIndex =\n        getCustomers.data.customer_id.indexOf(order.customer_id);\n\n      const customerName =\n        (getCustomers.data.name[customerIndex] || "").toLowerCase();\n\n      const passesCustomerSearch =\n        searchText === "" || customerName.includes(searchText);\n\n      // --- Order ID text search ---\n      const passesOrderIdSearch =\n        orderIdSearch === "" ||\n        String(order.order_id).includes(orderIdSearch);\n\n      // --- Loading Slip → Order filter ---\n      const passesLoadingSlipFilter =\n        !searchTransitOrdersLS.value ||\n        order.order_id === ls_order_id;\n\n      return (\n        order.order_status === "2" &&\n        passesDateFilter &&\n        passesCustomerSearch &&\n        passesOrderIdSearch &&\n        passesLoadingSlipFilter\n      );\n    })\n}}\n'
      }
      itemWidth="200px"
      margin="0"
      numColumns={3}
      padding="0"
    >
      <Container
        id="container12"
        footerPadding="4px 12px"
        headerPadding="4px 12px"
        padding="12px"
        showBody={true}
        style={{
          ordered: [
            {
              background:
                "{{ item.order_id == selectedOrderId.value?theme.tertiary:theme.surfacePrimary }}",
            },
            {
              border:
                "{{ item.order_id == selectedOrderId.value?theme.primary:theme.surfacePrimaryBorder }}",
            },
          ],
        }}
      >
        <Header>
          <Text
            id="containerTitle10"
            value="#### {{ item }}"
            verticalAlign="center"
          />
        </Header>
        <View id="77a98" viewKey="View 1">
          <IconText
            id="iconText5"
            icon="line/interface-file-clipboard-check"
            text="OD - {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(item.customer_id)] }} - {{ item.order_id }}"
          />
          <Text
            id="orderDateTransit"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="**{{`${((d = item.order_date.split('T')[0].split('-')) && `${d[2]}-${d[1]}-${d[0]}`)}`}}**"
            verticalAlign="center"
          />
          <Text
            id="loadingSlipNumberTransit"
            horizontalAlign="right"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="**{{getAllLoadingSlipItems.data.loading_slip_file_name[getAllLoadingSlipItems.data.order_id.indexOf(item.order_id)]}}**"
            verticalAlign="center"
          />
        </View>
        <Event
          id="da62ad2f"
          event="click"
          method="run"
          params={{
            ordered: [
              { src: "await selectedOrderId.setValue(item.order_id);" },
            ],
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </Container>
    </ListViewBeta>
  </View>
  <View id="41817" label="Delivered">
    <DateRange
      id="deliveredOrdersDateRange"
      dateFormat="MMM d, yyyy"
      endPlaceholder="End date"
      iconBefore="bold/interface-calendar-remove"
      label="Filter By Date"
      labelPosition="top"
      maxDate="{{ new Date() }}"
      showClear={true}
      startPlaceholder="Start date"
      textBetween="-"
      value={{
        start: '{{ new Date().toISOString().split("T")[0] }}',
        end: '{{ new Date().toISOString().split("T")[0] }}',
      }}
    />
    <TextInput
      id="searchDeliveredOrdersText"
      label=""
      labelPosition="top"
      placeholder="Search by Party Name"
    />
    <TextInput
      id="searchDeliveredOrdersON"
      label=""
      labelPosition="top"
      pattern="^\d{4,5}$"
      patternType="regex"
      placeholder="Search by Order Number"
    />
    <TextInput
      id="searchDeliveredOrdersLS"
      label=""
      labelPosition="top"
      pattern="^\d{4,5}$"
      patternType="regex"
      placeholder="Search by Loading Slip Number"
    />
    <ListViewBeta
      id="ordersDeliveredListView"
      data={
        '{{\n  getOrders.data.order_id\n    .map((_, i) =>\n      Object.fromEntries(\n        Object.entries(getOrders.data).map(([key, value]) => [key, value[i]])\n      )\n    )\n    .filter(order => {\n      const startDate = deliveredOrdersDateRange.value?.start;\n      const endDate = deliveredOrdersDateRange.value?.end;\n\n      const searchText = (searchDeliveredOrdersText.value || "")\n        .trim()\n        .toLowerCase();\n\n      const orderIdSearch = (searchDeliveredOrdersON.value || "")\n        .trim();\n\n      const ls_order_id =\n        getAllLoadingSlipItems.data.order_id[\n          getAllLoadingSlipItems.data.loading_slip_number.indexOf(\n            Number(searchDeliveredOrdersLS.value)\n          )\n        ];\n\n      // --- Date filtering ---\n      const orderDate = new Date(order.order_date);\n      orderDate.setHours(0, 0, 0, 0);\n\n      const hasDates = startDate && endDate;\n      let start, end;\n\n      if (hasDates) {\n        start = new Date(startDate);\n        start.setHours(0, 0, 0, 0);\n        end = new Date(endDate);\n        end.setHours(23, 59, 59, 999);\n      }\n\n      const passesDateFilter =\n        !hasDates || (orderDate >= start && orderDate <= end);\n\n      // --- Customer name lookup ---\n      const customerIndex =\n        getCustomers.data.customer_id.indexOf(order.customer_id);\n\n      const customerName =\n        (getCustomers.data.name[customerIndex] || "").toLowerCase();\n\n      const passesCustomerSearch =\n        searchText === "" || customerName.includes(searchText);\n\n      // --- Order ID text filter ---\n      const passesOrderIdSearch =\n        orderIdSearch === "" ||\n        String(order.order_id).includes(orderIdSearch);\n\n      // --- Loading Slip → Order filter ---\n      const passesLoadingSlipFilter =\n        !searchDeliveredOrdersLS.value ||\n        order.order_id === ls_order_id;\n\n      return (\n        order.order_status === "3" &&\n        passesDateFilter &&\n        passesCustomerSearch &&\n        passesOrderIdSearch &&\n        passesLoadingSlipFilter\n      );\n    })\n}}\n'
      }
      itemWidth="200px"
      margin="0"
      numColumns={3}
      padding="0"
    >
      <Container
        id="container13"
        footerPadding="4px 12px"
        headerPadding="4px 12px"
        padding="12px"
        showBody={true}
        style={{
          ordered: [
            {
              border:
                "{{ item.order_id == selectedOrderId.value?theme.primary:theme.surfacePrimaryBorder }}",
            },
            {
              background:
                "{{ item.order_id == selectedOrderId.value?theme.tertiary:theme.surfacePrimary }}",
            },
          ],
        }}
      >
        <Header>
          <Text
            id="containerTitle11"
            value="#### {{ item }}"
            verticalAlign="center"
          />
        </Header>
        <View id="77a98" viewKey="View 1">
          <IconText
            id="iconText6"
            icon="line/interface-file-clipboard-check"
            text="OD - {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(item.customer_id)] }} - {{ item.order_id }}"
          />
          <Text
            id="text26"
            horizontalAlign="right"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="**{{`${((d = item.order_date.split('T')[0].split('-')) && `${d[2]}-${d[1]}-${d[0]}`)}`}}**"
            verticalAlign="center"
          />
        </View>
        <Event
          id="a6111d92"
          event="click"
          method="run"
          params={{
            ordered: [
              { src: "await selectedOrderId.setValue(item.order_id);" },
            ],
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </Container>
    </ListViewBeta>
  </View>
  <View
    id="c3ba3"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Deleted"
  >
    <ListViewBeta
      id="ordersDeletedListView"
      data={
        '{{getOrders.data.order_id.map((_, i) =>\n  Object.fromEntries(\n    Object.entries(getOrders.data).map(([key, value]) => [key, value[i]])\n  )\n).filter(order => order.order_status === "5")}}'
      }
      itemWidth="200px"
      margin="0"
      numColumns={3}
      padding="0"
    >
      <Container
        id="container37"
        footerPadding="4px 12px"
        headerPadding="4px 12px"
        padding="12px"
        showBody={true}
        style={{
          ordered: [
            {
              border:
                "{{ item.order_id == selectedOrderId.value?theme.primary:theme.surfacePrimaryBorder }}",
            },
            {
              background:
                "{{ item.order_id == selectedOrderId.value?theme.tertiary:theme.surfacePrimary }}",
            },
          ],
        }}
      >
        <Header>
          <Text
            id="containerTitle33"
            value="#### {{ item }}"
            verticalAlign="center"
          />
        </Header>
        <View id="77a98" viewKey="View 1">
          <IconText
            id="iconText11"
            icon="line/interface-file-clipboard-check"
            text="OD - {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(item.customer_id)] }} - {{ item.order_id }}"
          />
          <Text
            id="text59"
            horizontalAlign="right"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="**{{`${((d = item.order_date.split('T')[0].split('-')) && `${d[2]}-${d[1]}-${d[0]}`)}`}}**"
            verticalAlign="center"
          />
        </View>
        <Event
          id="09dd1468"
          event="click"
          method="run"
          params={{
            ordered: [
              { src: "await selectedOrderId.setValue(item.order_id);" },
            ],
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </Container>
    </ListViewBeta>
  </View>
</Container>
