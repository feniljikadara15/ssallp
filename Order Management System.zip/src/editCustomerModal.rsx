<ModalFrame
  id="editCustomerModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="large"
>
  <Header>
    <Text
      id="modalTitle15"
      value="#### Edit Customer - {{ customersTable.selectedSourceRow.name }} [{{ customersTable.selectedSourceRow.zb_customer_id }}]"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton16"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="c9a6ca41"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="editCustomerModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <PhoneNumberInput
      id="customerPhoneNumber"
      inputTooltip="Country Code Mandatory!"
      label="Phone
"
      labelPosition="top"
      lockedCountryCode="US"
      value="{{ customersTable.selectedSourceRow.phone }}"
    />
    <TextInput
      id="customerName"
      label="Name"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ customersTable.selectedSourceRow.name }}"
    />
    <TextInput
      id="customerEmail"
      iconBefore="bold/mail-send-envelope"
      label="Email"
      labelPosition="top"
      patternType="email"
      value="{{ customersTable.selectedSourceRow.email }}"
    />
    <PhoneNumberInput
      id="customerAdditionalPhone1"
      label="Additional Phone 1"
      labelPosition="top"
      lockedCountryCode="US"
      value="{{ customersTable.selectedSourceRow.additional_phone_1 }}"
    />
    <PhoneNumberInput
      id="customerAdditionalPhone2"
      label="Additional Phone 2"
      labelPosition="top"
      lockedCountryCode="US"
      value="{{ customersTable.selectedSourceRow.additional_phone_2 }}"
    />
    <TextInput
      id="customerGST"
      label="GST"
      labelPosition="top"
      value="{{ customersTable.selectedSourceRow.gstin }}"
    />
    <TextInput
      id="customerPAN"
      label="PAN"
      labelPosition="top"
      value="{{ customersTable.selectedSourceRow.pan }}"
    />
    <TextInput
      id="customerType"
      hidden="true"
      label="Customer Type"
      labelPosition="top"
      value="{{ customersTable.selectedSourceRow.customer_type }}"
    />
    <TextArea
      id="customerRemarks"
      autoResize={true}
      hidden="true"
      label="Remarks"
      labelPosition="top"
      minLines="1"
      value="{{ customersTable.selectedSourceRow.remarks }}"
    />
    <Checkbox
      id="customerTCS"
      hidden="true"
      label="TCS Applicability"
      labelWidth="100"
      value="{{ customersTable.selectedSourceRow.tcs_status }}"
    />
    <Checkbox
      id="customerActive"
      hidden=""
      label="Customer Active"
      labelWidth="100"
      value="{{ customersTable.selectedSourceRow.is_active }}"
    />
    <Text id="text67" value="##### Billing Address" verticalAlign="center" />
    <Divider id="divider11" />
    <TextInput
      id="editBillingAddressLine1"
      label="Address Line 1"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ getCustomerBillingAddress.data.line1[0] }}"
    />
    <TextInput
      id="editBillingAddressLine2"
      label="Address Line 2"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ getCustomerBillingAddress.data.line2[0] }}"
    />
    <NumberInput
      id="billingAddressPincode"
      currency="USD"
      inputValue={0}
      label="Pincode"
      labelPosition="top"
      placeholder="Enter value"
      preventScroll={true}
      value="{{ getCustomerBillingAddress.data.pincode[0] }}"
    />
    <TextInput
      id="billingAddressCIty"
      label="City"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ getCustomerBillingAddress.data.city[0] }}"
    />
    <Select
      id="billingAddressState"
      data="{{ getStateCodes.data }}"
      emptyMessage="No options"
      label="State"
      labelPosition="top"
      labels="{{ item.state_name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value="{{ getCustomerBillingAddress.data.state[0] }}"
      values="{{ item.state_name }}"
    />
    <Text id="text66" value="##### Site Details" verticalAlign="center" />
    <Button id="AddSiteModalOpenBUtton" text="Add Site">
      <Event
        id="1022dbda"
        event="click"
        method="show"
        params={{}}
        pluginId="addSiteModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Divider id="divider10" />
    <Table
      id="customerSitesTable"
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ getCustomersSItes.data }}"
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      heightType="auto"
      primaryKeyColumnId="9cbd3"
      showBorder={true}
      showColumnBorders={true}
      showFooter={true}
      showHeader={true}
      toolbarPosition="bottom"
    >
      <Column
        id="7fd98"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="site_name"
        label="Site Name"
        placeholder="Enter value"
        position="center"
        size={71.28125}
        summaryAggregationMode="none"
      />
      <Column
        id="6d28a"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="site_person_name"
        label="Site Person Name"
        placeholder="Enter value"
        position="center"
        size={111.84375}
        summaryAggregationMode="none"
      />
      <Column
        id="48ee0"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="city"
        label="City"
        placeholder="Enter value"
        position="center"
        size={96.796875}
        summaryAggregationMode="none"
      />
      <Column
        id="f9cbc"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="pincode"
        label="Pincode"
        placeholder="Enter value"
        position="center"
        size={59.375}
        summaryAggregationMode="none"
      />
      <Column
        id="25389"
        alignment="center"
        format="link"
        formatOptions={{ showUnderline: "hover", underlineStyle: "solid" }}
        groupAggregationMode="none"
        key="maps_link"
        label="Google Map Link"
        position="center"
        size={105.671875}
        summaryAggregationMode="none"
      >
        <Event
          id="1b9856d4"
          event="clickCell"
          method="openUrl"
          params={{ map: { url: "{{ item }}" } }}
          pluginId=""
          type="util"
          waitMs="0"
          waitType="debounce"
        />
      </Column>
      <Column
        id="5fd45"
        alignment="center"
        format="boolean"
        groupAggregationMode="none"
        key="is_active"
        label="Is active"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="46307"
        alignment="center"
        format="button"
        formatOptions={{ variant: "solid" }}
        groupAggregationMode="none"
        label="Action"
        placeholder="Enter value"
        position="center"
        referenceId="act"
        size={50.421875}
        summaryAggregationMode="none"
        valueOverride="Edit"
      >
        <Event
          id="cf7a69cc"
          event="clickCell"
          method="show"
          params={{}}
          pluginId="siteDetailsModalEdit"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </Column>
      <Column
        id="9cbd3"
        alignment="right"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="site_id"
        label="Site ID"
        placeholder="Enter value"
        position="center"
        size={50.4375}
        summaryAggregationMode="none"
      />
    </Table>
  </Body>
  <Footer>
    <Button
      id="saveCustomerDetailsButton"
      disabled="{{ updateCustomer.isFetching }}"
      loaderPosition="left"
      loading="{{ updateCustomer.isFetching }}"
      text="Save"
    >
      <Event
        id="e31ab2bf"
        event="click"
        method="run"
        params={{
          map: {
            src: "await updateCustomer.trigger();\nawait updateAddressBilling.trigger();\nawait getCustomers.trigger();\nawait customersTable.refresh();\nawait editCustomerModal.setHidden();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
