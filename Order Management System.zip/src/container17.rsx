<Container
  id="container17"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  hoistFetching={true}
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
>
  <Header>
    <Text
      id="containerTitle15"
      value="#### Transport Details"
      verticalAlign="center"
    />
    <Button
      id="editTransportDetailsButton"
      hidden="{{getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '999'}}"
      text="Edit Details"
    >
      <Event
        id="d8d6e686"
        event="click"
        method="show"
        params={{}}
        pluginId="editTransportDetailsModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Text
      id="text34"
      value="Assign a transporter and set delivery details"
      verticalAlign="center"
    />
  </Header>
  <View id="472d8" viewKey="View 1">
    <Select
      id="selectTransporter2"
      captionByIndex=""
      data="{{ getTransportersWarehouseOrder.data }}"
      disabled="{{ updateWarehouse2.isFetching || updateTransporter2.isFetching || updatePoNumber.isFetching || updateSubDealer.isFetching || getOrders.isFetching || selectWarehouse2.value == null }}"
      emptyMessage="No options"
      hidden=""
      iconBefore="bold/shipping-transfer-truck"
      label="Transporter"
      labelPosition="top"
      labels="{{ item.transporter_name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      readOnly="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      required={true}
      showSelectionIndicator={true}
      value="{{ getOrders.data.transporter_id[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}"
      values="{{ item.transporter_id }}"
    />
    <Select
      id="selectWarehouse2"
      data="{{ getWarehouses.data }}"
      disabled="{{ updateWarehouse2.isFetching || updateTransporter2.isFetching || updatePoNumber.isFetching || updateSubDealer.isFetching || getOrders.isFetching }}"
      emptyMessage="No options"
      iconBefore="bold/shipping-warehouse"
      label="Warehouse"
      labelPosition="top"
      labels="{{ item.name }}"
      overlayMaxHeight={375}
      placeholder="Select a warehouse"
      readOnly="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      required={true}
      showSelectionIndicator={true}
      value="{{ getOrders.data.warehouse_id[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}"
      values="{{ item.warehouse_id }}"
    />
    <Select
      id="selectDeliveryTerms"
      emptyMessage="No options"
      itemMode="static"
      label="Delivery Terms"
      labelPosition="top"
      overlayMaxHeight={375}
      placeholder="Select an option"
      required={true}
      showSelectionIndicator={true}
      value="{{ getOrders.data.delivery_terms[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}"
    >
      <Option id="00030" value="Delivery" />
      <Option id="00031" value="Ex warehouse" />
    </Select>
    <Select
      id="selectVehicleNumber"
      data="{{ getVehicleNumber.data }}"
      disabled="{{ updateWarehouse2.isFetching || updateTransporter2.isFetching || updatePoNumber.isFetching || updateSubDealer.isFetching || getOrders.isFetching }}"
      emptyMessage="No options"
      label="Vehicle Number"
      labelPosition="top"
      labels="{{ item.vehicle_number }}"
      overlayMaxHeight={375}
      placeholder="Select a vehicle"
      readOnly="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      required={true}
      showClear={true}
      showSelectionIndicator={true}
      value="{{ getOrders.data.vehicle_id[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}"
      values="{{ item.vehicle_id }}"
    >
      <Event
        id="8df57504"
        event="inputValueChange"
        method="setValue"
        params={{ map: { value: "{{ selectVehicleNumber.inputValue }}" } }}
        pluginId="storeVehicleNumber"
        type="state"
        waitMs="0"
        waitType="debounce"
      />
    </Select>
    <Button
      id="notifyTransporterButton3"
      disabled="{{ selectWarehouse2.value.length ==0 || selectTransporter2.value.length == 0 || selectVehicleNumber.value.length == 0 }}"
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      iconBefore="bold/interface-alert-alarm-bell-1"
      style={{ map: { background: "info" } }}
      text="Notify Transporter"
    >
      <Event
        id="8e9e4a96"
        event="click"
        method="run"
        params={{ ordered: [{ src: "await notifyTransporter.trigger()" }] }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="addVehicleNumberButton"
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' || getVehicleNumber.data.vehicle_id?.includes(selectVehicleNumber.value)  }}"
      loading="{{ addVehicleNumberToTransporter.isFetching }}"
      text="Add New Vehicle Number"
      tooltipText="If Vehicle number is not there pease add"
    >
      <Event
        id="47fc0d00"
        event="click"
        method="show"
        params={{}}
        pluginId="addNewVehicleModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </View>
</Container>
