<ModalFrame
  id="editCompanyModalUpdate"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="modalTitle21"
      value="#### Edit Company Warehouse"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton22"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="eba2c0aa"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="editCompanyModalUpdate"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="editCompanyNameInput"
      label="Company Name"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ getWarehouseCompaniesDetails.selectedSourceRow.company_name }}"
    />
    <TextInput
      id="editCompanyCountry"
      label="Country"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ getWarehouseCompaniesDetails.selectedSourceRow.country}}"
    />
    <TextInput
      id="editCompanyState"
      label="State"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ getWarehouseCompaniesDetails.selectedSourceRow.state}}"
    />
    <TextInput
      id="editCompanyCity"
      label="City"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ getWarehouseCompaniesDetails.selectedSourceRow.city}}"
    />
    <TextArea
      id="editCompanyAddressLine1"
      autoResize={true}
      label="Address Line 1"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
      value="{{ getWarehouseCompaniesDetails.selectedSourceRow.address_line1}}"
    />
    <TextArea
      id="editcompanyAddressLine2"
      autoResize={true}
      label="Address Line 2"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
      value="{{ getWarehouseCompaniesDetails.selectedSourceRow.address_line2}}"
    />
    <TextInput
      id="editCompanyPincode"
      label="Pincode"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ getWarehouseCompaniesDetails.selectedSourceRow.pincode}}"
    />
  </Body>
  <Footer>
    <Button
      id="deleteCompanyWarehouseButton"
      style={{}}
      styleVariant="outline"
      text="Delete"
    >
      <Event
        id="0c10a66b"
        event="click"
        method="run"
        params={{
          map: {
            src: "await deleteCompanies.trigger();\nawait editCompanyModalUpdate.setHidden();\nawait getWarehouseCompanies.trigger();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button id="updateCompanyButton" text="Update">
      <Event
        id="ea6f63d6"
        event="click"
        method="run"
        params={{
          map: {
            src: "await updateCompanies.trigger();\nawait editCompanyModalUpdate.setHidden();\nawait getWarehouseCompanies.trigger();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
