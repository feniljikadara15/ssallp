<ModalFrame
  id="deleteProductModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showOverlay={true}
>
  <Header>
    <Text
      id="modalTitle14"
      value="### Container title"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton15"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="0301df3d"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="deleteProductModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Icon
      id="icon1"
      horizontalAlign="center"
      icon="line/interface-alert-warning-triangle"
      style={{ map: { color: "danger" } }}
    />
    <Text
      id="text62"
      horizontalAlign="center"
      value="###### Are you sure you want to permanently delete **{{ productsTable.selectedSourceRow.product_name }}** ?"
      verticalAlign="center"
    />
    <Button
      id="deleteProductConfirmButton"
      disabled="{{ deleteProduct.isFetching }}"
      loaderPosition="left"
      loading="{{ deleteProduct.isFetching }}"
      style={{ map: { background: "rgba(189, 39, 8, 1)" } }}
      text="Delete"
    >
      <Event
        id="e38739a1"
        event="click"
        method="run"
        params={{
          map: {
            src: "await deleteProductZB.trigger();\nawait deleteProduct.trigger();\nawait deleteProductModal.setHidden();\nawait editProductModal.setHidden()\nawait getAllProducts.trigger();\nawait productsTable.refresh();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="cancelDeleteProductButton"
      style={{}}
      styleVariant="outline"
      text="Cancel"
    >
      <Event
        id="3ce6cee7"
        event="click"
        method="hide"
        params={{}}
        pluginId="deleteProductModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Body>
</ModalFrame>
