<ModalFrame
  id="addWarehouseKeeperModal"
  footerPadding="12px 12px"
  headerPadding="12px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showFooterBorder={false}
  showHeader={true}
  showHeaderBorder={false}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="modalTitle12"
      value="### New Warehouse Keeper"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton12"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ ordered: [{ border: "transparent" }] }}
      styleVariant="outline"
    >
      <Event
        id="ff424fd1"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await warehouseKeeperNameInput.clearValue();\nawait warehouseKeeperPhoneInput.clearValue();\nawait selectKeeperWarehouse.clearValue();\nawait addWarehouseKeeperModal.hide();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="warehouseKeeperNameInput"
      label="Name"
      labelPosition="top"
      placeholder="Enter name"
    />
    <PhoneNumberInput
      id="warehouseKeeperPhoneInput"
      _lockSelectedCountry={true}
      label="Phone"
      labelPosition="top"
      lockedCountryCode="IN"
    />
    <Select
      id="selectKeeperWarehouse"
      data="{{ getWarehouses.data }}"
      emptyMessage="No options"
      label="Warehouse"
      labelPosition="top"
      labels="{{ item.name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      values="{{ item.warehouse_id }}"
    />
  </Body>
  <Footer>
    <Button
      id="saveWarehouseKeeperButton"
      disabled="{{ getWarehouseKeepers.isFetching || addWarehouseKeeper.isFetching || warehouseKeeperNameInput.value.length == 0 || warehouseKeeperPhoneInput.value.length ==3 || selectKeeperWarehouse.value == null }}"
      text="Save"
    >
      <Event
        id="6edb9100"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await addWarehouseKeeper.trigger();\nawait getWarehouseKeepers.trigger();\nawait addWarehouseKeeperModal.hide();\nawait warehouseKeeperNameInput.clearValue();\nawait warehouseKeeperPhoneInput.clearValue();\nawait selectKeeperWarehouse.clearValue();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
