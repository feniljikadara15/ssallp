<ModalFrame
  id="addSiteModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showHeader={true}
  showOverlay={true}
  size="large"
>
  <Header>
    <Text id="modalTitle26" value="### Add Site " verticalAlign="center" />
    <Button
      id="modalCloseButton27"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="e31c6dc5"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="addSiteModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <PhoneNumberInput
      id="addCustomerSItePersonContact"
      label="Site Person Contact"
      labelPosition="top"
      lockedCountryCode="US"
    />
    <TextInput
      id="AddCustomerSiteName"
      label="Site Name"
      labelPosition="top"
      placeholder="Enter value"
    />
    <TextInput
      id="addCustomerSItePersonName"
      label="Site Person Name"
      labelPosition="top"
      placeholder="Enter value"
    />
    <TextArea
      id="addSiteAddressLane1"
      autoResize={true}
      label="Address Lane 1"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
    />
    <Select
      id="addSiteState"
      data="{{ getStateCodes.data }}"
      emptyMessage="No options"
      label="State"
      labelPosition="top"
      labels="{{ item.state_name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      values="{{ item.state_name }}"
    />
    <TextInput
      id="addSiteCity"
      label="City"
      labelPosition="top"
      placeholder="Enter value"
    />
    <TextArea
      id="addSiteAddressLane2"
      autoResize={true}
      label="Address Lane 2"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
    />
    <TextInput
      id="addSiteMapLink"
      label="Map Link"
      labelPosition="top"
      placeholder="Enter value"
    />
    <NumberInput
      id="addSItePincode"
      currency="USD"
      inputValue={0}
      label="Pincode"
      labelPosition="top"
      placeholder="Enter value"
      preventScroll={true}
      value=""
    />
    <Button
      id="button8"
      loading="{{ AddCustomerAdress.isFetching || AddCustomerSiteDetails.isFetching }}"
      text="Save"
    >
      <Event
        id="b156dd3e"
        event="click"
        method="run"
        params={{
          map: {
            src: "await AddCustomerAdress.trigger();\nawait AddCustomerSiteDetails.trigger();\nawait addSiteModal.setHidden();\nawait customersTable.refresh();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Body>
</ModalFrame>
