<Screen
  id="cashBills"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={5}
  _searchParams={[{ ordered: [{ key: "_embed" }, { value: "true" }] }]}
  browserTitle=""
  title="Cash Bills"
  urlSlug=""
  uuid="c2729bd3-ec80-41df-9698-977430d8b9e0"
>
  <Folder id="manageCashBillItem">
    <SqlQueryUnified
      id="getCashPayments"
      isHidden={false}
      query={include("../lib/getCashPayments.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="addCashCollected"
      isHidden={false}
      query={include("../lib/addCashCollected.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showFailureToaster={false}
      successMessage="Cash Collection Recorded Successfully"
      warningCodes={[]}
    />
  </Folder>
  <Folder id="getCashBills">
    <SqlQueryUnified
      id="getCashBillItems"
      isHidden={false}
      query={include("../lib/getCashBillItems.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="getCashBillsCollected"
      isHidden={false}
      query={include("../lib/getCashBillsCollected.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <State id="selectedCashBillId" />
    <SqlQueryUnified
      id="getCashBillsPending"
      isHidden={false}
      isMultiplayerEdited={false}
      query={include("../lib/getCashBillsPending.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <JavascriptQuery
      id="query17"
      notificationDuration={4.5}
      query={include("../lib/query17.js", "string")}
      resourceName="JavascriptQuery"
      showSuccessToaster={false}
    />
  </Folder>
  <Folder id="exportCashData">
    <SqlQueryUnified
      id="getCashPendingExportData"
      query={include("../lib/getCashPendingExportData.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showFailureToaster={false}
      showSuccessToaster={false}
      warningCodes={[]}
    >
      <Event
        id="39fdabc3"
        event="success"
        method="run"
        params={{
          map: {
            src: "await utils.exportData(\n  getCashPendingExportData.data,\n  `Cash Bills Pending - ${new Date().toLocaleString('en-GB', { \n  day: '2-digit', month: '2-digit', year: 'numeric', \n  hour: '2-digit', minute: '2-digit', hour12: true \n})}`,\n  \"xlsx\",\n  {sheetName:\"Cash Bills Pending\"});",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </SqlQueryUnified>
    <SqlQueryUnified
      id="getCashCollectedDetailsExport"
      isMultiplayerEdited={false}
      query={include("../lib/getCashCollectedDetailsExport.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="getCashCollectedExportData"
      query={include("../lib/getCashCollectedExportData.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      warningCodes={[]}
    />
  </Folder>
  <Include src="./collectPaymentModal.rsx" />
  <Frame
    id="$main6"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <Include src="./container30.rsx" />
    <Include src="./container32.rsx" />
    <Container
      id="skeletonImageOrders2"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      hidden="{{ selectedCashBillId.value != null }}"
      margin="0"
      padding="0"
      showBody={true}
      showBorder={false}
      style={{ ordered: [{ background: "rgba(255, 255, 255, 0)" }] }}
    >
      <View id="9adee" viewKey="View 1">
        <Image
          id="image6"
          heightType="fixed"
          horizontalAlign="center"
          retoolStorageFileId="b98ba2aa-e879-4e27-ae7d-83ebc600eb47"
          src="https://picsum.photos/id/1025/800/600"
          srcType="retoolStorageFileId"
        />
        <Text
          id="text57"
          horizontalAlign="center"
          value="###### Select a cash bill to view details"
          verticalAlign="center"
        />
      </View>
    </Container>
  </Frame>
</Screen>
