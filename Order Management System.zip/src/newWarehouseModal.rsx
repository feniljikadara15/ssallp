<ModalFrame
  id="newWarehouseModal"
  footerPadding="12px 12px"
  headerPadding="12px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showFooterBorder={false}
  showHeader={true}
  showHeaderBorder={false}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text id="modalTitle5" value="### New Warehouse" verticalAlign="center" />
    <Button
      id="modalCloseButton5"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ ordered: [{ border: "transparent" }] }}
      styleVariant="outline"
    >
      <Event
        id="8c091b4d"
        event="click"
        method="setHidden"
        params={{ ordered: [{ hidden: true }] }}
        pluginId="newWarehouseModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="newWarehouseNameInput"
      label="Warehouse Name"
      labelPosition="top"
      placeholder="Enter value"
    />
    <TextInput
      id="newWarehouseLocationInput"
      label="Location"
      labelPosition="top"
      placeholder="Enter value"
    />
  </Body>
  <Footer>
    <Button id="addNewWarehouseButton" text="Save">
      <Event
        id="20090fb8"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await addNewWarehouseButton.setDisabled();\nawait addNewWarehouse.trigger();\nawait getWarehouses.trigger();\nawait selectedWarehouseId.setValue(addNewWarehouse.data.warehouse_id[0]);\nawait addNewWarehouseButton.setDisabled(false);\nawait newWarehouseModal.hide();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
