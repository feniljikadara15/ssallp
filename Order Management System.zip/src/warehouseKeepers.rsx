<Screen
  id="warehouseKeepers"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={7}
  _searchParams={[{ ordered: [{ key: "_embed" }, { value: "true" }] }]}
  browserTitle="Warehouse Keepers"
  title="Warehouse Keepers"
  urlSlug=""
  uuid="61d51559-0b26-4dc5-af96-7ca60b4493e4"
>
  <SqlQueryUnified
    id="deleteWarehouseKeeper"
    notificationDuration={4.5}
    query={include("../lib/deleteWarehouseKeeper.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="addWarehouseKeeper"
    isMultiplayerEdited={false}
    notificationDuration="2"
    query={include("../lib/addWarehouseKeeper.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    successMessage="Warehouse Keeper Added"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="updateWarehouseKeeper"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/updateWarehouseKeeper.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <Include src="./addWarehouseKeeperModal.rsx" />
  <Include src="./editWarehouseKeepersModal.rsx" />
  <Frame
    id="$main8"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <Text id="text61" value="### Warehouse Keepers" verticalAlign="center" />
    <Button
      id="addWarehouseKeeperButton"
      iconBefore="bold/interface-add-circle-alternate"
      text="Add Warehouse Keeper"
    >
      <Event
        id="a55ef9bb"
        event="click"
        method="show"
        params={{ ordered: [] }}
        pluginId="addWarehouseKeeperModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <TextInput
      id="warehouseKeepersSerachInput"
      iconBefore="bold/interface-search"
      label=""
      labelPosition="top"
      placeholder="serach here"
      showClear={true}
      tooltipText="serach with name or phone"
    />
    <Table
      id="table1"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ getWarehouseKeepers.data }}"
      defaultSelectedRow={{ mode: "none", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      heightType="auto"
      primaryKeyColumnId="d803a"
      rowHeight="medium"
      searchTerm="{{ warehouseKeepersSerachInput.value }}"
      showBorder={true}
      showColumnBorders={true}
      showFooter={true}
      showHeader={true}
    >
      <Column
        id="d803a"
        alignment="right"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="warehouse_keeper_id"
        label="Warehouse keeper ID"
        placeholder="Enter value"
        position="center"
        size={128.875}
        summaryAggregationMode="none"
      />
      <Column
        id="84307"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="name"
        label="Name"
        placeholder="Enter value"
        position="center"
        size={88.03125}
        summaryAggregationMode="none"
      />
      <Column
        id="5484e"
        alignment="left"
        format="phoneNumber"
        formatOptions={{
          showFormatting: true,
          showCountryCallingCode: true,
          restrictToCountry: false,
        }}
        groupAggregationMode="none"
        key="phone"
        label="Phone"
        placeholder="Enter value"
        position="center"
        size={109.6875}
        summaryAggregationMode="none"
      />
      <Column
        id="3222b"
        alignment="left"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="warehouse_id"
        label="Warehouse"
        placeholder="Enter value"
        position="center"
        referenceId="warehouse"
        size={103.515625}
        summaryAggregationMode="none"
        valueOverride="{{ getWarehouses.data.name[getWarehouses.data.warehouse_id.indexOf(item)] }}"
      />
      <Column
        id="a537e"
        alignment="left"
        format="button"
        formatOptions={{
          variant: "solid",
          buttonColor: "{{ theme.danger }}",
          iconAfter: "bold/interface-link-square-alternate",
        }}
        groupAggregationMode="none"
        label="Actions"
        placeholder="Enter value"
        position="center"
        referenceId="actions"
        size={87.25}
        summaryAggregationMode="none"
        valueOverride="Manage"
      >
        <Event
          id="7df9c453"
          event="clickCell"
          method="show"
          params={{}}
          pluginId="editWarehouseKeepersModal"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </Column>
      <ToolbarButton
        id="1a"
        icon="bold/interface-text-formatting-filter-2"
        label="Filter"
        type="filter"
      />
      <ToolbarButton
        id="3c"
        icon="bold/interface-download-button-2"
        label="Download"
        type="custom"
      >
        <Event
          id="0abb929c"
          event="clickToolbar"
          method="exportData"
          params={{
            ordered: [{ fileType: "csv" }, { data: "{{  table1.data }}" }],
          }}
          pluginId=""
          type="util"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
      <ToolbarButton
        id="4d"
        icon="bold/interface-arrows-round-left"
        label="Refresh"
        type="custom"
      >
        <Event
          id="f6671135"
          event="clickToolbar"
          method="refresh"
          params={{ ordered: [] }}
          pluginId="table1"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
    </Table>
  </Frame>
</Screen>
