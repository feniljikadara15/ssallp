<ModalFrame
  id="siteDetailsModalEdit"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="large"
>
  <Header>
    <Text
      id="modalTitle19"
      value="### Edit Site Details"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton20"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="6ef7f88f"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="siteDetailsModalEdit"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <PhoneNumberInput
      id="customerSitePersonContact"
      label="Site Person Contact"
      labelPosition="top"
      lockedCountryCode="US"
      value="{{ customerSitesTable.selectedSourceRow.site_person_contact }}"
    />
    <TextInput
      id="customerSiteName"
      label="Site Name"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ customerSitesTable.selectedSourceRow.site_name }}"
    />
    <TextInput
      id="customerSItePersonName"
      label="Site Person Name"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ customerSitesTable.selectedSourceRow.site_person_name }}"
    />
    <TextInput
      id="cityState"
      label="City"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ customerSitesTable.selectedSourceRow.city }}"
    />
    <TextInput
      id="customersState"
      label="State"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ customerSitesTable.selectedSourceRow.state }}"
    />
    <TextArea
      id="customerAddressLane1"
      autoResize={true}
      label="Address Lane 1"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
      value="{{ customerSitesTable.selectedSourceRow.line1 }}"
    />
    <TextArea
      id="customerAddressLane2"
      autoResize={true}
      label="Address Lane 2"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
      value="{{ customerSitesTable.selectedSourceRow.line2 }}"
    />
    <NumberInput
      id="customerPincode"
      currency="USD"
      inputValue={0}
      label="Pincode"
      labelPosition="top"
      placeholder="Enter value"
      preventScroll={true}
      value="{{ customerSitesTable.selectedSourceRow.pincode }}"
    />
    <TextInput
      id="siteMapLink"
      label="Map Link"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ customerSitesTable.selectedSourceRow.maps_link }}"
    />
  </Body>
  <Footer>
    <Button
      id="deleteSiteDetailsButton"
      loading="{{ deleteSiteAddress.isFetching }}"
      style={{ map: { background: "rgba(246, 4, 4, 1)" } }}
      text="Delete"
    >
      <Event
        id="88c01e49"
        event="click"
        method="run"
        params={{
          map: {
            src: "await deleteSiteAddress.trigger();\nawait siteDetailsModalEdit.setHidden();\nawait getCustomersSItes.trigger();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button id="editSiteDetailsButton" text="Save">
      <Event
        id="cda24814"
        event="click"
        method="run"
        params={{
          map: {
            src: "await updateSite.trigger();\nawait siteUpdateAddress.trigger();\nawait siteDetailsModalEdit.setHidden();\nawait getCustomersSItes.trigger();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
