<Container
  id="container15"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  hoistFetching={true}
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
  style={{ ordered: [] }}
>
  <Header>
    <Text
      id="containerTitle13"
      value="#### Customer Information"
      verticalAlign="center"
    />
  </Header>
  <View id="472d8" viewKey="View 1">
    <Text
      id="text27"
      value="**Name**
{{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}"
      verticalAlign="center"
    />
    <Text
      id="text28"
      value="**Phone**
{{ getCustomers.data.phone[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}"
      verticalAlign="center"
    />
    <Text
      id="text29"
      style={{
        ordered: [
          { fontSize: "defaultFont" },
          { fontWeight: "defaultFont" },
          { fontFamily: "defaultFont" },
        ],
      }}
      value={
        '**PAN**\n{{ getCustomers.data.pan[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] == null?"Not Applicable":getCustomers.data.pan[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}'
      }
      verticalAlign="center"
    />
    <Text
      id="text30"
      value={
        '**GSTIN**\n{{ getCustomers.data.gstin[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] == null?"Not Applicable":getCustomers.data.gstin[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}'
      }
      verticalAlign="center"
    />
    <Divider
      id="divider3"
      style={{ ordered: [{ color: "rgba(195, 191, 191, 1)" }] }}
    />
    <Text id="text79" value="**Billing Address**" verticalAlign="center" />
    <Text
      id="text33"
      value="**Site**
{{ getSites.data.site_name[getSites.data.site_id.indexOf(getOrders.data.site_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}"
      verticalAlign="center"
    />
    <Text
      id="text31"
      disableMarkdown={true}
      value="{{ getAddresses.data.line1[getAddresses.data.address_id.indexOf(getOrders.data.billing_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}, {{ getAddresses.data.line2[getAddresses.data.address_id.indexOf(getOrders.data.billing_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}, {{ getAddresses.data.city[getAddresses.data.address_id.indexOf(getOrders.data.billing_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}, {{ getAddresses.data.state[getAddresses.data.address_id.indexOf(getOrders.data.billing_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}, {{ getAddresses.data.pincode[getAddresses.data.address_id.indexOf(getOrders.data.billing_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}"
      verticalAlign="center"
    />
    <Text id="text63" value="**Delivery Address**" verticalAlign="center" />
    <Text
      id="text32"
      disableMarkdown={true}
      value="{{ getAddresses.data.line1[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}, {{ getAddresses.data.line2[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}, {{ getAddresses.data.city[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}, {{ getAddresses.data.state[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}, {{ getAddresses.data.pincode[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}
"
      verticalAlign="center"
    />
  </View>
</Container>
