<Screen
  id="LoadingSlips"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={1}
  _searchParams={[]}
  browserTitle="LoadingSlips"
  title="LoadingSlips"
  urlSlug=""
  uuid="0260f9cd-f70a-4a1a-98e8-cf238b735085"
>
  <SqlQueryUnified
    id="getLoadingSlipsNew"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/getLoadingSlipsNew.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getLoadingSlipCount"
    isMultiplayerEdited={false}
    query={include("../lib/getLoadingSlipCount.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <Include src="./addSiteModal4.rsx" />
  <Include src="./importSingleCustomerModal2.rsx" />
  <Include src="./modalFrame6.rsx" />
  <Include src="./siteDetailsModalEdit5.rsx" />
  <Frame
    id="$main13"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <Text
      id="customersPageHeading5"
      value="### Loading Slips"
      verticalAlign="center"
    />
    <Divider id="divider23" />
    <Statistic
      id="productStatistic4"
      currency="USD"
      label="Total Loading Slips"
      positiveTrend="{{ self.value >= 0 }}"
      secondaryCurrency="USD"
      secondaryEnableTrend={true}
      secondaryFormattingStyle="percent"
      secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
      secondaryShowSeparators={true}
      secondarySignDisplay="trendArrows"
      secondaryValue=""
      showSeparators={true}
      value="{{ getLoadingSlipsNew.data.loading_slip_id.length }}"
    />
    <Button id="filterLS" text="Filter">
      <Event
        id="3ac55f6a"
        event="click"
        method="trigger"
        params={{}}
        pluginId="getLoadingSlipsNew"
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Select
      id="loadingslipBrandFilter"
      data="{{
  _.uniq(
    loadingSlipsTable.data
      .map(row => row.brand)   // use your real column key here
      .filter(Boolean)
  )
}}
"
      emptyMessage="No options"
      label=""
      labelPosition="top"
      overlayMaxHeight={375}
      placeholder="Select an Brand"
      showClear={true}
      showSelectionIndicator={true}
      values="{{ item }}"
    />
    <DateRange
      id="loadingslipDaterangeFilter"
      dateFormat="MMM d, yyyy"
      endPlaceholder="End date"
      iconBefore="bold/interface-calendar-remove"
      label=""
      labelPosition="top"
      showClear={true}
      startPlaceholder="Start date"
      textBetween="-"
      tooltipText="Select Order Date Range for filter data"
      value={{ start: "", end: "" }}
    />
    <TextInput
      id="searchLoadingSlips"
      label=""
      labelPosition="top"
      pattern="^\d{4,5}$"
      patternType="regex"
      placeholder="Search by Loading Slip Number"
    />
    <Select
      id="loadingslipwarehouseFilter"
      data="{{
  _.uniq(
    loadingSlipsTable.data
      .map(row => row.warehouse_name)   // use your real column key here
      .filter(Boolean)
  )
}}
"
      emptyMessage="No options"
      label=""
      labelPosition="top"
      overlayMaxHeight={375}
      placeholder="Select an warehouse"
      showClear={true}
      showSelectionIndicator={true}
    />
    <Table
      id="loadingSlipsTable"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ getLoadingSlipsNew.data }}"
      defaultFilters={{
        0: {
          id: "2b683",
          columnId: "85c11",
          operator: "=",
          value: "{{ loadingslipBrandFilter.value }}",
          disabled: false,
        },
        1: {
          id: "8c445",
          columnId: "71dfe",
          operator: "=",
          value: "{{ loadingslipwarehouseFilter.value }}",
          disabled: false,
        },
        2: {
          id: "bb98a",
          columnId: "4fa90",
          operator: "includes",
          value: "{{ searchLoadingSlips.value }}",
          disabled: false,
        },
      }}
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      groupByColumns={{}}
      heightType="auto"
      limitOffsetRowCount="{{ getLoadingSlipCount.data.total }}"
      overflowType="pagination"
      primaryKeyColumnId="4fa90"
      rowHeight="medium"
      serverPaginated={true}
      showBorder={true}
      showColumnBorders={true}
      showFooter={true}
      showHeader={true}
      style={{ headerBackground: "rgba(255, 244, 239, 1)" }}
      templatePageSize="50"
    >
      <Column
        id="c4b55"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="order_id"
        label="Order ID"
        placeholder="Enter value"
        position="center"
        size={59.515625}
      />
      <Column
        id="b8ce6"
        alignment="right"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="loading_slip_item_id"
        label="Loading slip item ID"
        placeholder="Enter value"
        position="center"
        size={121.453125}
      />
      <Column
        id="4fa90"
        alignment="right"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="loading_slip_id"
        label="Loading slip ID"
        placeholder="Enter value"
        position="center"
        size={94.75}
      />
      <Column
        id="e5fa7"
        alignment="center"
        editableOptions={{ spellCheck: false }}
        format="string"
        groupAggregationMode="none"
        key="loading_slip_file_name"
        label="Loading slip Number"
        placeholder="Enter value"
        position="center"
        size={126.46875}
      />
      <Column
        id="85c11"
        alignment="center"
        editableOptions={{ spellCheck: false }}
        format="string"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="brand"
        label="Brand"
        placeholder="Enter value"
        position="center"
        size={82.296875}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="6b59d"
        alignment="left"
        format="link"
        formatOptions={{ showUnderline: "hover" }}
        groupAggregationMode="none"
        hidden="true"
        key="url"
        label="URL"
        position="center"
        size={420.625}
      >
        <Event
          id="8a9f506c"
          event="clickCell"
          method="openUrl"
          params={{ map: { url: "{{ item }}" } }}
          pluginId=""
          type="util"
          waitMs="0"
          waitType="debounce"
        />
      </Column>
      <Column
        id="990e5"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="transporter_id"
        label="Transporter ID"
        placeholder="Enter value"
        position="center"
        size={92.3125}
      />
      <Column
        id="9a792"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="warehouse_id"
        label="Warehouse ID"
        placeholder="Enter value"
        position="center"
        size={90.046875}
      />
      <Column
        id="96e01"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="enquiry_id"
        label="Enquiry ID"
        placeholder="Enter value"
        position="center"
        size={69.765625}
      />
      <Column
        id="7a5c6"
        alignment="left"
        format="datetime"
        groupAggregationMode="none"
        key="order_date_ist"
        label="Order Date "
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="08707"
        alignment="left"
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        hidden="true"
        key="payment_type"
        label="Payment type"
        placeholder="Select option"
        position="center"
        size={88.75}
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="df4c2"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="order_status"
        label="Order status"
        placeholder="Enter value"
        position="center"
        size={81.765625}
      />
      <Column
        id="f04f7"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="currency"
        formatOptions={{
          currency: "INR",
          currencySign: "standard",
          notation: "standard",
          showSeparators: true,
          currencyDisplay: "symbol",
        }}
        groupAggregationMode="sum"
        key="total_amount"
        label="Total amount"
        placeholder="Enter value"
        position="center"
        size={86.828125}
        summaryAggregationMode="none"
      />
      <Column
        id="5556f"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="shipping_address_id"
        label="Shipping address ID"
        placeholder="Enter value"
        position="center"
        size={122.265625}
      />
      <Column
        id="0ea07"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="site_id"
        label="Site ID"
        placeholder="Enter value"
        position="center"
        size={50.4375}
      />
      <Column
        id="1f8a1"
        alignment="left"
        editableOptions={{ spellCheck: false }}
        format="string"
        groupAggregationMode="none"
        hidden="true"
        key="delivery_charges"
        label="Delivery charges"
        placeholder="Enter value"
        position="center"
        size={103.671875}
      />
      <Column
        id="18e5e"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="otp"
        label="Otp"
        placeholder="Enter value"
        position="center"
        size={58.828125}
      />
      <Column
        id="ab6f5"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="invoice_id"
        label="Invoice ID"
        placeholder="Enter value"
        position="center"
        size={68.125}
      />
      <Column
        id="e99bc"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="customer_id"
        label="Customer ID"
        placeholder="Enter value"
        position="center"
        size={82.34375}
      />
      <Column
        id="60d5a"
        alignment="left"
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        hidden="true"
        key="po_number"
        label="Po number"
        placeholder="Select option"
        position="center"
        size={156.046875}
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="2be9c"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="vehicle_id"
        label="Vehicle ID"
        placeholder="Enter value"
        position="center"
        size={68.953125}
      />
      <Column
        id="43113"
        alignment="center"
        editableOptions={{ spellCheck: false }}
        format="string"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="sub_dealer"
        label="Sub dealer"
        placeholder="Enter value"
        position="center"
        size={128.21875}
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="71dfe"
        alignment="center"
        editableOptions={{ spellCheck: false }}
        format="string"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="warehouse_name"
        label="Warehouse name"
        placeholder="Enter value"
        position="center"
        size={108.9375}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="5139b"
        alignment="center"
        editableOptions={{ spellCheck: false }}
        format="string"
        groupAggregationMode="none"
        key="warehouse_keeper_name"
        label="Warehouse keeper name"
        placeholder="Enter value"
        position="center"
        size={147.78125}
      />
      <Column
        id="34cef"
        alignment="center"
        format="phoneNumber"
        formatOptions={{
          showFormatting: true,
          showCountryCallingCode: true,
          restrictToCountry: false,
        }}
        groupAggregationMode="none"
        key="warehouse_keeper_phone"
        label="Warehouse keeper phone"
        placeholder="Enter value"
        position="center"
        size={150.921875}
      />
      <Column
        id="9df2a"
        alignment="center"
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="delivery_terms"
        label="Delivery terms"
        placeholder="Select option"
        position="center"
        size={92.078125}
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="b69a8"
        alignment="center"
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="status"
        label="Status"
        placeholder="Select option"
        position="center"
        size={65.046875}
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="ed8f9"
        alignment="center"
        cellTooltip="View Loading Slip"
        cellTooltipMode="custom"
        editableOptions={{ spellCheck: false }}
        format="button"
        formatOptions={{
          variant: "solid",
          iconBefore: "bold/interface-edit-view",
        }}
        groupAggregationMode="none"
        label="Action"
        placeholder="Enter value"
        position="center"
        referenceId="action"
        size={69.9375}
        valueOverride="View"
      >
        <Event
          id="35728246"
          event="clickCell"
          method="openUrl"
          params={{ map: { url: "{{ currentSourceRow.url }}" } }}
          pluginId=""
          type="util"
          waitMs="0"
          waitType="debounce"
        />
      </Column>
      <ToolbarButton
        id="1a"
        icon="bold/interface-text-formatting-filter-2"
        label="Filter"
        type="filter"
      />
      <ToolbarButton
        id="4d"
        icon="bold/interface-arrows-round-left"
        label="Refresh"
        type="custom"
      >
        <Event
          id="f55ac8b2"
          event="clickToolbar"
          method="trigger"
          params={{ ordered: [] }}
          pluginId="getProducts"
          type="datasource"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
    </Table>
  </Frame>
</Screen>
