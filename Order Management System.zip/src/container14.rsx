<Container
  id="container14"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  hidden="{{ selectedOrderId.value == null }}"
  hoistFetching={true}
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
>
  <Header>
    <Text
      id="containerTitle12"
      value="#### Order #{{ selectedOrderId.value }}"
      verticalAlign="center"
    />
    <Button
      id="restoreOrderButton"
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '5' }}"
      iconBefore="bold/interface-delete-bin-put-back-2"
      loading="{{ restoreOrder.isFetching || getOrders.isFetching }}"
      style={{ ordered: [{ background: "highlight" }] }}
      text="Restore"
    >
      <Event
        id="87548855"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await restoreOrderButton.setDisabled();\nawait restoreOrder.trigger();\nawait getOrders.trigger();\nawait tabbedContainer2.setCurrentViewIndex(0);\nawait restoreOrderButton.setDisabled(false);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="generateCashBillButton"
      disabled="{{ getLoadingSlips.data.loading_slip_id.length != 1 }}"
      hidden="{{ !cashBillingSwitch.value || getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      iconBefore="bold/money-cash-bag-share"
      loaderPosition="right"
      loading="{{ generateCashBill.isFetching || getTotalAmount.isFetching || getOrders.isFetching }}"
      text="Generate Cash Bill"
    >
      <Event
        id="292e574a"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await generateCashBillButton.setDisabled();\nawait getTotalAmount.trigger();\nawait generateCashBill.trigger();\nawait getOrders.trigger();\nawait generateCashBillButton.setDisabled(false);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Text
      id="containerTitle38"
      value="**{{  getOrders.data.order_number[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}**"
      verticalAlign="center"
    />
    <Button
      id="deleteOrderButton"
      disabled=""
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1'  }}"
      iconBefore="bold/interface-delete-bin-1"
      loading="{{ deleteOrder.isFetching || getOrders.isFetching }}"
      style={{ map: { background: "secondary" } }}
      text="Delete Order"
    >
      <Event
        id="8620d493"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await deleteOrderButton.setDisabled();\nawait deleteOrder.trigger();\nawait getOrders.trigger();\nawait tabbedContainer2.setCurrentViewIndex(3);\nawait deleteOrderButton.setDisabled(false);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="generateInvoiceButton"
      disabled="{{ getLoadingSlips.data.loading_slip_id.length < 1 || selectVehicleNumber.value < 1 || selectDeliveryTerms.value == null }}"
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' || cashBillingSwitch.value}}"
      iconBefore="bold/money-atm-card-2"
      loading="{{ triggerInvoicingWorkflow.isFetching }}"
      text="Generate Invoice"
    >
      <Event
        id="f46bb451"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await generateInvoiceButton.setDisabled();\nawait triggerInvoicingWorkflow.trigger();\nawait createOtp.trigger();\nawait getOrders.trigger();\nawait getInvoices.trigger();\nawait generateInvoiceButton.setDisabled(false);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="viewCashBillButton"
      hidden="{{ !(getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] == '2' && cashBillingSwitch.value) || getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] == '5' }}"
      iconBefore="bold/interface-link-circle-alternate"
      style={{ ordered: [{ background: "info" }] }}
      text="View Cash Bill"
    >
      <Event
        id="0c41954f"
        event="click"
        method="openPage"
        params={{
          ordered: [
            { options: { ordered: [{ passDataWith: "urlParams" }] } },
            { pageName: "cashBills" },
          ],
        }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="eInvoiceButton"
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] == 1 || getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] == 5 || cashBillingSwitch.value}}"
      iconAfter="bold/interface-link-square"
      style={{ map: { background: "rgba(242, 96, 34, 0.87)" } }}
      text="E-Invoice"
    >
      <Event
        id="77fbb742"
        event="click"
        method="openUrl"
        params={{
          map: {
            url: "https://books.zoho.in/app/60031284196#/invoices/{{ \ngetInvoices.data.zb_invoice_id[getInvoices.data.invoice_id.indexOf(getOrders.data.invoice_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }}",
          },
        }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <DropdownButton
      id="sendInvoiceButton"
      _colorByIndex={["", ""]}
      _fallbackTextByIndex={["", ""]}
      _imageByIndex={["", ""]}
      _values={["Action 4", ""]}
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] == 1 || getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] == 5 || cashBillingSwitch.value}}"
      itemMode="static"
      overlayMaxHeight={375}
      styleVariant="outline"
      text="Send Invoice to..."
    >
      <Option
        id="d72ef"
        disabled={false}
        hidden={false}
        icon="bold/phone-telephone-otp"
        label="Customer (with OTP)"
      >
        <Event
          id="64c9818b"
          event="click"
          method="run"
          params={{
            map: {
              src: 'try {\n  utils.showNotification({\n    title: "Downloading invoice",\n    description: "Preparing the invoice PDF...",\n    notificationType: "info",\n  });\n\n  await downloadInvoice.trigger();\n\n  utils.showNotification({\n    title: "Invoice downloaded",\n    description: "Saving invoice details...",\n    notificationType: "success",\n  });\n\n  await storeInvoice.trigger();\n\n  utils.showNotification({\n    title: "Uploading PDF",\n    description: "Uploading invoice PDF and generating the URL...",\n    notificationType: "info",\n  });\n\n  await updatePDFUrl.trigger();\n\n  utils.showNotification({\n    title: "Sending WhatsApp message",\n    description: "Sending invoice to customer on WhatsApp...",\n    notificationType: "info",\n  });\n\n  await notifyCustomer3.trigger();\n\n  utils.showNotification({\n    title: "Sending delivery OTP",\n    description: "Sending delivery OTP to the customer...",\n    notificationType: "info",\n  });\n\n  await sendDeliveryOTP.trigger();\n\n  utils.showNotification({\n    title: "Customer notified",\n    description: "Invoice and delivery OTP were sent successfully.",\n    notificationType: "success",\n  });\n} catch (error) {\n  console.error("Invoice notification flow failed:", error);\n\n  utils.showNotification({\n    title: "Failed to notify customer",\n    description: error?.message || "Something went wrong while processing the invoice flow.",\n    notificationType: "error",\n  });\n\n  throw error;\n}',
            },
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </Option>
      <Option
        id="3f41e"
        icon="line/interface-align-front"
        label="Customer (with OTP) & Transporter"
      >
        <Event
          id="3da3a8b3"
          event="click"
          method="run"
          params={{
            map: {
              src: 'try {\n  utils.showNotification({\n    title: "Downloading invoice",\n    description: "Preparing the invoice PDF...",\n    notificationType: "info",\n  });\n\n  await downloadInvoice.trigger();\n\n  utils.showNotification({\n    title: "Invoice downloaded",\n    description: "Saving invoice details...",\n    notificationType: "success",\n  });\n\n  await storeInvoice.trigger();\n\n  utils.showNotification({\n    title: "Uploading PDF",\n    description: "Uploading invoice PDF and generating the URL...",\n    notificationType: "info",\n  });\n\n  await updatePDFUrl.trigger();\n\n  utils.showNotification({\n    title: "Sending WhatsApp message",\n    description: "Sending invoice to customer on WhatsApp...",\n    notificationType: "info",\n  });\n\n  await notifyCustomer3.trigger();\n\n  utils.showNotification({\n    title: "Sending delivery OTP",\n    description: "Sending delivery OTP to the customer...",\n    notificationType: "info",\n  });\n\n  await sendDeliveryOTP.trigger();\n\n  utils.showNotification({\n    title: "Sending transporter invoice",\n    description: "Sending invoice PDF to the transporter...",\n    notificationType: "info",\n  });\n\n  await sendInvoiceToTransporter.trigger();\n\n  utils.showNotification({\n    title: "Invoice sent successfully",\n    description: "Customer invoice, delivery OTP, and transporter invoice were sent successfully.",\n    notificationType: "success",\n  });\n} catch (error) {\n  console.error("Invoice notification flow failed:", error);\n\n  utils.showNotification({\n    title: "Failed to send invoice",\n    description:\n      error?.message ||\n      "Something went wrong while sending the invoice to the customer or transporter.",\n    notificationType: "error",\n  });\n\n  throw error;\n}',
            },
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </Option>
      <Event
        id="720eaf38"
        event="click"
        method="trigger"
        params={{ ordered: [] }}
        pluginId="sendInvoiceToTransporter"
        targetId="b0162"
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
      <Event
        id="a9444ac0"
        event="click"
        method="trigger"
        params={{
          ordered: [
            {
              options: {
                object: {
                  onSuccess: null,
                  onFailure: null,
                  additionalScope: null,
                },
              },
            },
          ],
        }}
        pluginId="notifyCustomer"
        targetId="8d9e8"
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </DropdownButton>
    <SplitButton
      id="viewButton"
      _colorByIndex={["", ""]}
      _fallbackTextByIndex={["", ""]}
      _imageByIndex={["", ""]}
      _values={["", ""]}
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] == 1 || getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] == 5 || cashBillingSwitch.value}}"
      itemMode="static"
      overlayMaxHeight={375}
      showSelectionIndicator={true}
      style={{ map: { background: "info" } }}
    >
      <Option
        id="05084"
        icon="bold/interface-link-circle-alternate"
        label="View Invoice"
      >
        <Event
          id="374f62ec"
          event="click"
          method="openUrl"
          params={{
            map: {
              url: "{{ getInvoices.data.zb_invoice_url[getInvoices.data.order_id.indexOf(selectedOrderId.value)] }}",
            },
          }}
          pluginId=""
          type="util"
          waitMs="0"
          waitType="debounce"
        />
      </Option>
      <Option
        id="cf709"
        hidden="{{ orderItemsTable.data.reduce((sum, item) => sum + Number(item.unit_price) * item.quantity, 0) < 50000 }}
"
        icon="bold/interface-link-circle-alternate"
        label="View E-way Bill"
      >
        <Event
          id="3579d3bb"
          event="click"
          method="openUrl"
          params={{
            map: {
              url: "https://books.zoho.in/app/60031284196#/ewaybills/new?entity_id={{getInvoices.data.zb_invoice_id[getInvoices.data.invoice_id.indexOf(getOrders.data.invoice_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])]}}&entity_type=invoice",
            },
          }}
          pluginId=""
          type="util"
          waitMs="0"
          waitType="debounce"
        />
      </Option>
    </SplitButton>
  </Header>
  <View id="2def4" viewKey="View 1">
    <Include src="./container15.rsx" />
    <Container
      id="container16"
      footerPadding="4px 12px"
      headerPadding="12px 12px"
      loading="false"
      padding="12px"
      showBody={true}
      showHeader={true}
      showHeaderBorder={false}
    >
      <Header>
        <Text
          id="containerTitle14"
          value="#### Order Details"
          verticalAlign="center"
        />
        <Button
          id="cashBillingButton"
          disabled="false"
          hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
          style={{
            background: "success",
            fontSize: "h5Font",
            fontWeight: "h5Font",
            fontFamily: "h5Font",
          }}
          text="CASH BILL"
        >
          <Event
            id="0a40e6b1"
            event="click"
            method="show"
            params={{}}
            pluginId="convertCashBillModal"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
        </Button>
        <Switch
          id="cashBillingSwitch"
          disabled="true"
          hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
          label=""
          labelPosition="left"
          value={
            '{{ getOrders.data.payment_type[getOrders.data.order_id.indexOf(selectedOrderId.value)] == "cash" }}'
          }
        />
      </Header>
      <View id="472d8" viewKey="View 1">
        <Table
          id="orderItemsTable"
          autoColumnWidth={true}
          cellSelection="none"
          clearChangesetOnSave={true}
          data="{{ getOrderItems.data }}"
          defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
          defaultSort={[{ object: { columnId: "ee79e", direction: "asc" } }]}
          emptyMessage="No rows found"
          enableSaveActions={true}
          heightType="auto"
          primaryKeyColumnId="ee79e"
          rowHeight="medium"
          rowSelection="none"
          showBorder={true}
          showColumnBorders={true}
          showFooter={true}
          showHeader={true}
          showSummaryRow={true}
          style={{
            headerBackground: "tertiary",
            summaryRowBackground: "tertiary",
          }}
          toolbarPosition="bottom"
        >
          <Column
            id="ee79e"
            alignment="right"
            editable={false}
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            hidden="true"
            key="order_item_id"
            label="Order item ID"
            placeholder="Enter value"
            position="center"
            size={86.171875}
            summaryAggregationMode="none"
          />
          <Column
            id="15462"
            alignment="left"
            format="string"
            groupAggregationMode="none"
            label="Category"
            placeholder="Enter value"
            position="center"
            referenceId="category"
            size={64.0625}
            summaryAggregationMode="none"
            valueOverride="{{ getProducts.data.category[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
          />
          <Column
            id="a4d3c"
            alignment="left"
            format="string"
            groupAggregationMode="none"
            label="Brand"
            placeholder="Enter value"
            position="center"
            referenceId="brand"
            size={47.234375}
            summaryAggregationMode="none"
            valueOverride="{{ getProducts.data.brand[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
          />
          <Column
            id="7a451"
            alignment="left"
            format="string"
            groupAggregationMode="none"
            label="Grade"
            placeholder="Enter value"
            position="center"
            referenceId="grade"
            size={47.65625}
            summaryAggregationMode="none"
            valueOverride="{{ getProducts.data.grade[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
          />
          <Column
            id="c698c"
            alignment="right"
            editable="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] == '1' }}"
            editableOptions={{ showStepper: true, min: "0" }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="quantity"
            label="Quantity"
            placeholder="Enter value"
            position="center"
            size={60.46875}
            summaryAggregationMode="none"
          />
          <Column
            id="45215"
            alignment="right"
            editable="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] == '1' }}"
            editableOptions={{ showStepper: false, min: "0" }}
            format="currency"
            formatOptions={{
              currency: "INR",
              currencySign: "standard",
              notation: "standard",
              showSeparators: true,
              currencyDisplay: "symbol",
              decimalPlaces: "",
            }}
            groupAggregationMode="sum"
            key="unit_price"
            label="Unit price"
            placeholder="Enter value"
            position="center"
            size={66.59375}
            summaryAggregationMode="none"
          />
          <Column
            id="a6619"
            alignment="right"
            editableOptions={{ showStepper: true }}
            format="currency"
            formatOptions={{
              currency: "INR",
              currencySign: "standard",
              notation: "standard",
              showSeparators: true,
              currencyDisplay: "symbol",
              decimalPlaces: "",
            }}
            groupAggregationMode="sum"
            label="Total price"
            placeholder="Enter value"
            position="center"
            referenceId="total_price"
            size={72.140625}
            summaryAggregationMode="sum"
            valueOverride="{{ currentSourceRow.unit_price * currentSourceRow.quantity }}"
          />
          <ToolbarButton
            id="1a"
            icon="bold/interface-text-formatting-filter-2"
            label="Filter"
            type="filter"
          />
          <ToolbarButton
            id="4d"
            icon="bold/interface-arrows-round-left"
            label="Refresh"
            type="custom"
          >
            <Event
              id="659775fe"
              event="clickToolbar"
              method="refresh"
              params={{ ordered: [] }}
              pluginId="orderItemsTable"
              type="widget"
              waitMs="0"
              waitType="debounce"
            />
          </ToolbarButton>
          <Event
            id="c9da78fd"
            event="save"
            method="run"
            params={{
              ordered: [
                {
                  src: "await orderItemsTableSaveHandler.trigger();\norderItemsTable.refresh();",
                },
              ],
            }}
            pluginId=""
            type="script"
            waitMs="0"
            waitType="debounce"
          />
        </Table>
      </View>
    </Container>
    <Include src="./container17.rsx" />
    <Include src="./container38.rsx" />
  </View>
</Container>
