<Container
  id="tabbedContainer1"
  currentViewKey="{{ self.viewKeys[0] }}"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  overflowType="hidden"
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
  style={{ ordered: [] }}
  transition="slide"
>
  <Header>
    <Text id="text17" value="### Enquiries" verticalAlign="center" />
    <Button
      id="newEnquiryButton"
      iconBefore="bold/interface-add-1"
      style={{ ordered: [{ background: "info" }] }}
      text="New"
    >
      <Event
        id="df9761f5"
        event="click"
        method="run"
        params={{ ordered: [{ src: "await newEnquiryModal.show();" }] }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Tabs
      id="enquiryStatusTabs"
      itemMode="static"
      navigateContainer={true}
      style={{ ordered: [] }}
      targetContainerId="tabbedContainer1"
      value="{{ self.values[0] }}"
    >
      <Option id="26728" value="Tab 1" />
      <Option id="fef66" value="Tab 2" />
      <Option id="757df" value="Tab 3" />
    </Tabs>
  </Header>
  <View id="2851d" label="Ongoing">
    <DateRange
      id="ongoingEnquiriesDateRange"
      dateFormat="MMM d, yyyy"
      endPlaceholder="End date"
      iconBefore="bold/interface-calendar-remove"
      label="Filter By Date"
      labelPosition="top"
      maxDate="{{ new Date() }}"
      showClear={true}
      startPlaceholder="Start date"
      textBetween="-"
      value={{
        start: '{{ new Date().toISOString().split("T")[0] }}',
        end: '{{ new Date().toISOString().split("T")[0] }}',
      }}
    />
    <TextInput
      id="searchOngoingEnquiriesCustomer"
      label=""
      labelPosition="top"
      placeholder="Search by Customer"
    />
    <ListViewBeta
      id="ongoingEnquiriesListView"
      _primaryKeys="{{ item.enquiry_id }}"
      data={
        '{{\n  getEnquiries.data.enquiry_id\n    .map((_, i) =>\n      Object.fromEntries(\n        Object.entries(getEnquiries.data).map(([key, value]) => [key, value[i]])\n      )\n    )\n    .filter(enquiry => {\n\n      const startDate = ongoingEnquiriesDateRange.value?.start;\n      const endDate = ongoingEnquiriesDateRange.value?.end;\n\n      // --- Date filtering ---\n      const enquiryDate = new Date(enquiry.enquiry_date);\n      enquiryDate.setHours(0, 0, 0, 0);\n\n      const hasDates = startDate && endDate;\n\n      let start, end;\n\n      if (hasDates) {\n        start = new Date(startDate);\n        start.setHours(0, 0, 0, 0);\n\n        end = new Date(endDate);\n        end.setHours(23, 59, 59, 999);\n      }\n\n      const passesDateFilter =\n        !hasDates || (enquiryDate >= start && enquiryDate <= end);\n\n      return (\n        enquiry.enquiry_status === "0" &&\n        passesDateFilter\n      );\n    })\n}}'
      }
      itemWidth="200px"
      margin="0"
      maxHeight="100vh"
      numColumns={3}
      padding="0"
    >
      <Container
        id="container8"
        footerPadding="4px 12px"
        headerPadding="4px 12px"
        padding="12px"
        showBody={true}
        style={{
          ordered: [
            {
              border:
                "{{ item.enquiry_id == selectedEnquiryId.value?theme.primary:theme.surfacePrimaryBorder }}",
            },
            {
              background:
                "{{ item.enquiry_id == selectedEnquiryId.value?theme.tertiary:theme.surfacePrimary }}",
            },
          ],
        }}
      >
        <Header>
          <Text
            id="containerTitle6"
            value="#### {{ item }}"
            verticalAlign="center"
          />
        </Header>
        <View id="352b5" viewKey="View 1">
          <IconText
            id="iconText1"
            icon="line/mail-chat-two-bubbles-oval"
            text="EN - {{ item.enquiry_id }} - {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(item.customer_id)] }}"
          />
          <TagsWidget2
            id="enquiryTypeTag"
            _colorByIndex={["{{ theme.info }}", "{{ theme.success }}"]}
            _hiddenByIndex={[false, false]}
            _iconByIndex={["", ""]}
            _ids={["36eb1", "eecb3"]}
            _imageByIndex={["", ""]}
            _labels={["", ""]}
            _textColorByIndex={["", ""]}
            _tooltipByIndex={["", ""]}
            _values={["Internal", "External"]}
            allowWrap={true}
            colorByIndex=""
            data=""
            hiddenByIndex=""
            iconByIndex=""
            imageByIndex=""
            itemMode="static"
            labels=""
            textColorByIndex=""
            tooltipByIndex=""
            value="{{ [getEnquiries.data.type[getEnquiries.data.enquiry_id.indexOf(item.enquiry_id)]] }}"
            values=""
          />
          <Text
            id="text14"
            horizontalAlign="right"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="**{{`${((d = item.enquiry_date.split('T')[0].split('-')) && `${d[2]}-${d[1]}-${d[0]}`)}`}}**"
            verticalAlign="center"
          />
        </View>
        <Event
          id="ac0892b9"
          event="click"
          method="run"
          params={{
            ordered: [
              { src: "await selectedEnquiryId.setValue(item.enquiry_id);" },
            ],
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </Container>
    </ListViewBeta>
  </View>
  <View id="ec531" label="Past">
    <DateRange
      id="pastEnquiriesDateRange"
      dateFormat="MMM d, yyyy"
      endPlaceholder="End date"
      iconBefore="bold/interface-calendar-remove"
      label="Filter By Date"
      labelPosition="top"
      maxDate="{{ new Date() }}"
      showClear={true}
      startPlaceholder="Start date"
      textBetween="-"
      value={{
        start: '{{ new Date().toISOString().split("T")[0] }}',
        end: '{{ new Date().toISOString().split("T")[0] }}',
      }}
    />
    <ListViewBeta
      id="pastEnquiriesListView"
      _primaryKeys="{{ item.enquiry_id }}"
      data={
        '{{getEnquiries.data.enquiry_id.map((_, i) =>\n  Object.fromEntries(\n    Object.entries(getEnquiries.data).map(([key, value]) => [key, value[i]])\n  )\n).filter(enquiry => {\n  if (enquiry.enquiry_status != "1") return false;\n\n  // --- Date filtering (cleared range = show all) ---\n  const startDate = pastEnquiriesDateRange.value?.start;\n  const endDate = pastEnquiriesDateRange.value?.end;\n  if (!(startDate && endDate)) return true;\n\n  const enquiryDate = new Date(enquiry.enquiry_date);\n  enquiryDate.setHours(0, 0, 0, 0);\n  const start = new Date(startDate);\n  start.setHours(0, 0, 0, 0);\n  const end = new Date(endDate);\n  end.setHours(23, 59, 59, 999);\n\n  return enquiryDate >= start && enquiryDate <= end;\n})}}'
      }
      itemWidth="200px"
      margin="0"
      numColumns={3}
      padding="0"
    >
      <Container
        id="container9"
        footerPadding="4px 12px"
        headerPadding="4px 12px"
        padding="12px"
        showBody={true}
        style={{
          ordered: [
            {
              border:
                "{{ item.enquiry_id == selectedEnquiryId.value?theme.primary:theme.surfacePrimaryBorder }}",
            },
            {
              background:
                "{{ item.enquiry_id == selectedEnquiryId.value?theme.tertiary:theme.surfacePrimary }}",
            },
          ],
        }}
      >
        <Header>
          <Text
            id="containerTitle7"
            value="#### {{ item }}"
            verticalAlign="center"
          />
        </Header>
        <View id="352b5" viewKey="View 1">
          <IconText
            id="iconText2"
            icon="line/mail-chat-two-bubbles-oval"
            text="EN - {{ item.enquiry_id }} - {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(item.customer_id)] }}"
          />
          <TagsWidget2
            id="tags2"
            _colorByIndex={["{{ theme.info }}", "{{ theme.success }}"]}
            _hiddenByIndex={[false, false]}
            _iconByIndex={["", ""]}
            _ids={["36eb1", "eecb3"]}
            _imageByIndex={["", ""]}
            _labels={["", ""]}
            _textColorByIndex={["", ""]}
            _tooltipByIndex={["", ""]}
            _values={["Internal", "External"]}
            allowWrap={true}
            colorByIndex=""
            data=""
            hiddenByIndex=""
            iconByIndex=""
            imageByIndex=""
            itemMode="static"
            labels=""
            textColorByIndex=""
            tooltipByIndex=""
            value="{{ [getEnquiries.data.type[getEnquiries.data.enquiry_id.indexOf(item.enquiry_id)]] }}"
            values=""
          />
          <Text
            id="text15"
            horizontalAlign="right"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="**{{`${((d = item.enquiry_date.split('T')[0].split('-')) && `${d[2]}-${d[1]}-${d[0]}`)}`}}**"
            verticalAlign="center"
          />
        </View>
        <Event
          id="cbace321"
          event="click"
          method="run"
          params={{
            ordered: [
              { src: "await selectedEnquiryId.setValue(item.enquiry_id);" },
            ],
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </Container>
    </ListViewBeta>
  </View>
  <View id="3cda5" label="Deleted">
    <ListViewBeta
      id="deletedEnquiriesListView"
      _primaryKeys="{{ item.enquiry_id }}"
      data={
        '{{getEnquiries.data.enquiry_id.map((_, i) =>\n  Object.fromEntries(\n    Object.entries(getEnquiries.data).map(([key, value]) => [key, value[i]])\n  )\n).filter(enquiry => enquiry.enquiry_status === "5")}}'
      }
      itemWidth="200px"
      margin="0"
      numColumns={3}
      padding="0"
    >
      <Container
        id="container10"
        footerPadding="4px 12px"
        headerPadding="4px 12px"
        padding="12px"
        showBody={true}
        style={{
          ordered: [
            {
              border:
                "{{ item.enquiry_id == selectedEnquiryId.value?theme.primary:theme.surfacePrimaryBorder }}",
            },
            {
              background:
                "{{ item.enquiry_id == selectedEnquiryId.value?theme.tertiary:theme.surfacePrimary }}",
            },
          ],
        }}
      >
        <Header>
          <Text
            id="containerTitle8"
            value="#### {{ item }}"
            verticalAlign="center"
          />
        </Header>
        <View id="352b5" viewKey="View 1">
          <IconText
            id="iconText3"
            icon="line/mail-chat-two-bubbles-oval"
            text="EN - {{ item.enquiry_id }} - {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(item.customer_id)] }}"
          />
          <TagsWidget2
            id="tags3"
            _colorByIndex={["{{ theme.info }}", "{{ theme.success }}"]}
            _hiddenByIndex={[false, false]}
            _iconByIndex={["", ""]}
            _ids={["36eb1", "eecb3"]}
            _imageByIndex={["", ""]}
            _labels={["", ""]}
            _textColorByIndex={["", ""]}
            _tooltipByIndex={["", ""]}
            _values={["Internal", "External"]}
            allowWrap={true}
            colorByIndex=""
            data=""
            hiddenByIndex=""
            iconByIndex=""
            imageByIndex=""
            itemMode="static"
            labels=""
            textColorByIndex=""
            tooltipByIndex=""
            value="{{ [getEnquiries.data.type[getEnquiries.data.enquiry_id.indexOf(item.enquiry_id)]] }}"
            values=""
          />
          <Text
            id="text16"
            horizontalAlign="right"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="**{{`${((d = item.enquiry_date.split('T')[0].split('-')) && `${d[2]}-${d[1]}-${d[0]}`)}`}}**"
            verticalAlign="center"
          />
        </View>
        <Event
          id="14cc71b2"
          event="click"
          method="run"
          params={{
            ordered: [
              { src: "await selectedEnquiryId.setValue(item.enquiry_id);" },
            ],
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </Container>
    </ListViewBeta>
  </View>
</Container>
