<ModalFrame
  id="editProductModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="editProductHeading"
      style={{ map: { color: "secondary" } }}
      value="##### Edit Product : {{ productsTable.selectedSourceRow.product_name }}  [{{ productsTable.selectedSourceRow.zb_item_id }}]"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton13"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="2338e750"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="editProductModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="productName"
      label="Product Name"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ productsTable.selectedSourceRow.product_name  }}"
    />
    <TextArea
      id="productDescription"
      autoResize={true}
      label="Description"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
      value="{{ productsTable.selectedSourceRow.description }}"
    />
    <TextInput
      id="productGrade"
      label="Grade"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ productsTable.selectedSourceRow.grade  }}"
    />
    <Select
      id="productCategory"
      emptyMessage="No options"
      itemMode="static"
      label="Category"
      labelPosition="top"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value="{{ productsTable.selectedSourceRow.category }}"
    >
      <Option id="135c7" value="Aggregate" />
      <Option id="13e72" disabled={false} hidden={false} value="Blocks" />
      <Option id="f5a43" disabled={false} hidden={false} value="Binding Wire" />
      <Option id="57446" value="Cement" />
      <Option id="d8c19" disabled={false} hidden={false} value="RMC" />
      <Option id="fe13e" disabled={false} hidden={false} value="Sand" />
      <Option id="91b43" value="Steel" />
      <Option id="fd29b" disabled={false} hidden={false} value="Tilefix" />
      <Option id="b73e5" disabled={false} hidden={false} value="White Cement" />
    </Select>
    <TextInput
      id="productBrand"
      label="Brand"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ productsTable.selectedSourceRow.brand  }}"
    />
    <Select
      id="productUnit"
      emptyMessage="No options"
      itemMode="static"
      label="Unit"
      labelPosition="top"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value="{{ productsTable.selectedSourceRow.unit }}"
    >
      <Option id="135c7" value="Bags" />
      <Option id="13e72" disabled={false} hidden={false} value="Bundles" />
      <Option id="f5a43" disabled={false} hidden={false} value="MTS" />
      <Option id="57446" value="M3" />
      <Option id="d8c19" disabled={false} hidden={false} value="Pieces" />
      <Option id="fe13e" disabled={false} hidden={false} value="MTS/Kgs" />
      <Option
        id="97f11"
        disabled={false}
        hidden={false}
        label="Nos"
        value="Nos"
      />
    </Select>
    <TextInput
      id="productSKU"
      inputTooltip="SKU Should be Unique for each product."
      label="SKU"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ productsTable.selectedSourceRow.sku  }}"
    />
    <TextInput
      id="productHSN"
      label="HSN"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ productsTable.selectedSourceRow.hsn  }}"
    />
    <Select
      id="productGST"
      emptyMessage="No options"
      itemMode="static"
      label="GST Rate"
      labelPosition="top"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value="{{ Number(productsTable.selectedSourceRow.gst_rate) }}"
    >
      <Option id="135c7" label="5%" value="5" />
      <Option
        id="13e72"
        disabled={false}
        hidden={false}
        label="18%"
        value="18"
      />
      <Option
        id="f5a43"
        disabled={false}
        hidden={false}
        label="28%"
        value="28"
      />
    </Select>
    <NumberInput
      id="productMRP"
      currency="INR"
      format="currency"
      inputValue={0}
      label="MRP"
      labelPosition="top"
      placeholder="Enter value"
      preventScroll={true}
      showClear={true}
      showSeparators={true}
      showStepper={true}
      value="{{ Number(productsTable.selectedSourceRow.mrp) }}"
    />
    <Checkbox
      id="productActive"
      label="Product Active"
      labelWidth="100"
      value="{{ productsTable.selectedSourceRow.is_active }}"
    />
  </Body>
  <Footer>
    <Button
      id="deleteProductButton"
      style={{
        label: "danger",
        border: "danger",
        hoverBackground: "rgba(89, 0, 4, 0.22)",
      }}
      styleVariant="outline"
      text="Delete"
    >
      <Event
        id="4fcb7752"
        event="click"
        method="show"
        params={{}}
        pluginId="deleteProductModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="saveProductDetailsButton"
      disabled="{{ updateProduct.isFetching || updateProductZB.isFetching }}"
      loaderPosition="left"
      loading="{{ updateProduct.isFetching || updateProductZB.isFetching }}"
      text="Save"
    >
      <Event
        id="513297da"
        event="click"
        method="run"
        params={{
          map: {
            src: "await saveProductDetailsButton.setDisabled();\nawait updateProduct.trigger();\nawait updateProductZB.trigger();\nawait productsTable.refresh();\nawait getAllProducts.trigger();\nawait editProductModal.setHidden();\nawait saveProductDetailsButton.setDisabled(false);",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
