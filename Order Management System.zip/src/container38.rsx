<Container
  id="container38"
  footerPadding="4px 12px"
  headerPadding="4px 12px"
  padding="12px"
  showBody={true}
  showHeader={true}
>
  <Header>
    <Button
      id="confirmOrderDeliveryButton"
      disabled=""
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] !=2 }}"
      style={{ map: { background: "success" } }}
      text="Confirm Delivery"
    >
      <Event
        id="38967b7f"
        event="click"
        method="show"
        params={{ ordered: [] }}
        pluginId="deliveryModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Text
      id="containerTitle37"
      value="#### Dispatch Details"
      verticalAlign="center"
    />
  </Header>
  <View id="00030" viewKey="View 1">
    <TextInput
      id="subDealerInput"
      disabled="{{ updateWarehouse2.isFetching || updateTransporter2.isFetching || updatePoNumber.isFetching || updateSubDealer.isFetching || getOrders.isFetching }}"
      label="Sub Dealer"
      labelPosition="top"
      placeholder="Enter sub dealer name"
      readOnly="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      value="{{ getOrders.data.sub_dealer[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}"
    />
    <TextInput
      id="poNumberInput"
      disabled="{{ updateWarehouse2.isFetching || updateTransporter2.isFetching || updatePoNumber.isFetching || updateSubDealer.isFetching || getOrders.isFetching }}"
      label="PO Number"
      labelPosition="top"
      placeholder="Enter PO number"
      readOnly="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      value="{{ getOrders.data.po_number[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}"
    />
    <Button
      id="viewLoadingSlipsButton"
      disabled=""
      hidden="{{ (getOrders.data.loading_slip_id[getOrders.data.order_id.indexOf(selectedOrderId.value)]) == null || orderStatusTabs.selectedLabel=='Ongoing' }}"
      iconBefore="bold/shipping-transfer-cart"
      style={{ map: { background: "primary" } }}
      text="View Loading Slips"
    >
      <Event
        id="bc8d38d1"
        event="click"
        method="show"
        params={{ ordered: [] }}
        pluginId="manageLoadingSlipsModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="saveOrderDetailsButton"
      disabled={
        '{{ selectWarehouse2.value == null || selectTransporter2.value == null || selectVehicleNumber.value == null ||\nselectDeliveryTerms.value == null || poNumberInput.value == "" || subDealerInput.value == ""}}'
      }
      hidden="{{   getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      iconBefore="bold/shipping-transfer-truck-time"
      loading="{{ updateOrderParameters.isFetching || getOrders.isFetching }}"
      style={{
        background: "success",
        fontSize: "h5Font",
        fontWeight: "h5Font",
        fontFamily: "h5Font",
      }}
      text="Save Details"
    >
      <Event
        id="541d57d4"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await updateOrderParameters.trigger();\nawait getOrders.trigger();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="manageLoadingSlipsButton"
      disabled={
        '{{ selectWarehouse2.value == null || selectTransporter2.value == null || selectVehicleNumber.value == null ||\nselectDeliveryTerms.value == null || poNumberInput.value == "" || subDealerInput.value == ""}}'
      }
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      iconBefore="bold/shipping-transfer-cart"
      style={{ map: { background: "primary" } }}
      text="Manage Loading Slips"
    >
      <Event
        id="688b1746"
        event="click"
        method="show"
        params={{ ordered: [] }}
        pluginId="manageLoadingSlipsModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="saveDeliveryTermsButton"
      disabled="{{ selectWarehouse2.value.length ==0 || selectTransporter2.value.length == 0 || selectVehicleNumber.value.length == 0 }}"
      hidden="{{ true || getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      iconBefore="bold/shipping-transfer-truck-time"
      style={{ ordered: [{ background: "success" }] }}
      text="Save Delivery Terms"
    >
      <Event
        id="541d57d4"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await updateWarehouse2.trigger();\nawait updateTransporter2.trigger();\nawait updateVehicleNumber.trigger();\nawait updateDeliveryTerms.trigger();\nawait newVehicleID.setValue(null);\nawait getOrders.trigger();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </View>
</Container>
