<Screen
  id="Customers"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={8}
  _searchParams={[]}
  browserTitle=""
  title={null}
  urlSlug=""
  uuid="9b11e35b-5c6c-41ec-b44c-a674f353b89b"
>
  <Folder id="Address">
    <SqlQueryUnified
      id="siteUpdateAddress"
      isMultiplayerEdited={false}
      query={include("../lib/siteUpdateAddress.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updateAddressBilling"
      notificationDuration={4.5}
      query={include("../lib/updateAddressBilling.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="getCustomerBillingAddress"
      notificationDuration={4.5}
      query={include("../lib/getCustomerBillingAddress.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
  </Folder>
  <Folder id="Customer">
    <SqlQueryUnified
      id="getCustomersSItes"
      isMultiplayerEdited={false}
      query={include("../lib/getCustomersSItes.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updateCustomer"
      notificationDuration={4.5}
      query={include("../lib/updateCustomer.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="getAllCustomers"
      isHidden={false}
      query={include("../lib/getAllCustomers.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
  </Folder>
  <Folder id="AddSiteDetails">
    <SqlQueryUnified
      id="AddCustomerSiteDetails"
      isMultiplayerEdited={false}
      notificationDuration={4.5}
      query={include("../lib/AddCustomerSiteDetails.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="AddCustomerAdress"
      notificationDuration={4.5}
      query={include("../lib/AddCustomerAdress.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updateSite"
      notificationDuration={4.5}
      query={include("../lib/updateSite.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="deleteSiteAddress"
      isMultiplayerEdited={false}
      notificationDuration={4.5}
      query={include("../lib/deleteSiteAddress.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
  </Folder>
  <Folder id="ImportSingleCustomerZB">
    <WorkflowRun
      id="importSingleZBCustomer"
      notificationDuration={4.5}
      queryFailureConditions={'[{"condition":"","message":""}]'}
      resourceName="WorkflowRun"
      successMessage="Customer Imported Successfully."
      workflowParams={include("../lib/importSingleZBCustomer.json", "string")}
    />
    <RESTQuery
      id="checkZBCustomerValidity"
      isMultiplayerEdited={false}
      notificationDuration={4.5}
      query="contacts/{{ zbCustomerIDInput.value}}?organization_id=60031284196"
      resourceDisplayName="ZB v3"
      resourceName="c5058a3e-b80a-4586-a22f-88cbcba8ab5f"
      runWhenModelUpdates={false}
      showFailureToaster={false}
      showSuccessToaster={false}
    />
  </Folder>
  <Include src="./addSiteModal.rsx" />
  <Include src="./editCustomerModal.rsx" />
  <Include src="./importSingleCustomerModal.rsx" />
  <Include src="./modalFrame1.rsx" />
  <Include src="./siteDetailsModalEdit.rsx" />
  <Frame
    id="$main9"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <Text
      id="customersPageHeading"
      value="### Customers"
      verticalAlign="center"
    />
    <Button
      id="importSingleCustomerButton"
      hidden="true"
      text="Import Customer"
      tooltipText="Import Single Customer from Zoho Books"
    >
      <Event
        id="4eef7567"
        event="click"
        method="show"
        params={{}}
        pluginId="importSingleCustomerModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Divider id="divider9" />
    <Statistic
      id="productStatistic2"
      currency="USD"
      label="ACTIVE CUSTOMER Count"
      labelCaption="Active Customers"
      positiveTrend="{{ self.value >= 0 }}"
      secondaryCurrency="USD"
      secondaryEnableTrend={true}
      secondaryFormattingStyle="percent"
      secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
      secondaryShowSeparators={true}
      secondarySignDisplay="trendArrows"
      secondaryValue=""
      showSeparators={true}
      value="{{ getCustomers.data.customer_id.length }}"
    />
    <Statistic
      id="productStatistic3"
      currency="USD"
      label="Total Customer Count"
      labelCaption="Customers"
      positiveTrend="{{ self.value >= 0 }}"
      secondaryCurrency="USD"
      secondaryEnableTrend={true}
      secondaryFormattingStyle="percent"
      secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
      secondaryShowSeparators={true}
      secondarySignDisplay="trendArrows"
      secondaryValue=""
      showSeparators={true}
      value="{{ getAllCustomers.data.customer_id.length }}"
    />
    <Select
      id="customersActiveInActiveFilter"
      emptyMessage="No options"
      itemMode="static"
      label=""
      labelPosition="top"
      overlayMaxHeight={375}
      placeholder="Filter by Active/Inactive"
      showClear={true}
      showSelectionIndicator={true}
    >
      <Option id="00030" label="Active" value="true" />
      <Option id="00031" label="In Active" value="false" />
    </Select>
    <TextInput
      id="searchCustomers"
      iconBefore="line/interface-edit-pin-3"
      label=""
      labelPosition="top"
      placeholder="Search Customers..."
    />
    <Table
      id="customersTable"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ getAllCustomers.data }}"
      defaultFilters={{
        0: {
          id: "ef725",
          columnId: "5410d",
          operator: "=",
          value: "{{ customersActiveInActiveFilter.value }}",
          disabled: false,
        },
      }}
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      heightType="auto"
      primaryKeyColumnId="4455a"
      rowHeight="medium"
      searchTerm="{{ searchCustomers.value }}"
      showBorder={true}
      showColumnBorders={true}
      showFooter={true}
      showHeader={true}
      style={{ headerBackground: "rgba(255, 244, 239, 1)" }}
    >
      <Column
        id="4455a"
        alignment="right"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="customer_id"
        label="Customer ID"
        placeholder="Enter value"
        position="center"
        size={82.34375}
        summaryAggregationMode="none"
      />
      <Column
        id="ca08f"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="name"
        label="Name"
        placeholder="Enter value"
        position="center"
        size={225.25}
        summaryAggregationMode="none"
      />
      <Column
        id="30241"
        alignment="left"
        format="phoneNumber"
        formatOptions={{
          showFormatting: true,
          showCountryCallingCode: true,
          restrictToCountry: true,
          restrictedCountry: "IN",
        }}
        groupAggregationMode="none"
        key="phone"
        label="Phone"
        placeholder="Enter value"
        position="center"
        size={109.6875}
        summaryAggregationMode="none"
      />
      <Column
        id="e30b3"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="gstin"
        label="GSTIN"
        placeholder="Enter value"
        position="center"
        size={124.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="1ad44"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="pan"
        label="PAN"
        placeholder="Enter value"
        position="center"
        size={90.8125}
        summaryAggregationMode="none"
      />
      <Column
        id="5dff7"
        alignment="center"
        format="boolean"
        groupAggregationMode="none"
        key="tcs_status"
        label="TCS"
        placeholder="Enter value"
        position="center"
        size={37.9375}
        summaryAggregationMode="none"
        valueOverride="{{ item }}"
      />
      <Column
        id="b7a79"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="zb_customer_id"
        label="ZB Customer ID"
        placeholder="Enter value"
        position="center"
        size={144.140625}
        summaryAggregationMode="none"
      />
      <Column
        id="5410d"
        alignment="center"
        format="boolean"
        groupAggregationMode="none"
        key="is_active"
        label="Is Active"
        placeholder="Enter value"
        position="center"
        size={61.484375}
        summaryAggregationMode="none"
      />
      <Column
        id="50906"
        alignment="center"
        format="button"
        formatOptions={{ variant: "solid" }}
        groupAggregationMode="none"
        label="Action"
        placeholder="Enter value"
        position="center"
        referenceId="edit"
        size={50.421875}
        summaryAggregationMode="none"
        valueOverride="Edit"
      >
        <Event
          id="90f59080"
          event="clickCell"
          method="show"
          pluginId="editCustomerModal"
          type="widget"
          waitMs={0}
          waitType="debounce"
        />
      </Column>
      <ToolbarButton
        id="1a"
        icon="bold/interface-text-formatting-filter-2"
        label="Filter"
        type="filter"
      />
      <ToolbarButton
        id="4d"
        icon="bold/interface-arrows-round-left"
        label="Refresh"
        type="custom"
      >
        <Event
          id="f55ac8b2"
          event="clickToolbar"
          method="trigger"
          params={{ ordered: [] }}
          pluginId="getProducts"
          type="datasource"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
    </Table>
  </Frame>
</Screen>
