<Screen
  id="warehouses"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={3}
  _searchParams={[{ ordered: [{ key: "_embed" }, { value: "true" }] }]}
  browserTitle=""
  title="Warehouses"
  urlSlug=""
  uuid="0f734224-86b3-427d-9de9-81773a3b15d8"
>
  <Folder id="saveWarehouseCompany">
    <SqlQueryUnified
      id="saveCompany"
      isMultiplayerEdited={false}
      query={include("../lib/saveCompany.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      warningCodes={[]}
    />
    <State id="selectwarehouseid" />
    <SqlQueryUnified
      id="getWarehouseCompanies"
      notificationDuration={4.5}
      query={include("../lib/getWarehouseCompanies.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updateCompanies"
      notificationDuration={4.5}
      query={include("../lib/updateCompanies.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="deleteCompanies"
      notificationDuration={4.5}
      query={include("../lib/deleteCompanies.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
  </Folder>
  <State id="selectedWarehouseId" />
  <SqlQueryUnified
    id="getWarehouseKeepersWarehouse"
    isHidden={false}
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/getWarehouseKeepersWarehouse.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getWarehouseBrands"
    isHidden={false}
    query={include("../lib/getWarehouseBrands.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getBrandsDistinct"
    isHidden={false}
    query={include("../lib/getBrandsDistinct.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="addWarehouseBrand"
    isHidden={false}
    query={include("../lib/addWarehouseBrand.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="updateWarehouseBrand"
    isHidden={false}
    query={include("../lib/updateWarehouseBrand.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getWarehouseTransporters"
    isHidden={false}
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/getWarehouseTransporters.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="addNewWarehouse"
    isHidden={false}
    isMultiplayerEdited={false}
    query={include("../lib/addNewWarehouse.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="deleteAllBrandsWarehouse"
    query={include("../lib/deleteAllBrandsWarehouse.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="deleteAllWarehouseKeepers"
    notificationDuration={4.5}
    query={include("../lib/deleteAllWarehouseKeepers.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="deleteWarehouse"
    notificationDuration={4.5}
    query={include("../lib/deleteWarehouse.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="deleteWarehouseBrand"
    notificationDuration={4.5}
    query={include("../lib/deleteWarehouseBrand.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <State id="editWarehouseNameVariable" />
  <State id="editWarehouseLocationVariable" />
  <SqlQueryUnified
    id="updateWarehouseName"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/updateWarehouseName.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <State id="editwarehouseID" />
  <Include src="./addCompanyModal.rsx" />
  <Include src="./addWarehouseBrandModal.rsx" />
  <Include src="./addWarehouseTransporterModal.rsx" />
  <Include src="./editCompanyModalUpdate.rsx" />
  <Include src="./editWarehouseBrandModal.rsx" />
  <Include src="./editWarehouseModal.rsx" />
  <Include src="./newWarehouseModal.rsx" />
  <Frame
    id="$main4"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <Container
      id="container20"
      footerPadding="4px 12px"
      headerPadding="12px 12px"
      hoistFetching={true}
      padding="12px"
      showBody={true}
      showHeader={true}
      showHeaderBorder={false}
    >
      <Header>
        <Text
          id="containerTitle18"
          value="### Warehouses"
          verticalAlign="center"
        />
        <Button
          id="button1"
          iconBefore="bold/interface-add-circle-alternate"
          text="New"
        >
          <Event
            id="22019a7c"
            event="click"
            method="run"
            params={{ ordered: [{ src: "await newWarehouseModal.show();" }] }}
            pluginId=""
            type="script"
            waitMs="0"
            waitType="debounce"
          />
        </Button>
        <TextInput
          id="warehouseSerachInput"
          iconBefore="bold/interface-search"
          label=""
          labelPosition="top"
          placeholder="search warehouse"
          showClear={true}
          tooltipText="serach with warehouse name"
        >
          <Event
            id="3cfadebd"
            event="change"
            method="setValue"
            params={{ map: { value: "{{ self.value }}" } }}
            pluginId="warehouseSearchVariable"
            type="state"
            waitMs="0"
            waitType="debounce"
          />
        </TextInput>
      </Header>
      <View id="9adee" viewKey="View 1">
        <ListViewBeta
          id="listView5"
          _primaryKeys="{{ item.warehouse_id }}"
          data="{{ getWarehouses.data }}"
          enableInstanceValues={true}
          heightType="auto"
          itemWidth="200px"
          margin="0"
          numColumns={3}
          padding="0"
        >
          <Container
            id="container21"
            footerPadding="4px 12px"
            headerPadding="4px 12px"
            padding="12px"
            showBody={true}
            style={{
              ordered: [
                {
                  border:
                    "{{ item.warehouse_id == selectedWarehouseId.value?theme.primary:theme.surfacePrimaryBorder }}",
                },
                {
                  background:
                    "{{ item.warehouse_id == selectedWarehouseId.value?theme.tertiary:theme.surfacePrimary }}",
                },
              ],
            }}
          >
            <Header>
              <Text
                id="containerTitle19"
                value="#### {{ item }}"
                verticalAlign="center"
              />
            </Header>
            <View id="23ca0" viewKey="View 1">
              <IconText
                id="iconText7"
                icon="line/shipping-transfer-cart"
                text="{{ item.name }}"
              />
              <Icon
                id="icon2"
                horizontalAlign="center"
                icon="bold/interface-edit-write-2"
                style={{ map: { color: "primary" } }}
                tooltipText="Edit warehouse name"
              >
                <Event
                  id="634fbb03"
                  event="click"
                  method="show"
                  params={{}}
                  pluginId="editWarehouseModal"
                  type="widget"
                  waitMs="0"
                  waitType="debounce"
                />
                <Event
                  id="e25fdd14"
                  event="click"
                  method="setValue"
                  params={{ map: { value: "{{ item.name }}" } }}
                  pluginId="editWarehouseNameVariable"
                  type="state"
                  waitMs="0"
                  waitType="debounce"
                />
                <Event
                  id="87e16d3b"
                  event="click"
                  method="setValue"
                  params={{ map: { value: "{{ item.location }}" } }}
                  pluginId="editWarehouseLocationVariable"
                  type="state"
                  waitMs="0"
                  waitType="debounce"
                />
                <Event
                  id="5423ca5e"
                  event="click"
                  method="setValue"
                  params={{ map: { value: "{{ item.warehouse_id }}" } }}
                  pluginId="editwarehouseID"
                  type="state"
                  waitMs="0"
                  waitType="debounce"
                />
                <Event
                  id="6549d250"
                  event="click"
                  method="setValue"
                  params={{ map: { value: "{{ item.warehouse_id }}" } }}
                  pluginId="selectwarehouseid"
                  type="state"
                  waitMs="0"
                  waitType="debounce"
                />
              </Icon>
              <Text id="text39" verticalAlign="center" />
            </View>
            <Event
              id="308a89d0"
              event="click"
              method="run"
              params={{
                ordered: [
                  {
                    src: "await selectedWarehouseId.setValue(item.warehouse_id);",
                  },
                ],
              }}
              pluginId=""
              type="script"
              waitMs="0"
              waitType="debounce"
            />
          </Container>
        </ListViewBeta>
      </View>
    </Container>
    <Include src="./container22.rsx" />
    <Container
      id="skeletonImageWarehouse"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      hidden="{{ selectedWarehouseId.value != null }}"
      margin="0"
      padding="0"
      showBody={true}
      showBorder={false}
      style={{ ordered: [{ background: "rgba(255, 255, 255, 0)" }] }}
    >
      <View id="9adee" viewKey="View 1">
        <Image
          id="image2"
          heightType="fixed"
          horizontalAlign="center"
          retoolStorageFileId="b98ba2aa-e879-4e27-ae7d-83ebc600eb47"
          src="https://picsum.photos/id/1025/800/600"
          srcType="retoolStorageFileId"
        />
        <Text
          id="text40"
          horizontalAlign="center"
          value="###### Select a warehouse to view details"
          verticalAlign="center"
        />
      </View>
    </Container>
  </Frame>
</Screen>
