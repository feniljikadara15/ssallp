<Container
  id="enquiryDetailsContainer"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  hidden="{{ selectedEnquiryId.value == null }}"
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
>
  <Header>
    <Text
      id="containerTitle4"
      value="##### Enquiry #{{ selectedEnquiryId.value }}"
      verticalAlign="center"
    />
    <Button
      id="deleteEnquiryButton"
      hidden="{{ getEnquiries.data.enquiry_status[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] != '0' }}"
      iconBefore="bold/interface-delete-bin-1"
      loaderPosition="right"
      loading="{{ deleteEnquiry.isFetching || getEnquiries.isFetching }}"
      style={{ ordered: [{ background: "danger" }] }}
      text="Delete Enquiry"
    >
      <Event
        id="33674302"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await deleteEnquiryButton.setDisabled();\nawait deleteEnquiry.trigger();\nawait sendEnquiryRejectionToCustomer.trigger();\nawait getEnquiries.trigger();\nawait tabbedContainer1.setCurrentViewIndex(2);\nawait deleteEnquiryButton.setDisabled(false);\nawait selectedEnquiryId.setValue(null);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="createOrderButton"
      disabled="{{ getEnquiries.data.warehouse_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] == null || getEnquiries.data.transporter_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] == null }}"
      hidden="{{ getEnquiries.data.enquiry_status[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] != '0' }}"
      iconBefore="bold/interface-link-circle-alternate"
      loading="{{ createOrder.isFetching || insertOrderItems.isFetching || getEnquiries.isFetching || getOrders.isFetching }}"
      text="Create Order"
      tooltipText={
        '{{ (getEnquiries.data.warehouse_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] == null || getEnquiries.data.transporter_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] == null)?"Please select warehouse and transporter":"" }}'
      }
    >
      <Event
        id="b0675f7d"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await createOrderButton.setDisabled();\nawait createOrder.trigger();\nawait insertOrderItems.trigger();\nawait updateEnquiryStatus.trigger();\nawait sendEnquiryToCustomer.trigger();\nawait getEnquiries.trigger();\nawait getOrders.trigger();\nawait tabbedContainer1.setCurrentViewIndex(1);\nawait createOrderButton.setDisabled(false);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="restoreEnquiryButton"
      hidden="{{ getEnquiries.data.enquiry_status[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] != '5' }}"
      iconBefore="bold/interface-delete-bin-put-back-2"
      style={{ ordered: [{ background: "highlight" }] }}
      text="Restore"
    >
      <Event
        id="1180227b"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await restoreEnquiryButton.setDisabled();\nawait restoreEnquiry.trigger();\nawait getEnquiries.trigger();\nawait tabbedContainer1.setCurrentViewIndex(0);\nawait restoreEnquiryButton.setDisabled(false);\nawait restoreEnquiryButton.setHidden();\nawait deleteEnquiryButton.setHidden(false);\nawait tabbedContainer1.setCurrentViewIndex(0);\nawait createOrderButton.setHidden(false);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <View id="3843f" viewKey="View 1">
    <Include src="./container5.rsx" />
    <Container
      id="container6"
      footerPadding="4px 12px"
      headerPadding="12px 12px"
      padding="12px"
      showBody={true}
      showHeader={true}
      showHeaderBorder={false}
    >
      <Header>
        <Text
          id="containerTitle2"
          value="#### Enquiry Items"
          verticalAlign="center"
        />
      </Header>
      <View id="472d8" viewKey="View 1">
        <Table
          id="enquiryItemsTable"
          autoColumnWidth={true}
          cellSelection="none"
          clearChangesetOnSave={true}
          data="{{ getEnquiryItems.data }}"
          defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
          defaultSort={[{ object: { columnId: "ccc6d", direction: "asc" } }]}
          emptyMessage="No rows found"
          enableSaveActions={true}
          heightType="auto"
          primaryKeyColumnId="ccc6d"
          rowHeight="medium"
          rowSelection="none"
          showBorder={true}
          showColumnBorders={true}
          showFooter={true}
          showHeader={true}
          showSummaryRow={true}
          style={{
            summaryRowBackground: "tertiary",
            headerBackground: "tertiary",
          }}
          toolbarPosition="bottom"
        >
          <Column
            id="ccc6d"
            alignment="right"
            editable={false}
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            hidden="true"
            key="enquiry_item_id"
            label="Enquiry item ID"
            placeholder="Enter value"
            position="center"
            size={100}
          />
          <Column
            id="15462"
            alignment="left"
            format="string"
            groupAggregationMode="none"
            label="Category"
            placeholder="Enter value"
            position="center"
            referenceId="category"
            size={64.0625}
            summaryAggregationMode="none"
            valueOverride="{{ getProducts.data.category[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
          />
          <Column
            id="a4d3c"
            alignment="left"
            format="string"
            groupAggregationMode="none"
            label="Brand"
            placeholder="Enter value"
            position="center"
            referenceId="brand"
            size={47.234375}
            summaryAggregationMode="none"
            valueOverride="{{ getProducts.data.brand[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
          />
          <Column
            id="7a451"
            alignment="left"
            format="string"
            groupAggregationMode="none"
            label="Grade"
            placeholder="Enter value"
            position="center"
            referenceId="grade"
            size={47.65625}
            summaryAggregationMode="none"
            valueOverride="{{ getProducts.data.grade[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
          />
          <Column
            id="9736b"
            alignment="right"
            editable="{{ getEnquiries.data.enquiry_status[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] == 0 }}"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="quantity"
            label="Quantity"
            placeholder="Enter value"
            position="center"
            size={60.46875}
            summaryAggregationMode="none"
          />
          <Column
            id="52ba7"
            alignment="right"
            editable="{{ getEnquiries.data.enquiry_status[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] == 0 }}"
            editableOptions={{ showStepper: true }}
            format="currency"
            formatOptions={{
              currency: "INR",
              currencySign: "standard",
              notation: "standard",
              showSeparators: true,
              currencyDisplay: "symbol",
            }}
            groupAggregationMode="sum"
            key="unit_price"
            label="Unit price"
            placeholder="Enter value"
            position="center"
            size={66.59375}
            summaryAggregationMode="none"
          />
          <Column
            id="b6194"
            alignment="right"
            editableOptions={{ showStepper: true }}
            format="currency"
            formatOptions={{
              currency: "INR",
              currencySign: "standard",
              notation: "standard",
              showSeparators: true,
              currencyDisplay: "symbol",
            }}
            groupAggregationMode="sum"
            label="Total price"
            placeholder="Enter value"
            position="center"
            referenceId="total_price"
            size={72.140625}
            summaryAggregationMode="sum"
            valueOverride="{{ currentSourceRow.unit_price * currentSourceRow.quantity }}"
          />
          <ToolbarButton
            id="1a"
            icon="bold/interface-text-formatting-filter-2"
            label="Filter"
            type="filter"
          />
          <ToolbarButton
            id="4d"
            icon="bold/interface-arrows-round-left"
            label="Refresh"
            type="custom"
          />
          <Event
            id="e7bd43a9"
            event="save"
            method="run"
            params={{
              ordered: [
                {
                  src: "await enquiryItemsTableSaveHandler.trigger();\nawait enquiryItemsTable.refresh();",
                },
              ],
            }}
            pluginId=""
            type="script"
            waitMs="0"
            waitType="debounce"
          />
        </Table>
      </View>
    </Container>
    <Include src="./container7.rsx" />
  </View>
</Container>
