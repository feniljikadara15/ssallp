<ModalFrame
  id="importSingleCustomerModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="modalTitle36"
      value="#### Import Single Customer from Zoho Books"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton37"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="e918f269"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="importSingleCustomerModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="zbCustomerIDInput"
      label="Zoho Books Customer ID"
      labelPosition="top"
      pattern="^\d{18,19}$"
      patternType="regex"
      placeholder="Enter value"
    />
    <TextInput
      id="zbCustomerImportCheck"
      label="Import Check"
      labelPosition="top"
      placeholder="Enter value"
      readOnly="true"
      value={
        '{{ Number.isFinite(\n    getAllCustomers.data.customer_id[\n      getAllCustomers.data.zb_customer_id.indexOf(zbCustomerIDInput.value)\n    ]\n  )\n    ? "Customer Already Exists in the DB. Please check and activate if required."\n    : "Ready for Import" }}'
      }
    />
    <Button
      id="checkNewZBCustomerValidityButton"
      loading="{{ checkZBCustomerValidity.isFetching }}"
      text="Check Validity"
    >
      <Event
        id="d14a0191"
        event="click"
        method="trigger"
        params={{}}
        pluginId="checkZBCustomerValidity"
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Status
      id="ZBNewCustomerValidity"
      hidden="{{ checkZBCustomerValidity.data === null || checkZBCustomerValidity.data.message.length <= 0 }}"
      itemMode="static"
      maintainSpaceWhenHidden={true}
      margin="6px 8px 0px 4px"
      style={{ fontSize: "h6Font", fontWeight: "h6Font", fontFamily: "h6Font" }}
      value={
        '{{ checkZBCustomerValidity.data.message == "success" ? "valid" : "invalid" }}'
      }
    >
      <Option
        id="00030"
        color="{{ theme.success }}"
        icon="bold/interface-validation-check-circle"
        label="Valid"
        value="valid"
      />
      <Option
        id="00032"
        color="rgba(233, 0, 12, 1)"
        icon="bold/interface-delete-circle"
        label="Invalid"
        value="invalid"
      />
    </Status>
  </Body>
  <Footer>
    <Button
      id="importSingleZBCustomerWFButton"
      disabled={
        '{{!(Number.isFinite(\n    getAllCustomers.data.customer_id[\n      getAllCustomers.data.zb_customer_id.indexOf(zbCustomerIDInput.value)\n    ]\n  )) && ZBNewCustomerValidity.value == "invalid" }}'
      }
      loading="{{ importSingleZBCustomer.isFetching }}"
      text="Import"
    >
      <Event
        id="f71932c6"
        event="click"
        method="run"
        params={{
          map: {
            src: "await importSingleZBCustomerWFButton.setDisabled();\nawait importSingleZBCustomer.trigger();\nawait zbCustomerIDInput.clearValue();\nawait importSingleCustomerModal.setHidden();\nawait getCustomers.trigger();\nawait getAllCustomers.trigger();\nawait customersTable.refresh();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
