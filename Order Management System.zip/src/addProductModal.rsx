<ModalFrame
  id="addProductModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="modalTitle13"
      value="#### Add New Product"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton14"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="94971537"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="addProductModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="newProductName"
      inputTooltip="Product Names must be UNIQUE"
      label="Product Name"
      labelPosition="top"
      placeholder="Enter Name"
    />
    <TextArea
      id="newProductDescription"
      autoResize={true}
      label="Description"
      labelPosition="top"
      minLines="1"
      placeholder="Enter value"
    />
    <TextInput
      id="newProductBrand"
      label="Brand"
      labelPosition="top"
      placeholder="Enter value"
    />
    <TextInput
      id="newProductGrade"
      label="Grade"
      labelPosition="top"
      placeholder="Enter value"
    />
    <Select
      id="newProductCategory"
      emptyMessage="No options"
      itemMode="static"
      label="Category"
      labelPosition="top"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value=""
    >
      <Option id="135c7" value="Aggregate" />
      <Option id="13e72" disabled={false} hidden={false} value="Blocks" />
      <Option id="f5a43" disabled={false} hidden={false} value="Binding Wire" />
      <Option id="57446" value="Cement" />
      <Option id="d8c19" disabled={false} hidden={false} value="RMC" />
      <Option id="fe13e" disabled={false} hidden={false} value="Sand" />
      <Option id="91b43" value="Steel" />
      <Option id="fd29b" disabled={false} hidden={false} value="Tilefix" />
      <Option id="b73e5" disabled={false} hidden={false} value="White Cement" />
    </Select>
    <Select
      id="newProductUnit"
      emptyMessage="No options"
      itemMode="static"
      label="Unit"
      labelPosition="top"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value=""
    >
      <Option id="135c7" value="Bags" />
      <Option id="13e72" disabled={false} hidden={false} value="Bundles" />
      <Option id="f5a43" disabled={false} hidden={false} value="MTS" />
      <Option id="57446" value="M3" />
      <Option id="d8c19" disabled={false} hidden={false} value="Pieces" />
      <Option id="fe13e" disabled={false} hidden={false} value="MTS/Kgs" />
      <Option
        id="89cff"
        disabled={false}
        hidden={false}
        label="Nos"
        value="Nos "
      />
    </Select>
    <TextInput
      id="newProductSKU"
      inputTooltip="SKU Should be Unique for each product."
      label="SKU"
      labelPosition="top"
      placeholder="Enter value"
    />
    <TextInput
      id="newProductHSN"
      label="HSN/SAC"
      labelPosition="top"
      placeholder="Enter value"
    />
    <NumberInput
      id="newProductMRP"
      currency="INR"
      format="currency"
      inputValue={0}
      label="MRP"
      labelPosition="top"
      placeholder="Enter value"
      preventScroll={true}
      showClear={true}
      showSeparators={true}
      showStepper={true}
      value=""
    />
    <Select
      id="newProductGST"
      emptyMessage="No options"
      itemMode="static"
      label="GST Rate"
      labelPosition="top"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value=""
    >
      <Option id="135c7" label="5%" value="5" />
      <Option
        id="13e72"
        disabled={false}
        hidden={false}
        label="18%"
        value="18"
      />
      <Option
        id="f5a43"
        disabled={false}
        hidden={false}
        label="28%"
        value="28"
      />
    </Select>
  </Body>
  <Footer>
    <Button
      id="saveNewProductButton"
      disabled={
        '{{ addProduct.isFetching || addProductZB.isFetching || newProductName.value == "" }}'
      }
      loaderPosition="left"
      loading="{{ addProduct.isFetching || addProductZB.isFetching }} "
      text="Save"
    >
      <Event
        id="886b17a5"
        event="click"
        method="run"
        params={{
          map: {
            src: "await saveNewProductButton.setDisabled();\n\nawait getAllProducts.trigger();\nawait productsTable.refresh();\nawait addProductZB.trigger();\nawait addProduct.trigger({\n  additionalScope : {new_zb_item_id : addProductZB.data.item.item_id}\n}\n);\nawait addProductModal.setHidden();\nawait saveNewProductButton.setDisabled(false);",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
