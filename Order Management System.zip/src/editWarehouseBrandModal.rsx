<ModalFrame
  id="editWarehouseBrandModal"
  footerPadding="12px 12px"
  headerPadding="12px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showFooterBorder={false}
  showHeader={true}
  showHeaderBorder={false}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text id="modalTitle4" value="### Manage Brand" verticalAlign="center" />
    <Button
      id="modalCloseButton4"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ ordered: [{ border: "transparent" }] }}
      styleVariant="outline"
    >
      <Event
        id="02e74677"
        event="click"
        method="run"
        params={{ ordered: [{ src: "await editWarehouseBrandModal.hide();" }] }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Select
      id="editWarehouseBrand"
      data="{{ getBrandsDistinct.data }}"
      emptyMessage="No options"
      label="Brand"
      labelPosition="top"
      labels="{{ item.brand }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value="{{ warehouseBrandsTable.selectedRow.brand }}"
      values="{{ item.brand }}"
    />
    <Select
      id="editWarehouseKeeper"
      captionByIndex=""
      data="{{ getWarehouseKeepers.data }}"
      emptyMessage="No options"
      label="Warehouse Keeper"
      labelPosition="top"
      labels="{{ item.name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value="{{ warehouseBrandsTable.selectedSourceRow.warehouse_keeper_id }}"
      values="{{ item.warehouse_keeper_id }}"
    />
  </Body>
  <Footer>
    <Button
      id="button3"
      style={{ ordered: [{ background: "danger" }] }}
      text="Remove Brand "
    >
      <Event
        id="4c0c14ad"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await deleteWarehouseBrand.trigger();\nawait warehouseBrandsTable.refresh();\nawait editWarehouseBrandModal.hide();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="updateWarehouseBrandButton"
      disabled="{{ editWarehouseBrand.value == null || editWarehouseKeeper.value == null }}"
      loaderPosition="right"
      loading="{{ updateWarehouseBrand.isFetching || getWarehouseBrands.isFetching || getWarehouseKeepers.isFetching }}"
      text="Save"
    >
      <Event
        id="1794571d"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await updateWarehouseBrandButton.setDisabled();\nawait updateWarehouseBrand.trigger();\nawait warehouseBrandsTable.refresh();\nawait updateWarehouseBrandButton.setDisabled(false);\nawait editWarehouseBrandModal.hide();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
