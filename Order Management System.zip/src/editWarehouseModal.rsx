<ModalFrame
  id="editWarehouseModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="modalTitle17"
      value="#### Edit Warehouse"
      verticalAlign="center"
    />
    <Button id="addCompanyButton" text="Add Company">
      <Event
        id="c1ac41af"
        event="click"
        method="show"
        params={{}}
        pluginId="addCompanyModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="modalCloseButton18"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="fbde12c6"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="editWarehouseModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="editWarehouseNameInput"
      label="Warehouse Name"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ editWarehouseNameVariable.value }}"
    />
    <TextInput
      id="editWarehouseLocationInput"
      label="Location"
      labelPosition="top"
      placeholder="Enter value"
      value="{{ editWarehouseLocationVariable.value }}"
    />
    <Table
      id="getWarehouseCompaniesDetails"
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ getWarehouseCompanies.data }}"
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      heightType="auto"
      showBorder={true}
      showFooter={true}
      showHeader={true}
      toolbarPosition="bottom"
    >
      <Column
        id="3c312"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="company_name"
        label="Company name"
        placeholder="Enter value"
        position="center"
        size={125.765625}
        summaryAggregationMode="none"
      />
      <Column
        id="1df5f"
        alignment="center"
        format="string"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="country"
        label="Country"
        placeholder="Enter value"
        position="center"
        size={58.109375}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="18df3"
        alignment="center"
        format="string"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="state"
        label="State"
        placeholder="Enter value"
        position="center"
        size={86.34375}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="ed0cc"
        alignment="center"
        format="string"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="city"
        label="City"
        placeholder="Enter value"
        position="center"
        size={99.96875}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="57ced"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="address_line1"
        label="Address line 1"
        placeholder="Enter value"
        position="center"
        size={103.59375}
        summaryAggregationMode="none"
      />
      <Column
        id="c54d3"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="address_line2"
        label="Address line 2"
        placeholder="Enter value"
        position="center"
        size={104.59375}
        summaryAggregationMode="none"
      />
      <Column
        id="31214"
        alignment="left"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="pincode"
        label="Pincode"
        placeholder="Enter value"
        position="center"
        size={68.375}
        summaryAggregationMode="none"
      />
      <Column
        id="9f7df"
        alignment="left"
        format="button"
        formatOptions={{ variant: "solid" }}
        groupAggregationMode="none"
        label="Action"
        placeholder="Enter value"
        position="center"
        referenceId="action"
        size={100}
        summaryAggregationMode="none"
        valueOverride="Edit"
      >
        <Event
          id="66462e47"
          event="clickCell"
          method="show"
          params={{}}
          pluginId="editCompanyModalUpdate"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </Column>
      <ToolbarButton
        id="1a"
        icon="bold/interface-text-formatting-filter-2"
        label="Filter"
        type="filter"
      />
      <ToolbarButton
        id="3c"
        icon="bold/interface-download-button-2"
        label="Download"
        type="custom"
      >
        <Event
          id="a5c0e35e"
          event="clickToolbar"
          method="exportData"
          pluginId="getWarehouseCompaniesDetails"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
      <ToolbarButton
        id="4d"
        icon="bold/interface-arrows-round-left"
        label="Refresh"
        type="custom"
      >
        <Event
          id="f6b42eeb"
          event="clickToolbar"
          method="refresh"
          pluginId="getWarehouseCompaniesDetails"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
    </Table>
  </Body>
  <Footer>
    <Button
      id="updateWarehouseButton"
      loading="{{ updateWarehouseName.isFetching }}"
      text="Update"
    >
      <Event
        id="144fa631"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await updateWarehouseName.trigger();\nawait getWarehouses.trigger();\nawait editWarehouseModal.setHidden();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
