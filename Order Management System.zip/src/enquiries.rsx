<Screen
  id="enquiries"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={0}
  _searchParams={[{ ordered: [{ key: "_embed" }, { value: "true" }] }]}
  browserTitle=""
  title="Enquiries"
  urlSlug=""
  uuid="58bffbca-58bb-411e-89e7-39ca05e98ced"
>
  <Folder id="Enquiry_Form">
    <SqlQueryUnified
      id="getCategories"
      cacheKeyTtl="3600"
      enableCaching={true}
      isHidden={false}
      query={include("../lib/getCategories.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="getBrands"
      cacheKeyTtl="3600"
      enableCaching={true}
      isHidden={false}
      isMultiplayerEdited={false}
      query={include("../lib/getBrands.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="getGrades"
      cacheKeyTtl="3600"
      enableCaching={true}
      isHidden={false}
      query={include("../lib/getGrades.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="getUnit"
      cacheKeyTtl="3600"
      enableCaching={true}
      isHidden={false}
      query={include("../lib/getUnit.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="getLtp"
      isHidden={false}
      query={include("../lib/getLtp.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      warningCodes={[]}
    />
    <WorkflowRun
      id="triggerEnquiryWorkflow"
      isHidden={false}
      isMultiplayerEdited={false}
      notificationDuration="3"
      resourceName="WorkflowRun"
      successMessage="Enquiry created"
      workflowId="bbced930-2b97-49f5-8caa-8c5aeb13bf4e"
      workflowParams={include("../lib/triggerEnquiryWorkflow.json", "string")}
    />
    <SqlQueryUnified
      id="getCustomerSites"
      isHidden={false}
      query={include("../lib/getCustomerSites.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenPageLoads={true}
      warningCodes={[]}
    />
    <JavascriptQuery
      id="query8"
      isMultiplayerEdited={false}
      notificationDuration={4.5}
      query={include("../lib/query8.js", "string")}
      resourceName="JavascriptQuery"
      showSuccessToaster={false}
    />
    <RESTQuery
      id="checkZBCustomer"
      notificationDuration={4.5}
      query="contacts/{{ customerZohoBooksID.value}}?organization_id=60031284196"
      resourceDisplayName="ZB v3"
      resourceName="c5058a3e-b80a-4586-a22f-88cbcba8ab5f"
      showFailureToaster={false}
      showSuccessToaster={false}
    />
  </Folder>
  <Folder id="State_Code">
    <SqlQueryUnified
      id="updateBillingAddressStateCode"
      notificationDuration={4.5}
      query={include("../lib/updateBillingAddressStateCode.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <JavascriptQuery
      id="updateBillingAddressStateCodeJS"
      isMultiplayerEdited={false}
      query={include("../lib/updateBillingAddressStateCodeJS.js", "string")}
      resourceName="JavascriptQuery"
    />
    <RESTQuery
      id="updateAddressStateCodeZB_Billing"
      body={
        '[{"key":"state_code","value":"{{ getStateCodes.data.code[(getStateCodes.data.state_name.indexOf(billingAddressStateInput2.value))] }}"}]'
      }
      bodyType="json"
      isMultiplayerEdited={false}
      query="contacts/{{ customerZohoBooksID.value }}/address/{{ getBillingAddressIndividual.data.zb_address_id }}?organization_id=60031284196"
      resourceDisplayName="ZB v3"
      resourceName="c5058a3e-b80a-4586-a22f-88cbcba8ab5f"
      runWhenModelUpdates={false}
      type="PUT"
    />
    <RESTQuery
      id="updateAddressStateCodeZB_Shipping"
      body={
        '[{"key":"state_code","value":"{{ getStateCodes.data.code[(getStateCodes.data.state_name.indexOf(deliveryAddressStateInput2.value))] }}"}]'
      }
      bodyType="json"
      isMultiplayerEdited={false}
      query="contacts/{{ customerZohoBooksID.value }}/address/{{ getAddresses.data.zb_address_id[getAddresses.data.address_id.indexOf(getSites.data.address_id[getSites.data.site_id.indexOf(selectSite.value)])] }}?organization_id=60031284196"
      resourceDisplayName="ZB v3"
      resourceName="c5058a3e-b80a-4586-a22f-88cbcba8ab5f"
      runWhenModelUpdates={false}
      type="PUT"
    />
    <SqlQueryUnified
      id="updateShippingAddressStateCode"
      isMultiplayerEdited={false}
      notificationDuration={4.5}
      query={include("../lib/updateShippingAddressStateCode.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <JavascriptQuery
      id="updateShippingAddressStateCodeJS"
      isMultiplayerEdited={false}
      query={include("../lib/updateShippingAddressStateCodeJS.js", "string")}
      resourceName="JavascriptQuery"
    />
  </Folder>
  <Folder id="manageLoadingSlips">
    <SqlQueryUnified
      id="query20"
      query={include("../lib/query20.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      warningCodes={[]}
    />
  </Folder>
  <State id="selectedEnquiryId" />
  <SqlQueryUnified
    id="getTransportersWarehouseEnquiry"
    isHidden={false}
    query={include("../lib/getTransportersWarehouseEnquiry.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <State id="selectedItems" value="[]" />
  <SqlQueryUnified
    id="getProductId"
    isHidden={false}
    query={include("../lib/getProductId.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="createEnquiry"
    isHidden={false}
    query={include("../lib/createEnquiry.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="enquiryItemsTableSaveHandler"
    actionType="BULK_UPDATE_BY_KEY"
    bulkUpdatePrimaryKey="enquiry_item_id"
    editorMode="gui"
    isHidden={false}
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    records="{{ enquiryItemsTable.changesetArray }}"
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    tableName="enquiry_items"
  />
  <SqlQueryUnified
    id="createCustomer"
    isHidden={false}
    query={include("../lib/createCustomer.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getBillingAddress"
    isHidden={false}
    query={include("../lib/getBillingAddress.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getEnquiryItems"
    isHidden={false}
    query={include("../lib/getEnquiryItems.sql", "string")}
    queryDisabled="{{ selectedEnquiryId.value == null }}"
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="deleteEnquiry"
    isHidden={false}
    isMultiplayerEdited={false}
    query={include("../lib/deleteEnquiry.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="restoreEnquiry"
    isHidden={false}
    isMultiplayerEdited={false}
    query={include("../lib/restoreEnquiry.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="createOrder"
    isHidden={false}
    isMultiplayerEdited={false}
    notificationDuration="3"
    query={include("../lib/createOrder.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    successMessage="Order created"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="insertOrderItems"
    isHidden={false}
    query={include("../lib/insertOrderItems.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="updateWarehouse"
    isHidden={false}
    query={include("../lib/updateWarehouse.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="updateTransporter"
    isHidden={false}
    query={include("../lib/updateTransporter.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="updateEnquiryStatus"
    isHidden={false}
    query={include("../lib/updateEnquiryStatus.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getEnquirySummaryString"
    isHidden={false}
    query={include("../lib/getEnquirySummaryString.sql", "string")}
    queryDisabled="{{ selectedEnquiryId.value == null }}"
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <RESTQuery
    id="sendEnquiryToTransporter"
    body={
      '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "[Live] New Enquiry Transporter Delivery Confirmation Request",\n  "destination": {{ (String(getTransporters.data.phone_number[getTransporters.data.transporter_id.indexOf(selectTransporter.value)])).replace("+", "") }},\n  "userName": {{ selectTransporter.selectedLabel }} ,\n  "templateParams": [\n    {{ selectTransporter.selectedLabel }},\n    {{ getEnquirySummaryString.data.output_string[0] }} ,\n    {{`${((d = getEnquiries.data.delivery_date[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)].split(\'T\')[0].split(\'-\')) && `${d[2]}-${d[1]}-${d[0]}`)}`}},\n    \n{{(getAddresses.data.maps_link[getAddresses.data.address_id.indexOf(getEnquiries.data.delivery_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])]=== "")?"Not Available":getAddresses.data.maps_link[getAddresses.data.address_id.indexOf(getEnquiries.data.delivery_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])]}}\n  ],\n  "source": "retool",\n  "media": {},\n  "buttons": [],\n  "carouselCards": [],\n  "location": {},\n  "paramsFallbackValue": {\n    "FirstName": "Transporter"\n  }\n}'
    }
    bodyType="raw"
    headers={'[{"key":"Content-type","value":"application/json"}]'}
    isHidden={false}
    isMultiplayerEdited={false}
    notificationDuration="3"
    resourceDisplayName="WhatsApp API Calls via AiSensy"
    resourceName="8bf4c560-d928-418e-96e1-17235877d9f4"
    runWhenModelUpdates={false}
    successMessage="Enquiry sent to transporter"
    type="POST"
  />
  <RESTQuery
    id="sendEnquiryRejectionToCustomer"
    body={
      '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "Enquiry Rejection Customer Notification",\n    "destination": {{ (String(getCustomers.data.phone[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])])).replace("+", "") }},\n  "userName": {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }},\n  "templateParams": [\n    {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }},\n    {{ getEnquirySummaryString.data.output_string[0] }}\n  ],\n  "source": "Internal Enquiry",\n  "media": {},\n  "buttons": [],\n  "carouselCards": [],\n  "location": {},\n  "paramsFallbackValue": {\n    "FirstName": "Customer"\n  }\n}'
    }
    bodyType="raw"
    headers={'[{"key":"Content-type","value":"application/json"}]'}
    isHidden={false}
    resourceDisplayName="WhatsApp API Calls via AiSensy"
    resourceName="8bf4c560-d928-418e-96e1-17235877d9f4"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    type="POST"
  />
  <RESTQuery
    id="sendEnquiryToCustomer"
    body={
      '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "customer_order_confirmation_notification",\n  "destination": {{ (String(getCustomers.data.phone[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])])).replace("+", "") }},\n  "userName": {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }},\n  "templateParams": [\n    {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }},\n    {{ getEnquirySummaryString.data.output_string[0] }},\n    {{`${((d = getEnquiries.data.delivery_date[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)].split(\'T\')[0].split(\'-\')) && `${d[2]}-${d[1]}-${d[0]}`)}`}}\n  ],\n  "source": "retool workflow",\n  "media": {},\n  "buttons": [],\n  "carouselCards": [],\n  "location": {},\n  "paramsFallbackValue": {\n    "FirstName": "Customer"\n  }\n}'
    }
    bodyType="raw"
    headers={'[{"key":"Content-type","value":"application/json"}]'}
    isHidden={false}
    isMultiplayerEdited={false}
    resourceDisplayName="WhatsApp API Calls via AiSensy"
    resourceName="8bf4c560-d928-418e-96e1-17235877d9f4"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    type="POST"
  />
  <SqlQueryUnified
    id="query3"
    notificationDuration={4.5}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
  />
  <JavascriptQuery
    id="setPANNotApplicableIndividual"
    notificationDuration={4.5}
    query={include("../lib/setPANNotApplicableIndividual.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <SqlQueryUnified
    id="getBillingAddressIndividual"
    isHidden={false}
    query={include("../lib/getBillingAddressIndividual.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <JavascriptQuery
    id="query7"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/query7.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <JavascriptQuery
    id="query11"
    notificationDuration={4.5}
    query={include("../lib/query11.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <Include src="./enquiryDetailsModal.rsx" />
  <Include src="./newEnquiryModal.rsx" />
  <Frame
    id="$main"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    style={{ ordered: [] }}
    type="main"
  >
    <Include src="./tabbedContainer1.rsx" />
    <Include src="./enquiryDetailsContainer.rsx" />
    <Container
      id="skeletonImageEnquiry"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      hidden="{{ selectedEnquiryId.value != null }}"
      margin="0"
      padding="0"
      showBody={true}
      showBorder={false}
      style={{ ordered: [{ background: "rgba(255, 255, 255, 0)" }] }}
    >
      <View id="9adee" viewKey="View 1">
        <Image
          id="image5"
          heightType="fixed"
          horizontalAlign="center"
          retoolStorageFileId="b98ba2aa-e879-4e27-ae7d-83ebc600eb47"
          src="https://picsum.photos/id/1025/800/600"
          srcType="retoolStorageFileId"
        />
        <Text
          id="text44"
          horizontalAlign="center"
          value="###### Select an enquiry to view details"
          verticalAlign="center"
        />
      </View>
    </Container>
  </Frame>
</Screen>
