<ModalFrame
  id="addNewVehicleModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="text81"
      value="##### Add New Vehicle for Order {{ selectedOrderId.value }}"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton45"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="175590f5"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="addNewVehicleModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Text
      id="text82"
      value="###### Transporter : {{ selectTransporter2.selectedItem.transporter_name }}"
      verticalAlign="center"
    />
    <TextInput
      id="addNewVehicleNumberInput"
      label="Vehicle Number "
      labelPosition="top"
      placeholder="Enter New Vehicle Number"
    >
      <Event
        id="536645ca"
        event="change"
        method="trigger"
        params={{}}
        pluginId="checkVNforTransporter"
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </TextInput>
    <Status
      id="newVNStatus"
      itemMode="static"
      value="{{ checkVNforTransporter.data === false ? 'valid' : 'invalid' }}"
    >
      <Option
        id="00030"
        color="{{ theme.success }}"
        icon="bold/interface-validation-check-circle"
        label="New Vehicle Number for {{ selectTransporter2.selectedItem.transporter_name }}"
        value="valid"
      />
      <Option
        id="00032"
        color="{{ theme.danger }}"
        icon="bold/interface-delete-circle"
        label="Vehicle Number Already Exists for {{ selectTransporter2.selectedItem.transporter_name }}"
        value="invalid"
      />
    </Status>
  </Body>
  <Footer>
    <Button
      id="saveNewVehicleNumberButton"
      disabled="{{ newVNStatus.value === 'invalid' }}"
      loading="{{ addVehicleNumberToTransporter2.isFetching || getVehicleNumber.isFetching }}"
      text="Save"
    >
      <Event
        id="8801e785"
        event="click"
        method="run"
        params={{
          map: {
            src: "await addVehicleNumberToTransporter2.trigger({\n  onSuccess: async (data) => {\n    await getVehicleNumber.trigger({\n      onSuccess: async () => {\n        await selectVehicleNumber.setValue(data.vehicle_id[0]);\n        await addNewVehicleModal.setHidden();\n        await addNewVehicleNumberInput.clearValue();\n        \n        utils.showNotification({\n          title: \"Vehicle Number added Successfully\",\n          description: 'Vehicle ' + data.vehicle_number[0] + ' Added to : ' + selectTransporter2.selectedItem.transporter_name,\n          notificationType: \"success\"\n        });\n      }\n    });\n  }\n});",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
