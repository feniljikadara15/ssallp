<Container
  id="container30"
  currentViewKey="{{ self.viewKeys[0] }}"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
>
  <Header>
    <Button
      id="exportPendingCashBillButton"
      hidden="{{ cashBillsStatusTabs.value === 1 }}"
      iconAfter="bold/interface-arrows-bottom"
      loading="{{ getCashPendingExportData.isFetching }}"
      text="Export"
    >
      <Event
        id="7d2592aa"
        event="click"
        method="run"
        params={{ map: { src: "await getCashPendingExportData.trigger();" } }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Text id="text53" value="### Cash Bills" verticalAlign="center" />
    <Button
      id="exportCollectedCashBillButton"
      hidden="{{ cashBillsStatusTabs.value === 0 }}"
      iconAfter="bold/interface-arrows-bottom"
      loading="{{ getCashCollectedExportData.isFetching }}"
      text="Export"
    >
      <Event
        id="8259c569"
        event="click"
        method="exportData"
        params={{
          fileType: "xlsx",
          data: "{{ getCashCollectedDetailsExport.data }}",
          fileName:
            "{{ `Cash Bills Collected - ${new Date().toLocaleString('en-GB', { \n  day: '2-digit', month: '2-digit', year: 'numeric', \n  hour: '2-digit', minute: '2-digit', hour12: true \n})}` }}",
          options: { map: { sheetName: "Cash Bills Collected" } },
        }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Tabs
      id="cashBillsStatusTabs"
      itemMode="static"
      navigateContainer={true}
      targetContainerId="container30"
      value="{{ self.values[0] }}"
    >
      <Option id="3b618" value="Tab 1" />
      <Option id="e1b2f" value="Tab 2" />
      <Option id="2eead" value="Tab 3" />
    </Tabs>
    <DateRange
      id="pendingCashBillsDateRange"
      dateFormat="MMM d, yyyy"
      endPlaceholder="End date"
      hidden="{{ cashBillsStatusTabs.value != 0 }}"
      iconBefore="bold/interface-calendar-remove"
      label="Filter By Date"
      labelPosition="top"
      maxDate="{{ new Date() }}"
      showClear={true}
      startPlaceholder="Start date"
      textBetween="-"
      value={{
        start:
          '{{ new Date(new Date().getFullYear(), new Date().getMonth(), 1).toLocaleDateString("en-CA") }}',
        end: '{{ new Date().toISOString().split("T")[0] }}',
      }}
    />
    <DateRange
      id="collectedCashBillsDateRange"
      dateFormat="MMM d, yyyy"
      endPlaceholder="End date"
      hidden="{{ cashBillsStatusTabs.value != 1 }}"
      iconBefore="bold/interface-calendar-remove"
      label="Filter By Date"
      labelPosition="top"
      maxDate="{{ new Date() }}"
      showClear={true}
      startPlaceholder="Start date"
      textBetween="-"
      value={{
        start:
          '{{ new Date(new Date().getFullYear(), new Date().getMonth(), 1).toLocaleDateString("en-CA") }}',
        end: '{{ new Date().toISOString().split("T")[0] }}',
      }}
    />
    <TextInput
      id="searchCashBillsCustomer"
      label=""
      labelPosition="top"
      placeholder="Search by Party Name"
    />
    <TextInput
      id="searchCashBillsOrder"
      label=""
      labelPosition="top"
      placeholder="Search by Order Number"
    />
    <TextInput
      id="searchCashBillsLS"
      label=""
      labelPosition="top"
      placeholder="Search by Loading Slip Number"
    />
  </Header>
  <View id="4352f" label="Pending">
    <ListViewBeta
      id="cashBillsListView"
      data={
        '{{\n  getCashBillsPending.data.order_id\n    .map((_, i) =>\n      Object.fromEntries(\n        Object.entries(getCashBillsPending.data).map(([key, value]) => [key, value[i]])\n      )\n    )\n    .filter(order => {\n      const searchCustomer = (searchCashBillsCustomer.value || "").trim().toLowerCase();\n      const searchOrderNumber = (searchCashBillsOrder.value || "").trim();\n      const searchLS = (searchCashBillsLS.value || "").trim();\n\n      // --- Date filtering ---\n      const startDate = pendingCashBillsDateRange.value?.start;\n      const endDate = pendingCashBillsDateRange.value?.end;\n      const orderDate = new Date(order.order_date);\n      orderDate.setHours(0, 0, 0, 0);\n      const hasDates = startDate && endDate;\n      let start, end;\n      if (hasDates) {\n        start = new Date(startDate);\n        start.setHours(0, 0, 0, 0);\n        end = new Date(endDate);\n        end.setHours(23, 59, 59, 999);\n      }\n      const passesDateFilter =\n        !hasDates || (orderDate >= start && orderDate <= end);\n\n      // --- Customer name lookup ---\n      const customerIndex = getCustomers.data.customer_id.indexOf(order.customer_id);\n      const customerName = (getCustomers.data.name[customerIndex] || "").toLowerCase();\n      const passesCustomerSearch =\n        searchCustomer === "" || customerName.includes(searchCustomer);\n\n      // --- Order number search (order_id or last 4 digits of order_number) ---\n      const orderNumberLast4 = (order.order_number || "").replace(/.*(\\d{4})$/, "$1");\n      const passesOrderNumberSearch =\n        searchOrderNumber === "" ||\n        String(order.order_id).includes(searchOrderNumber) ||\n        orderNumberLast4.includes(searchOrderNumber);\n\n      // --- Loading slip filter (file name or last 4 of loading_slip_number) ---\n      const loadingSlipFileName = (order.loading_slip_file_name || "").toLowerCase();\n      const loadingSlipLast4 = String(order.loading_slip_number || "").replace(/.*(\\d{4})$/, "$1");\n      const passesLoadingSlipFilter =\n        searchLS === "" ||\n        loadingSlipFileName.includes(searchLS.toLowerCase()) ||\n        loadingSlipLast4.includes(searchLS);\n\n      return (\n        passesDateFilter &&\n        passesCustomerSearch &&\n        passesOrderNumberSearch &&\n        passesLoadingSlipFilter\n      );\n    })\n}}'
      }
      itemWidth="200px"
      margin="0"
      numColumns={3}
      padding="0"
    >
      <Container
        id="container31"
        footerPadding="4px 12px"
        headerPadding="4px 12px"
        padding="12px"
        showBody={true}
        style={{
          ordered: [
            {
              background:
                "{{ item.order_id == selectedCashBillId.value?theme.tertiary:theme.surfacePrimary }}",
            },
            {
              border:
                "{{ item.order_id == selectedCashBillId.value?theme.primary:theme.surfacePrimaryBorder }}",
            },
          ],
        }}
      >
        <Header>
          <Text
            id="containerTitle27"
            value="#### {{ item }}"
            verticalAlign="center"
          />
        </Header>
        <View id="20f62" viewKey="View 1">
          <IconText
            id="iconText9"
            icon="line/interface-file-clipboard-check"
            text="OD - {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(item.customer_id)] }} - {{ item.order_id }}"
          />
          <Text
            id="text52"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="**{{`${((d = item.order_date.split('T')[0].split('-')) && `${d[2]}-${d[1]}-${d[0]}`)}`}}**"
            verticalAlign="center"
          />
          <Text
            id="text83"
            horizontalAlign="right"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="****{{getAllLoadingSlipItems.data.loading_slip_file_name[getAllLoadingSlipItems.data.order_id.indexOf(item.order_id)]}}****"
            verticalAlign="center"
          />
        </View>
        <Event
          id="2f2b096b"
          event="click"
          method="setValue"
          params={{ ordered: [{ value: "{{ item.order_id }}" }] }}
          pluginId="selectedCashBillId"
          type="state"
          waitMs="0"
          waitType="debounce"
        />
      </Container>
    </ListViewBeta>
  </View>
  <View id="47426" label="Collected">
    <ListViewBeta
      id="cashBillsListView2"
      _primaryKeys=""
      data={
        '{{\n  getCashBillsCollected.data.order_id\n    .map((_, i) =>\n      Object.fromEntries(\n        Object.entries(getCashBillsCollected.data).map(([key, value]) => [key, value[i]])\n      )\n    )\n    .filter(order => {\n      const searchCustomer = (searchCashBillsCustomer.value || "").trim().toLowerCase();\n      const searchOrderNumber = (searchCashBillsOrder.value || "").trim();\n      const searchLS = (searchCashBillsLS.value || "").trim();\n\n      // --- Date filtering ---\n      const startDate = collectedCashBillsDateRange.value?.start;\n      const endDate = collectedCashBillsDateRange.value?.end;\n      const orderDate = new Date(order.order_date);\n      orderDate.setHours(0, 0, 0, 0);\n      const hasDates = startDate && endDate;\n      let start, end;\n      if (hasDates) {\n        start = new Date(startDate);\n        start.setHours(0, 0, 0, 0);\n        end = new Date(endDate);\n        end.setHours(23, 59, 59, 999);\n      }\n      const passesDateFilter =\n        !hasDates || (orderDate >= start && orderDate <= end);\n\n      // --- Customer name lookup ---\n      const customerIndex = getCustomers.data.customer_id.indexOf(order.customer_id);\n      const customerName = (getCustomers.data.name[customerIndex] || "").toLowerCase();\n      const passesCustomerSearch =\n        searchCustomer === "" || customerName.includes(searchCustomer);\n\n      // --- Order number search (order_id or last 4 digits of order_number) ---\n      const orderNumberLast4 = (order.order_number || "").replace(/.*(\\d{4})$/, "$1");\n      const passesOrderNumberSearch =\n        searchOrderNumber === "" ||\n        String(order.order_id).includes(searchOrderNumber) ||\n        orderNumberLast4.includes(searchOrderNumber);\n\n      // --- Loading slip filter (file name or last 4 of loading_slip_number) ---\n      const loadingSlipFileName = (order.loading_slip_file_name || "").toLowerCase();\n      const loadingSlipLast4 = String(order.loading_slip_number || "").replace(/.*(\\d{4})$/, "$1");\n      const passesLoadingSlipFilter =\n        searchLS === "" ||\n        loadingSlipFileName.includes(searchLS.toLowerCase()) ||\n        loadingSlipLast4.includes(searchLS);\n\n      return (\n        passesDateFilter &&\n        passesCustomerSearch &&\n        passesOrderNumberSearch &&\n        passesLoadingSlipFilter\n      );\n    })\n}}'
      }
      itemWidth="200px"
      margin="0"
      numColumns={3}
      padding="0"
    >
      <Container
        id="container33"
        footerPadding="4px 12px"
        headerPadding="4px 12px"
        padding="12px"
        showBody={true}
        style={{
          ordered: [
            {
              background:
                "{{ item.order_id == selectedCashBillId.value?theme.tertiary:theme.surfacePrimary }}",
            },
            {
              border:
                "{{ item.order_id == selectedCashBillId.value?theme.primary:theme.surfacePrimaryBorder }}",
            },
          ],
        }}
      >
        <Header>
          <Text
            id="containerTitle29"
            value="#### {{ item }}"
            verticalAlign="center"
          />
        </Header>
        <View id="20f62" viewKey="View 1">
          <IconText
            id="iconText10"
            icon="line/interface-file-clipboard-check"
            text="OD - {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(item.customer_id)] }} - {{ item.order_id }}"
          />
          <Text
            id="text54"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="**{{`${((d = item.order_date.split('T')[0].split('-')) && `${d[2]}-${d[1]}-${d[0]}`)}`}}**"
            verticalAlign="center"
          />
          <Text
            id="text89"
            horizontalAlign="right"
            style={{ ordered: [{ color: "rgba(13, 13, 13, 0.4)" }] }}
            value="****{{getAllLoadingSlipItems.data.loading_slip_file_name[getAllLoadingSlipItems.data.order_id.indexOf(item.order_id)]}}****"
            verticalAlign="center"
          />
        </View>
        <Event
          id="ae942474"
          event="click"
          method="setValue"
          params={{ ordered: [{ value: "{{ item.order_id }}" }] }}
          pluginId="selectedCashBillId"
          type="state"
          waitMs="0"
          waitType="debounce"
        />
      </Container>
    </ListViewBeta>
  </View>
</Container>
