<Container
  id="container7"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
>
  <Header>
    <Text
      id="containerTitle5"
      value="#### Transport Details"
      verticalAlign="center"
    />
    <Text
      id="text13"
      value="Assign a transporter and set delivery details"
      verticalAlign="center"
    />
  </Header>
  <View id="472d8" viewKey="View 1">
    <Select
      id="selectWarehouse"
      data="{{ getWarehouses.data }}"
      disabled=""
      emptyMessage="No options"
      iconBefore="bold/shipping-warehouse"
      label="Warehouse"
      labelPosition="top"
      labels="{{ item.name }}"
      overlayMaxHeight={375}
      placeholder="Select a warehouse"
      readOnly="{{ getEnquiries.data.enquiry_status[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] != 0 }}"
      required={true}
      showSelectionIndicator={true}
      value="{{ getEnquiries.data.warehouse_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] }}"
      values="{{ item.warehouse_id }}"
    >
      <Event
        id="c9237838"
        event="change"
        method="run"
        params={{
          ordered: [
            {
              src: "await updateWarehouse.trigger();\nawait getEnquiries.trigger();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Select>
    <Select
      id="selectTransporter"
      captionByIndex=""
      data="{{ getTransportersWarehouseEnquiry.data }}"
      disabled="{{ selectWarehouse.value == null }}"
      emptyMessage="No options"
      iconBefore="bold/shipping-transfer-truck"
      label="Transporter"
      labelPosition="top"
      labels="{{ item.transporter_name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      readOnly="{{ getEnquiries.data.enquiry_status[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] != 0 }}"
      required={true}
      showSelectionIndicator={true}
      value="{{ getEnquiries.data.transporter_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)] }}"
      values="{{ item.transporter_id }}"
    >
      <Event
        id="5f127919"
        event="change"
        method="run"
        params={{
          ordered: [
            {
              src: "await updateTransporter.trigger();\nawait getEnquiries.trigger();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Select>
    <Button
      id="notifyTransporterButton"
      disabled="{{ selectTransporter.value == null }}"
      iconBefore="bold/interface-alert-alarm-bell-1"
      text="Notify Transporter"
    >
      <Event
        id="506f8426"
        event="click"
        method="trigger"
        params={{ ordered: [] }}
        pluginId="sendEnquiryToTransporter"
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </View>
</Container>
