<ModalFrame
  id="newEnquiryModal"
  footerPadding="8px 12px"
  headerPadding="12px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showHeaderBorder={false}
  showOverlay={true}
  size="fullScreen"
>
  <Header>
    <Text id="modalTitle2" value="### New Enquiry" verticalAlign="center" />
    <Button
      id="modalCloseButton2"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ ordered: [{ border: "transparent" }] }}
      styleVariant="outline"
    >
      <Event
        id="465747e7"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await newEnquiryModal.setHidden();\nawait customerNameInput.clearValue();\nawait customerPhoneInput.clearValue();\nawait selectSite.clearValue();\nawait selectedItems.setValue([]);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Text
      id="text19"
      value="##### Customer Information"
      verticalAlign="center"
    />
    <TextInput
      id="customerZohoBooksID"
      disabled="{{ gstNotApplicableToggle.value == true }}"
      label="Zoho Books Customer ID"
      labelPosition="top"
      loading="false"
      placeholder="ZB Customer ID"
      readOnly="true"
      value="{{ getCustomers.data.zb_customer_id[getCustomers.data.customer_id.indexOf(customerNameInput.value)] }}"
    />
    <Select
      id="customerNameInput"
      allowCustomValue={true}
      captionByIndex=""
      data="{{ getCustomers.data }}"
      emptyMessage="No options"
      label="Customer Name"
      labelPosition="top"
      labels="{{ item.name }}"
      overlayMaxHeight={375}
      placeholder="Select or enter name"
      showSelectionIndicator={true}
      values="{{ item.customer_id }}"
    />
    <PhoneNumberInput
      id="customerPhoneInput"
      _lockSelectedCountry={true}
      label="Phone"
      labelPosition="top"
      lockedCountryCode="IN"
      value="{{ getCustomers.data.phone[getCustomers.data.customer_id.indexOf(customerNameInput.value)] }}"
    />
    <PhoneNumberInput
      id="additionalPhone1Input"
      _lockSelectedCountry={true}
      label="Additional Phone 1"
      labelPosition="top"
      lockedCountryCode="IN"
      value="{{ getCustomers.data.additional_phone_1[getCustomers.data.customer_id.indexOf(customerNameInput.value)] }}"
    />
    <PhoneNumberInput
      id="additionalPhone2Input"
      _lockSelectedCountry={true}
      label="Additional Phone 2"
      labelPosition="top"
      lockedCountryCode="IN"
      value="{{ getCustomers.data.additional_phone_2[getCustomers.data.customer_id.indexOf(customerNameInput.value)] }}"
    />
    <TextInput
      id="customerGstinInput"
      disabled="{{ gstNotApplicableToggle.value == true }}"
      label="GSTIN"
      labelPosition="top"
      placeholder="Enter GSTIN"
      value="{{ getCustomers.data.gstin[getCustomers.data.customer_id.indexOf(customerNameInput.value)] }}"
    />
    <TextInput
      id="customerPanInput"
      disabled="{{ panNotApplicableToggle.value == true }}"
      label="PAN"
      labelPosition="top"
      pattern="^[A-Z]{5}[0-9]{4}[A-Z]$"
      patternType="regex"
      placeholder="Enter PAN"
      value={
        '{{\n  getCustomers.data.pan[\n    getCustomers.data.customer_id.indexOf(customerNameInput.value)\n  ] ||\n  (\n    customerGstinInput.value &&\n    customerGstinInput.value.length === 15\n      ? customerGstinInput.value.substring(2, 12)\n      : ""\n  )\n}}\n'
      }
    />
    <Text
      id="text65"
      hidden="{{ (isNaN(Number(customerNameInput.value)) 
    ? 0 
    : (
        getCustomers.data.customer_id.includes(customerNameInput.value) 
          ? customerNameInput.value 
          : 0
      ) ) == 0 }}"
      value="###### ZB ID MATCH : {{checkZBCustomer.data.message}}"
      verticalAlign="center"
    />
    <Switch
      id="gstNotApplicableToggle"
      label="GST Not Applicable"
      style={{ map: { checkedBackground: "warning" } }}
    />
    <Switch
      id="panNotApplicableToggle"
      label="PAN Not Applicable"
      style={{ map: { checkedBackground: "warning" } }}
    />
    <Switch
      id="newEnquiryTcsStatus"
      hidden="true"
      label="TCS Applicable?"
      style={{ ordered: [{ checkedBackground: "success" }] }}
      value="{{ getCustomers.data.tcs_status[getCustomers.data.customer_id.indexOf(customerNameInput.value)] }}"
    />
    <Text id="text20" value="##### Billing Address" verticalAlign="center" />
    <TextInput
      id="billingAddressLine1Input"
      label="Address Line 1"
      labelPosition="top"
      loading=""
      placeholder="Enter address line 1"
      value="{{ getBillingAddressIndividual.data.line1[0] }}"
    />
    <TextInput
      id="billingAddressLine2Input"
      label="Address Line 2"
      labelPosition="top"
      placeholder="Enter address line 2"
      value="{{ getBillingAddressIndividual.data.line2[0] }}"
    />
    <TextInput
      id="billingAddressPincodeInput"
      customValidation={
        '{{(typeof self.value === \'number\' && !isNaN(self.value))?"":"Pincode can only contain numbers"}}'
      }
      label="Pincode"
      labelPosition="top"
      maxLength="6"
      minLength="6"
      placeholder="Enter pincode"
      value="{{ getBillingAddressIndividual.data.pincode[0] }}"
    />
    <TextInput
      id="billingAddressCityInput"
      label="City"
      labelPosition="top"
      placeholder="Enter city"
      value="{{ getBillingAddressIndividual.data.city[0] }}"
    />
    <Select
      id="billingAddressStateInput2"
      data="{{ getStateCodes.data }}"
      emptyMessage="No options"
      label="State"
      labelPosition="top"
      labels="{{ item.state_name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value="{{ getBillingAddressIndividual.data.state[0] }}"
      values="{{ item.state_name }}"
    />
    <Text id="text21" value="##### Delivery Address" verticalAlign="center" />
    <Select
      id="selectSite"
      allowCustomValue={true}
      customValidation={
        '{{ selectSite.value && selectSite.value.length >= 50 ? "Must be under 50 characters" : "" }}'
      }
      data="{{ getCustomerSites.data }}"
      emptyMessage="No options"
      label="Site"
      labelPosition="top"
      labels="{{ item.site_name }}"
      overlayMaxHeight={375}
      placeholder="Select or create site"
      showSelectionIndicator={true}
      values="{{ item.site_id }}"
    />
    <TextInput
      id="deliveryAddressLine1Input"
      label="Address Line 1"
      labelPosition="top"
      placeholder="Enter address line 1"
      value="{{ getAddresses.data.line1[getAddresses.data.address_id.indexOf(getSites.data.address_id[getSites.data.site_id.indexOf(selectSite.value)])] }}"
    />
    <TextInput
      id="deliveryAddressLine2Input"
      label="Address Line 2"
      labelPosition="top"
      placeholder="Enter address line 2"
      value="{{ getAddresses.data.line2[getAddresses.data.address_id.indexOf(getSites.data.address_id[getSites.data.site_id.indexOf(selectSite.value)])] }}"
    />
    <TextInput
      id="deliveryAddressCityInput"
      label="City"
      labelPosition="top"
      placeholder="Enter city"
      value="{{ getAddresses.data.city[getAddresses.data.address_id.indexOf(getSites.data.address_id[getSites.data.site_id.indexOf(selectSite.value)])] }}"
    />
    <TextInput
      id="deliveryAddressPincodeInput"
      customValidation={
        '{{(typeof self.value === \'number\' && !isNaN(self.value))?"":"Pincode can only contain numbers"}}'
      }
      label="Pincode"
      labelPosition="top"
      maxLength="6"
      minLength="6"
      placeholder="Enter pincode"
      value="{{ getAddresses.data.pincode[getAddresses.data.address_id.indexOf(getSites.data.address_id[getSites.data.site_id.indexOf(selectSite.value)])] }}"
    />
    <Select
      id="deliveryAddressStateInput2"
      data="{{ getStateCodes.data }}"
      emptyMessage="No options"
      label="State"
      labelPosition="top"
      labels="{{ item.state_name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      value="{{ getAddresses.data.state[getAddresses.data.address_id.indexOf(getSites.data.address_id[getSites.data.site_id.indexOf(selectSite.value)])] }}"
      values="{{ item.state_name }}"
    />
    <TextInput
      id="sitePersonNameInput"
      label="Site Person Name"
      labelPosition="top"
      placeholder="Enter site person name"
      value="{{ getSites.data.site_person_name[getSites.data.site_id.indexOf(selectSite.value)] }}"
    />
    <TextInput
      id="mapsLinkInput"
      iconBefore="bold/interface-link"
      label="Google Maps Link"
      labelPosition="top"
      patternType="url"
      placeholder="Paste maps link here"
      value="{{ getAddresses.data.maps_link[getAddresses.data.address_id.indexOf(getSites.data.address_id[getSites.data.site_id.indexOf(selectSite.value)])] }}"
    />
    <PhoneNumberInput
      id="sitePersonPhoneInput"
      _lockSelectedCountry={true}
      label="Site Person Phone"
      labelPosition="top"
      lockedCountryCode="IN"
      value="{{ getSites.data.site_person_contact[getSites.data.site_id.indexOf(selectSite.value)] }}"
    />
    <Date
      id="deliveryDateInput"
      dateFormat="MMM d, yyyy"
      datePlaceholder="{{ self.dateFormat.toUpperCase() }}"
      iconBefore="bold/interface-calendar"
      label="Delivery Date"
      labelPosition="top"
      value="{{ new Date() }}"
    />
    <Text id="text22" value="##### Enquiry Items" verticalAlign="center" />
    <Select
      id="selectCategory"
      data="{{ getCategories.data }}"
      emptyMessage="No options"
      label="Category"
      labelPosition="top"
      labels="{{ item.category }}"
      overlayMaxHeight={375}
      placeholder="Select a category"
      showSelectionIndicator={true}
      values="{{ item.category }}"
    />
    <NumberInput
      id="priceInput"
      currency="USD"
      inputValue={0}
      label="Price (with Tax)"
      labelPosition="top"
      labelWrap={true}
      min="0"
      placeholder="Enter value"
      preventScroll={true}
      showSeparators={true}
      showStepper={true}
      value="{{null}}"
    />
    <Select
      id="selectBrand"
      data="{{ getBrands.data }}"
      emptyMessage="No options"
      label="Brand"
      labelPosition="top"
      labels="{{ item.brand }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      values="{{ item.brand }}"
    />
    <Select
      id="selectGrade"
      data="{{ getGrades.data }}"
      emptyMessage="No options"
      label="Grade"
      labelPosition="top"
      labels="{{ item.grade }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      showSelectionIndicator={true}
      values="{{ item.grade }}"
    />
    <NumberInput
      id="quantityInput"
      currency="USD"
      inputValue={0}
      label="Quantity ({{ getUnit.data.unit[0] }})"
      labelPosition="top"
      labelWrap={true}
      min="1"
      placeholder="Enter value"
      preventScroll={true}
      showSeparators={true}
      showStepper={true}
      value=""
    />
    <NumberInput
      id="lastPriceInput"
      currency="USD"
      inputValue={0}
      label="Last Price"
      labelPosition="top"
      placeholder="Enter value"
      readOnly="true"
      showSeparators={true}
      showStepper={true}
      value="{{ getLtp.data.unit_price[0] }}"
    />
    <Link
      id="link1"
      iconBefore="bold/interface-add-circle-alternate"
      style={{ ordered: [{ text: "info" }] }}
      text="Add item"
    >
      <Event
        id="5a7d84a4"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "// Trigger to get the product ID\nawait getProductId.trigger();\n\nlet productId = getProductId.data.product_id[0];\nlet quantity = quantityInput.value;\nlet unitPrice = priceInput.value; // Assuming there's an input or value for unit price\n\n// Create a new entry in table format\nlet newEntry = {\n    product_id: productId,\n    quantity: quantity,\n    unit_price: unitPrice\n};\n\n// Get the current array of selected items\nlet oldTable = selectedItems.value || [];\n\n// Append the new entry to the array\noldTable.push(newEntry);\n\n// Update the selected items\nawait selectedItems.setValue(oldTable);\n\nawait newEnquiryItemsTable.refresh();\nawait selectCategory.clearValue();\nawait selectBrand.clearValue();\nawait selectGrade.clearValue();\nawait quantityInput.clearValue();\nawait priceInput.clearValue();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Link>
    <Table
      id="newEnquiryItemsTable"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ selectedItems.value }}"
      defaultSelectedRow={{ mode: "none", indexType: "display", index: 0 }}
      emptyMessage="No items added"
      enableSaveActions={true}
      heightType="auto"
      primaryKeyColumnId="04de2"
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      toolbarPosition="bottom"
    >
      <Column
        id="04de2"
        alignment="right"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="product_id"
        label="Product ID"
        placeholder="Enter value"
        position="center"
        size={72.046875}
        summaryAggregationMode="none"
      />
      <Column
        id="2b291"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        label="Category"
        placeholder="Enter value"
        position="center"
        referenceId="category"
        size={64.0625}
        summaryAggregationMode="none"
        valueOverride="{{ getProducts.data.category[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
      />
      <Column
        id="b62e0"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        label="Brand"
        placeholder="Enter value"
        position="center"
        referenceId="brand"
        size={47.234375}
        summaryAggregationMode="none"
        valueOverride="{{ getProducts.data.brand[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
      />
      <Column
        id="c6a58"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        label="Grade"
        placeholder="Enter value"
        position="center"
        referenceId="grade"
        size={47.65625}
        summaryAggregationMode="none"
        valueOverride="{{ getProducts.data.grade[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
      />
      <Column
        id="a9902"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="quantity"
        label="Quantity"
        placeholder="Enter value"
        position="center"
        size={60.46875}
        summaryAggregationMode="none"
      />
      <Column
        id="b1fd0"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="unit_price"
        label="Price (with Tax)"
        placeholder="Enter value"
        position="center"
        size={98.65625}
        summaryAggregationMode="none"
      />
    </Table>
  </Body>
  <Footer>
    <Button
      id="createEnquiryButton"
      disabled={
        '{{ customerNameInput.value == null || customerPhoneInput.value == "+91" || customerPhoneInput.value == "" || billingAddressLine1Input.value.length == 0 || billingAddressLine2Input.value.length == 0 || billingAddressCityInput.value.length == 0 || billingAddressStateInput2.value.length == 0 || billingAddressPincodeInput.value.length == 0 || deliveryAddressLine1Input.value.length == 0 || deliveryAddressLine2Input.value.length == 0 || deliveryAddressCityInput.value.length == 0 || deliveryAddressStateInput2.value.length == 0 || deliveryAddressPincodeInput.value.length == 0 || selectSite.value == null || sitePersonNameInput.value.length == 0 || sitePersonPhoneInput.value == "+91" || mapsLinkInput.value.length == 0 || selectedItems.value.length == 0 }}'
      }
      loaderPosition="right"
      loading="{{ triggerEnquiryWorkflow.isFetching || getEnquiries.isFetching || getCustomers.isFetching || getAddresses.isFetching}}"
      text="Create Enquiry"
    >
      <Event
        id="06ae95e6"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await createEnquiryButton.setDisabled();\nawait triggerEnquiryWorkflow.trigger();\nawait updateBillingAddressStateCodeJS.trigger();\nawait updateShippingAddressStateCodeJS.trigger();\nawait newEnquiryModal.hide();\nawait getEnquiries.trigger();\nawait getCustomers.trigger();\nawait getAddresses.trigger();\nawait getCustomerSites.trigger();\nawait getSites.trigger(); \nawait createEnquiryButton.setDisabled(false);\nawait customerNameInput.clearValue();\nawait customerPhoneInput.clearValue();\nawait selectSite.clearValue();\nawait selectedItems.setValue([]);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
