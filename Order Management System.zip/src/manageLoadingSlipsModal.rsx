<ModalFrame
  id="manageLoadingSlipsModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showHeader={true}
  showOverlay={true}
  size="large"
>
  <Header>
    <Text
      id="modalTitle10"
      value="### Manage Loading Slips"
      verticalAlign="center"
    />
    <Button
      id="createLoadingSlipsButton"
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      iconBefore="bold/interface-arrows-synchronize"
      loaderPosition="right"
      loading="{{ triggerLoadingSlipWorkflow.isFetching || getLoadingSlips.isFetching || getLoadingSlipItems.isFetching }}"
      style={{ ordered: [{ background: "highlight" }] }}
      text="Create Loading Slips"
    >
      <Event
        id="cfd17810"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await createLoadingSlipsButton.setDisabled();\nawait triggerLoadingSlipWorkflow.trigger();\nawait getLoadingSlips.trigger();\nawait getLoadingSlipItems.trigger();\nawait loadingSlipItemsTable.refresh();\nawait createLoadingSlipsButton.setDisabled(false);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="modalCloseButton10"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ ordered: [{ border: "transparent" }] }}
      styleVariant="outline"
    >
      <Event
        id="e8034b71"
        event="click"
        method="setHidden"
        params={{ ordered: [{ hidden: true }] }}
        pluginId="manageLoadingSlipsModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Date
      id="loadingSlipDate"
      dateFormat="MMM d, yyyy"
      datePlaceholder="{{ self.dateFormat.toUpperCase() }}"
      hidden="{{ getOrders.data.order_status[getOrders.data.order_id.indexOf(selectedOrderId.value)] != '1' }}"
      label=""
      labelPosition="top"
      textBefore="Date on LS"
      value="{{ new Date() }}"
    />
  </Header>
  <Body>
    <Table
      id="loadingSlipItemsTable"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ getLoadingSlipItems.data }}"
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      heightType="auto"
      primaryKeyColumnId="7fd08"
      rowHeight="medium"
      showBorder={true}
      showColumnBorders={true}
      showFooter={true}
      showHeader={true}
      style={{}}
      toolbarPosition="bottom"
    >
      <Column
        id="7fd08"
        alignment="right"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="loading_slip_item_id"
        label="Loading slip item ID"
        placeholder="Enter value"
        position="center"
        size={121.453125}
        summaryAggregationMode="none"
      />
      <Column
        id="78351"
        alignment="left"
        editableOptions={{ spellCheck: false }}
        format="string"
        formatOptions={{ showUnderline: "hover", underlineStyle: "solid" }}
        groupAggregationMode="none"
        key="loading_slip_file_name"
        label="Loading Slip No"
        placeholder="Enter value"
        position="center"
        size={99.9375}
        summaryAggregationMode="none"
        textColor="{{ theme.primary }}"
      >
        <Event
          id="cc9a8db4"
          event="clickCell"
          method="openUrl"
          params={{ ordered: [{ url: "{{ item }}" }] }}
          pluginId=""
          type="util"
          waitMs="0"
          waitType="debounce"
        />
      </Column>
      <Column
        id="98a00"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="brand"
        label="Brand"
        placeholder="Enter value"
        position="center"
        size={82.296875}
        summaryAggregationMode="none"
      />
      <Column
        id="c0c57"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="warehouse_keeper_name"
        label="Warehouse Keeper"
        placeholder="Enter value"
        position="center"
        size={116.171875}
        summaryAggregationMode="none"
      />
      <Column
        id="e8ab0"
        alignment="left"
        format="phoneNumber"
        formatOptions={{
          showFormatting: true,
          showCountryCallingCode: true,
          restrictToCountry: false,
        }}
        groupAggregationMode="none"
        key="warehouse_keeper_phone"
        label="Warehouse Keeper Phone"
        placeholder="Enter value"
        position="center"
        size={153.15625}
        summaryAggregationMode="none"
      />
      <Column
        id="748eb"
        alignment="center"
        editableOptions={{ spellCheck: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        hidden="false"
        key="status"
        label="Status"
        optionList={{
          mode: "manual",
          manualData: [
            {
              value: "Active",
              color: "rgba(24, 165, 5, 1)",
              textColor: "rgba(255, 255, 255, 1)",
            },
            {
              value: "Cancelled",
              color: "rgba(216, 0, 0, 1)",
              textColor: "rgba(255, 255, 255, 1)",
            },
            {
              value: "Sent",
              color: "rgba(77, 83, 255, 1)",
              icon: "bold/mail-chat-bubble-oval-check-alternate",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        referenceId="ls_status"
        size={68.046875}
        summaryAggregationMode="none"
      />
      <Column
        id="7bc06"
        alignment="center"
        format="button"
        formatOptions={{
          variant: "solid",
          buttonColor: "{{ theme.info }}",
          iconBefore: "bold/interface-link-circle-alternate",
        }}
        groupAggregationMode="none"
        label="View"
        placeholder="Enter value"
        position="center"
        referenceId="view"
        size={69.9375}
        summaryAggregationMode="none"
        valueOverride="View"
      >
        <Event
          id="fe0eca37"
          event="clickCell"
          method="openUrl"
          params={{ ordered: [{ url: "{{ currentSourceRow.url }}" }] }}
          pluginId=""
          type="util"
          waitMs="0"
          waitType="debounce"
        />
      </Column>
      <Column
        id="e740c"
        alignment="center"
        cellTooltip={
          '{{ currentSourceRow.warehouse_keeper_phone.length == 0?"No warehouse keeper assigned for this brand":"" }}'
        }
        cellTooltipMode="custom"
        format="button"
        formatOptions={{
          variant: "solid",
          buttonColor: "{{ theme.success }}",
          iconBefore: "bold/mail-send-envelope-alternate",
          disabled: "{{ currentSourceRow.warehouse_keeper_phone.length == 0 }}",
        }}
        groupAggregationMode="none"
        label="Send"
        placeholder="Enter value"
        position="center"
        referenceId="send"
        size={70.875}
        summaryAggregationMode="none"
        valueOverride="Send"
      >
        <Event
          id="d8e45273"
          event="clickCell"
          method="run"
          params={{
            map: {
              src: 'const target = (typeof currentSourceRow !== "undefined" && currentSourceRow && currentSourceRow.loading_slip_item_id) ? currentSourceRow : loadingSlipItemsTable.selectedSourceRow;\n\nif (!target || !target.loading_slip_item_id) {\n  utils.showNotification({ title: "Could not send", description: "Could not identify the loading slip row. Please reopen this window and try again.", notificationType: "error" });\n} else if (!target.warehouse_keeper_phone) {\n  utils.showNotification({ title: "Could not send", description: "No warehouse keeper phone number is assigned for this brand.", notificationType: "error" });\n} else if (!target.url) {\n  utils.showNotification({ title: "Could not send", description: "The loading slip file is not ready yet. Please regenerate the loading slip.", notificationType: "error" });\n} else {\n  await sendLoadingSlipToWarehouseKeeper.trigger({ additionalScope: { row: target } });\n\n  \n  if (sendLoadingSlipToWarehouseKeeper.data.success === "true") {\n    await updateLoadingSlipStatus.trigger({ additionalScope: { row: target } });\n  }\n\n\n\n  \n  await getLoadingSlipItems.trigger();\n  await loadingSlipItemsTable.refresh();\n}',
            },
          }}
          pluginId=""
          type="script"
          waitMs="0"
          waitType="debounce"
        />
      </Column>
      <Column
        id="9fcfb"
        alignment="center"
        format="button"
        formatOptions={{
          variant: "solid",
          buttonColor: "rgba(178, 1, 10, 1)",
          iconBefore: "bold/interface-delete-2-alternate",
        }}
        groupAggregationMode="none"
        hidden="false"
        label="Cancel"
        placeholder="Enter value"
        position="center"
        referenceId="cancel_ls"
        size={80.53125}
        summaryAggregationMode="none"
        valueOverride="Cancel"
      >
        <Event
          id="d85afbf3"
          event="clickCell"
          method="show"
          pluginId="confirmCancelLSModal"
          type="widget"
          waitMs={0}
          waitType="debounce"
        />
      </Column>
      <ToolbarButton
        id="4d"
        icon="bold/interface-arrows-round-left"
        label="Refresh"
        type="custom"
      >
        <Event
          id="0f030fa3"
          event="clickToolbar"
          method="refresh"
          params={{ ordered: [] }}
          pluginId="loadingSlipItemsTable"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
    </Table>
  </Body>
</ModalFrame>
