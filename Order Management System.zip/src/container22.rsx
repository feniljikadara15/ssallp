<Container
  id="container22"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  hidden="{{ selectedWarehouseId.value == null }}"
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
>
  <Header>
    <Text
      id="containerTitle20"
      value="#### {{ getWarehouses.data.name[getWarehouses.data.warehouse_id.indexOf(selectedWarehouseId.value)] }}"
      verticalAlign="center"
    />
    <Button
      id="button2"
      iconBefore="bold/interface-delete-bin-1"
      loaderPosition="left"
      loading="{{ deleteAllBrandsWarehouse.isFetching || deleteAllWarehouseKeepers.isFetching || deleteWarehouse.isFetching || getWarehouses.isFetching }}"
      style={{ ordered: [{ background: "danger" }] }}
      text="Delete Warehouse"
    >
      <Event
        id="70270cc2"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await button2.setDisabled();\nawait deleteAllBrandsWarehouse.trigger();\nawait deleteAllWarehouseKeepers.trigger();\nawait deleteWarehouse.trigger();\nawait getWarehouses.trigger();\nawait selectedWarehouseId.setValue(null);\nawait button2.setDisabled(false);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button id="addBrandButton" text="Add Brand">
      <Event
        id="695eef28"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await getBrandsDistinct.trigger();\nawait addWarehouseBrandModal.show();",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <View id="9adee" viewKey="View 1">
    <Table
      id="warehouseBrandsTable"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{getWarehouseBrands.data}}"
      defaultSelectedRow={{ mode: "none", indexType: "display", index: 0 }}
      defaultSort={[{ object: { columnId: "4207f", direction: "asc" } }]}
      emptyMessage="No rows found"
      enableSaveActions={true}
      heightType="auto"
      primaryKeyColumnId="4207f"
      rowHeight="medium"
      showBorder={true}
      showColumnBorders={true}
      showFooter={true}
      showHeader={true}
      toolbarPosition="bottom"
    >
      <Column
        id="4207f"
        alignment="right"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="warehouse_brands_id"
        label="Warehouse brands ID"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="bf4a0"
        alignment="left"
        editable={false}
        format="string"
        groupAggregationMode="none"
        key="brand"
        label="Brand"
        placeholder="Enter value"
        position="center"
        size={82.296875}
        summaryAggregationMode="none"
      />
      <Column
        id="86024"
        alignment="left"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="warehouse_keeper_id"
        label="Warehouse Keeper"
        placeholder="Enter value"
        position="center"
        referenceId="cu"
        size={116.171875}
        summaryAggregationMode="none"
        valueOverride="{{ getWarehouseKeepers.data.name[getWarehouseKeepers.data.warehouse_keeper_id.indexOf(currentSourceRow.warehouse_keeper_id)] }}"
      />
      <Column
        id="c2618"
        alignment="left"
        format="button"
        formatOptions={{
          variant: "solid",
          buttonColor: "{{ theme.danger }}",
          iconBefore: "bold/interface-link-circle-alternate",
        }}
        groupAggregationMode="none"
        label="Actions"
        placeholder="Enter value"
        position="center"
        referenceId="actions"
        size={77.8125}
        summaryAggregationMode="none"
        valueOverride="Delete"
      >
        <Event
          id="a88bcad0"
          event="clickCell"
          method="run"
          params={{
            ordered: [
              {
                src: "await deleteWarehouseBrand.trigger();\nawait warehouseBrandsTable.refresh();",
              },
            ],
          }}
          pluginId=""
          type="script"
          waitMs={0}
          waitType="debounce"
        />
      </Column>
      <ToolbarButton
        id="4d"
        icon="bold/interface-arrows-round-left"
        label="Refresh"
        type="custom"
      >
        <Event
          id="7bffb039"
          event="clickToolbar"
          method="refresh"
          pluginId="warehouseBrandsTable"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
      <Event
        id="6c1c1c8c"
        event="save"
        method="trigger"
        params={{ ordered: [] }}
        pluginId="warehouseBrandsTableSaveHandler"
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
      <Event
        id="8ca950b1"
        event="doubleClickRow"
        method="run"
        params={{ ordered: [{ src: "await editWarehouseBrandModal.show();" }] }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Table>
    <Table
      id="warehouseTransporterTable"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{getWarehouseTransporters.data}}"
      defaultSelectedRow={{ mode: "none", indexType: "display", index: 0 }}
      defaultSort={[{ object: { columnId: "4207f", direction: "asc" } }]}
      emptyMessage="No rows found"
      enableSaveActions={true}
      heightType="auto"
      primaryKeyColumnId="b69c6"
      rowHeight="medium"
      showBorder={true}
      showColumnBorders={true}
      showFooter={true}
      showHeader={true}
      toolbarPosition="bottom"
    >
      <Column
        id="0b173"
        alignment="right"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="transporter_id"
        label="Transporter ID"
        placeholder="Enter value"
        position="center"
        size={92.25}
        summaryAggregationMode="none"
      />
      <Column
        id="1833d"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="transporter_name"
        label="Transporter name"
        placeholder="Enter value"
        position="center"
        size={111.21875}
        summaryAggregationMode="none"
      />
      <Column
        id="922c6"
        alignment="left"
        editableOptions={{ showStepper: true }}
        format="phoneNumber"
        formatOptions={{
          showFormatting: true,
          showCountryCallingCode: true,
          restrictToCountry: true,
          restrictedCountry: "IN",
        }}
        groupAggregationMode="sum"
        key="phone_number"
        label="Phone number"
        placeholder="Enter value"
        position="center"
        size={109.6875}
        summaryAggregationMode="none"
      />
      <Column
        id="099e5"
        alignment="left"
        editableOptions={{ showStepper: true }}
        format="phoneNumber"
        formatOptions={{
          showFormatting: true,
          showCountryCallingCode: true,
          restrictToCountry: true,
          restrictedCountry: "IN",
        }}
        groupAggregationMode="sum"
        key="additional_mobile_number"
        label="Additional mobile number"
        placeholder="Enter value"
        position="center"
        size={153.234375}
        summaryAggregationMode="none"
      />
      <Column
        id="b69c6"
        alignment="right"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="transporter_warehouse_id"
        label="Transporter warehouse ID"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <ToolbarButton
        id="4d"
        icon="bold/interface-arrows-round-left"
        label="Refresh"
        type="custom"
      >
        <Event
          id="53330872"
          event="clickToolbar"
          method="refresh"
          pluginId="warehouseTransporterTable"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </ToolbarButton>
      <Event
        id="f8773b47"
        event="save"
        method="trigger"
        params={{ ordered: [] }}
        pluginId="warehouseBrandsTableSaveHandler"
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Table>
  </View>
</Container>
