<Container
  id="container32"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  hidden="{{ selectedCashBillId.value == null }}"
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
>
  <Header>
    <Text
      id="containerTitle28"
      value="#### Cash Bill: Order #{{ selectedCashBillId.value }}"
      verticalAlign="center"
    />
    <Button
      id="collectPaymentButton"
      hidden="{{ (getCashBillItems.data.total_price.reduce((sum, val) => sum + Number(val), 0)
) - (getCashPayments.data.amount.reduce((sum, val) => sum + Number(val), 0)) == 0 }}"
      iconBefore="bold/money-cash-bag-share"
      text="Collect Payment"
    >
      <Event
        id="a055604d"
        event="click"
        method="show"
        params={{ ordered: [] }}
        pluginId="collectPaymentModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Text
      id="containerTitle39"
      value="**{{  getCashBillsPending.data.order_number[getOrders.data.order_id.indexOf(selectedCashBillId.value)] }}**"
      verticalAlign="center"
    />
  </Header>
  <View id="004a2" viewKey="View 1">
    <Include src="./container34.rsx" />
    <Container
      id="container35"
      footerPadding="4px 12px"
      headerPadding="12px 12px"
      padding="12px"
      showBody={true}
      showHeader={true}
      showHeaderBorder={false}
    >
      <Header>
        <Text
          id="containerTitle31"
          value="#### Collected Payments"
          verticalAlign="center"
        />
        <Text
          id="text58"
          horizontalAlign="right"
          value="##### Pending: ₹ {{ (getCashBillItems.data.total_price.reduce((sum, val) => sum + Number(val), 0)
) - (getCashPayments.data.amount.reduce((sum, val) => sum + Number(val), 0)) }}"
          verticalAlign="center"
        />
      </Header>
      <View id="472d8" viewKey="View 1">
        <Table
          id="cashCollectedTable"
          autoColumnWidth={true}
          cellSelection="none"
          clearChangesetOnSave={true}
          data="{{ getCashPayments.data }}"
          defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
          defaultSort={[
            { object: { columnId: "ee79e", direction: "asc" } },
            { object: { columnId: "9abe2", direction: "asc" } },
          ]}
          emptyMessage="No rows found"
          enableSaveActions={true}
          heightType="auto"
          primaryKeyColumnId="9abe2"
          rowHeight="medium"
          rowSelection="none"
          showBorder={true}
          showColumnBorders={true}
          showFooter={true}
          showHeader={true}
          showSummaryRow={true}
          style={{
            headerBackground: "tertiary",
            summaryRowBackground: "tertiary",
          }}
          toolbarPosition="bottom"
        >
          <Column
            id="9abe2"
            alignment="right"
            editable="false"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            hidden="true"
            key="cash_collected_id"
            label="Cash collected ID"
            placeholder="Enter value"
            position="center"
            size={108.84375}
            summaryAggregationMode="none"
          />
          <Column
            id="cb1ac"
            alignment="left"
            format="date"
            groupAggregationMode="none"
            key="collection_date"
            label="Collection date"
            placeholder="Enter value"
            position="center"
            size={96.015625}
            summaryAggregationMode="none"
          />
          <Column
            id="ece95"
            alignment="left"
            format="string"
            groupAggregationMode="none"
            key="receipt_number"
            label="Receipt number"
            placeholder="Enter value"
            position="center"
            size={99.890625}
            summaryAggregationMode="none"
          />
          <Column
            id="662cf"
            alignment="right"
            editableOptions={{ showStepper: true }}
            format="currency"
            formatOptions={{
              currency: "INR",
              currencySign: "standard",
              notation: "standard",
              showSeparators: true,
              currencyDisplay: "symbol",
            }}
            groupAggregationMode="sum"
            key="amount"
            label="Amount"
            placeholder="Enter value"
            position="center"
            size={58.359375}
            summaryAggregationMode="sum"
          />
          <ToolbarButton
            id="1a"
            icon="bold/interface-text-formatting-filter-2"
            label="Filter"
            type="filter"
          />
          <ToolbarButton
            id="4d"
            icon="bold/interface-arrows-round-left"
            label="Refresh"
            type="custom"
          >
            <Event
              id="f032259d"
              event="clickToolbar"
              method="refresh"
              params={{ ordered: [] }}
              pluginId="cashCollectedTable"
              type="widget"
              waitMs="0"
              waitType="debounce"
            />
          </ToolbarButton>
          <Event
            id="1eb7d06e"
            event="save"
            method="run"
            params={{
              ordered: [
                {
                  src: "await orderItemsTableSaveHandler.trigger();\ncashCollectedTable.refresh();",
                },
              ],
            }}
            pluginId=""
            type="script"
            waitMs="0"
            waitType="debounce"
          />
        </Table>
      </View>
    </Container>
    <Container
      id="container36"
      footerPadding="4px 12px"
      headerPadding="12px 12px"
      padding="12px"
      showBody={true}
      showHeader={true}
      showHeaderBorder={false}
    >
      <Header>
        <Text
          id="containerTitle32"
          value="#### Order Items"
          verticalAlign="center"
        />
      </Header>
      <View id="472d8" viewKey="View 1">
        <Table
          id="cashBillItemsTable2"
          autoColumnWidth={true}
          cellSelection="none"
          clearChangesetOnSave={true}
          data="{{ getCashBillItems.data }}"
          defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
          defaultSort={[{ object: { columnId: "ee79e", direction: "asc" } }]}
          emptyMessage="No rows found"
          enableSaveActions={true}
          heightType="auto"
          primaryKeyColumnId="ee79e"
          rowHeight="medium"
          rowSelection="none"
          showBorder={true}
          showColumnBorders={true}
          showFooter={true}
          showHeader={true}
          showSummaryRow={true}
          style={{
            headerBackground: "tertiary",
            summaryRowBackground: "tertiary",
          }}
          toolbarPosition="bottom"
        >
          <Column
            id="ee79e"
            alignment="right"
            editable={false}
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            hidden="true"
            key="order_item_id"
            label="Order item ID"
            placeholder="Enter value"
            position="center"
            size={86.171875}
            summaryAggregationMode="none"
          />
          <Column
            id="15462"
            alignment="left"
            format="string"
            groupAggregationMode="none"
            label="Category"
            placeholder="Enter value"
            position="center"
            referenceId="category"
            size={64.0625}
            summaryAggregationMode="none"
            valueOverride="{{ getProducts.data.category[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
          />
          <Column
            id="a4d3c"
            alignment="left"
            format="string"
            groupAggregationMode="none"
            label="Brand"
            placeholder="Enter value"
            position="center"
            referenceId="brand"
            size={47.234375}
            summaryAggregationMode="none"
            valueOverride="{{ getProducts.data.brand[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
          />
          <Column
            id="7a451"
            alignment="left"
            format="string"
            groupAggregationMode="none"
            label="Grade"
            placeholder="Enter value"
            position="center"
            referenceId="grade"
            size={47.65625}
            summaryAggregationMode="none"
            valueOverride="{{ getProducts.data.grade[getProducts.data.product_id.indexOf(currentSourceRow.product_id)] }}"
          />
          <Column
            id="c698c"
            alignment="right"
            editable={false}
            editableOptions={{ showStepper: true, min: "0" }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="quantity"
            label="Quantity"
            placeholder="Enter value"
            position="center"
            size={60.46875}
            summaryAggregationMode="none"
          />
          <Column
            id="45215"
            alignment="right"
            editable={false}
            editableOptions={{ showStepper: false, min: "0" }}
            format="currency"
            formatOptions={{
              currency: "INR",
              currencySign: "standard",
              notation: "standard",
              showSeparators: true,
              currencyDisplay: "symbol",
              decimalPlaces: "",
            }}
            groupAggregationMode="sum"
            key="unit_price"
            label="Unit price"
            placeholder="Enter value"
            position="center"
            size={66.59375}
            summaryAggregationMode="none"
          />
          <Column
            id="a6619"
            alignment="right"
            editableOptions={{ showStepper: true }}
            format="currency"
            formatOptions={{
              currency: "INR",
              currencySign: "standard",
              notation: "standard",
              showSeparators: true,
              currencyDisplay: "symbol",
              decimalPlaces: "",
            }}
            groupAggregationMode="sum"
            label="Total price"
            placeholder="Enter value"
            position="center"
            referenceId="total_price"
            size={72.140625}
            summaryAggregationMode="sum"
            valueOverride="{{ currentSourceRow.unit_price * currentSourceRow.quantity }}"
          />
          <ToolbarButton
            id="1a"
            icon="bold/interface-text-formatting-filter-2"
            label="Filter"
            type="filter"
          />
          <ToolbarButton
            id="4d"
            icon="bold/interface-arrows-round-left"
            label="Refresh"
            type="custom"
          >
            <Event
              id="f162f054"
              event="clickToolbar"
              method="refresh"
              params={{ ordered: [] }}
              pluginId="cashBillItemsTable2"
              type="widget"
              waitMs="0"
              waitType="debounce"
            />
          </ToolbarButton>
          <Event
            id="78b24f76"
            event="save"
            method="run"
            params={{
              ordered: [
                {
                  src: "await orderItemsTableSaveHandler.trigger();\ncashBillItemsTable2.refresh();",
                },
              ],
            }}
            pluginId=""
            type="script"
            waitMs="0"
            waitType="debounce"
          />
        </Table>
      </View>
    </Container>
  </View>
</Container>
