<Screen
  id="transporterVehicleDetails"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={9}
  _searchParams={[]}
  browserTitle=""
  title={null}
  urlSlug=""
  uuid="6c02fbc9-e929-42f4-818e-b0fe55d7fce6"
>
  <SqlQueryUnified
    id="getVehicleDetails"
    notificationDuration={4.5}
    query={include("../lib/getVehicleDetails.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="query12"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/query12.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <Frame
    id="$main10"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <Text
      id="customersPageHeading2"
      value="### Transporter Vehicle Details"
      verticalAlign="center"
    />
    <Divider id="divider13" />
    <TextInput
      id="transportersSearchinput"
      iconBefore="bold/interface-search"
      label=""
      labelPosition="top"
      placeholder="Search with transporter or vehicle number"
      showClear={true}
    />
    <Table
      id="VehicleTransporterDetais"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ query12.data }}"
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      heightType="auto"
      rowHeight="medium"
      showBorder={true}
      showColumnBorders={true}
      showFooter={true}
      showHeader={true}
      style={{ headerBackground: "rgba(255, 244, 239, 1)" }}
    >
      <Column
        id="fbf69"
        alignment="right"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        hidden="true"
        key="transporter_id"
        label="Transporter ID"
        placeholder="Enter value"
        position="center"
        size={92.3125}
        summaryAggregationMode="none"
      />
      <Column
        id="0dc91"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        label="S.NO"
        placeholder="Enter value"
        position="center"
        referenceId="sNo"
        size={45.125}
        summaryAggregationMode="none"
        valueOverride="{{ i+1 }}"
      />
      <Column
        id="8130f"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="vehicle_number"
        label="Vehicle number"
        placeholder="Enter value"
        position="center"
        size={103.671875}
        summaryAggregationMode="none"
      />
      <Column
        id="34d43"
        alignment="center"
        format="string"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="transporter_name"
        label="Transporter name"
        placeholder="Enter value"
        position="center"
        size={123.515625}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="417a8"
        alignment="center"
        format="phoneNumber"
        formatOptions={{
          showFormatting: true,
          showCountryCallingCode: true,
          restrictToCountry: false,
        }}
        groupAggregationMode="none"
        key="transporter_phone"
        label="Transporter phone"
        placeholder="Enter value"
        position="center"
        size={121.59375}
        summaryAggregationMode="none"
      />
    </Table>
  </Frame>
</Screen>
