<Container
  id="container5"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
>
  <Header>
    <Text
      id="containerTitle1"
      value="#### Customer Information"
      verticalAlign="center"
    />
  </Header>
  <View id="472d8" viewKey="View 1">
    <Text
      id="text1"
      value="**Name**
{{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}"
      verticalAlign="center"
    />
    <Text
      id="text2"
      value="**Phone**
{{ getCustomers.data.phone[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}"
      verticalAlign="center"
    />
    <Text
      id="text3"
      style={{
        ordered: [
          { fontSize: "defaultFont" },
          { fontWeight: "defaultFont" },
          { fontFamily: "defaultFont" },
        ],
      }}
      value={
        '**PAN**\n{{ getCustomers.data.pan[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] == null? "Not Applicable": getCustomers.data.pan[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}'
      }
      verticalAlign="center"
    />
    <Text
      id="text4"
      value={
        '**GSTIN**\n{{ getCustomers.data.gstin[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] != null? getCustomers.data.gstin[getCustomers.data.customer_id.indexOf(getEnquiries.data.customer_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])]:"Not Applicable" }}'
      }
      verticalAlign="center"
    />
    <Divider
      id="divider1"
      style={{ ordered: [{ color: "rgba(195, 191, 191, 1)" }] }}
    />
    <Text
      id="text12"
      value="**Site**
{{ getSites.data.site_name[getSites.data.site_id.indexOf(getEnquiries.data.site_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}"
      verticalAlign="center"
    />
    <Text
      id="text10"
      value="**Billing Address**

{{ getAddresses.data.line1[getAddresses.data.address_id.indexOf(getEnquiries.data.billing_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}, {{ getAddresses.data.line2[getAddresses.data.address_id.indexOf(getEnquiries.data.billing_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}, {{ getAddresses.data.city[getAddresses.data.address_id.indexOf(getEnquiries.data.billing_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}, {{ getAddresses.data.state[getAddresses.data.address_id.indexOf(getEnquiries.data.billing_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}, {{ getAddresses.data.pincode[getAddresses.data.address_id.indexOf(getEnquiries.data.billing_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}"
      verticalAlign="center"
    />
    <Text id="text64" value="**Delivery Address**" verticalAlign="center" />
    <Text
      id="text11"
      disableMarkdown={true}
      value="{{ getAddresses.data.line1[getAddresses.data.address_id.indexOf(getEnquiries.data.delivery_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}, {{ getAddresses.data.line2[getAddresses.data.address_id.indexOf(getEnquiries.data.delivery_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}, {{ getAddresses.data.city[getAddresses.data.address_id.indexOf(getEnquiries.data.delivery_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}, {{ getAddresses.data.state[getAddresses.data.address_id.indexOf(getEnquiries.data.delivery_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}, {{ getAddresses.data.pincode[getAddresses.data.address_id.indexOf(getEnquiries.data.delivery_address_id[getEnquiries.data.enquiry_id.indexOf(selectedEnquiryId.value)])] }}"
      verticalAlign="center"
    />
  </View>
</Container>
