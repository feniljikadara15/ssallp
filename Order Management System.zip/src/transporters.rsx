<Screen
  id="transporters"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={4}
  _searchParams={[{ ordered: [{ key: "_embed" }, { value: "true" }] }]}
  browserTitle=""
  title="Transporters"
  urlSlug=""
  uuid="ef3490e7-fdaf-4c25-b71c-9aa24bd7f3bc"
>
  <State id="selectedTransporterId" />
  <SqlQueryUnified
    id="updateTransporterDetails"
    isHidden={false}
    query={include("../lib/updateTransporterDetails.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    tableName="transporters"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getTransporterVehicles"
    isHidden={false}
    query={include("../lib/getTransporterVehicles.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getTransporterWarehouses"
    isHidden={false}
    query={include("../lib/getTransporterWarehouses.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  >
    <Event
      id="4b498282"
      event="success"
      method="trigger"
      params={{ ordered: [] }}
      pluginId="getWarehousesForTransporter"
      type="datasource"
      waitMs="0"
      waitType="debounce"
    />
  </SqlQueryUnified>
  <JavascriptQuery
    id="updateTransporterWarehouses"
    isHidden={false}
    notificationDuration={4.5}
    query={include("../lib/updateTransporterWarehouses.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <SqlQueryUnified
    id="addTransporterVehicle"
    isHidden={false}
    isMultiplayerEdited={false}
    query={include("../lib/addTransporterVehicle.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="getWarehousesForTransporter"
    isHidden={false}
    isMultiplayerEdited={false}
    query={include("../lib/getWarehousesForTransporter.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="addTransporterWarehouse"
    isHidden={false}
    query={include("../lib/addTransporterWarehouse.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="deleteTransporterWarehouse"
    isHidden={false}
    query={include("../lib/deleteTransporterWarehouse.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="deleteTransporterVehicle"
    isHidden={false}
    query={include("../lib/deleteTransporterVehicle.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="addNewTransporter"
    isHidden={false}
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/addNewTransporter.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="deleteAllVehiclesForTransporter"
    query={include("../lib/deleteAllVehiclesForTransporter.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="deleteAllWarehousesTransporter"
    notificationDuration={4.5}
    query={include("../lib/deleteAllWarehousesTransporter.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="deleteTransporter"
    notificationDuration={4.5}
    query={include("../lib/deleteTransporter.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <Include src="./addTransporterModal.rsx" />
  <Frame
    id="$main5"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <Container
      id="container23"
      footerPadding="4px 12px"
      headerPadding="12px 12px"
      hoistFetching={true}
      padding="12px"
      showBody={true}
      showHeader={true}
      showHeaderBorder={false}
    >
      <Header>
        <Text
          id="containerTitle21"
          value="### Transporters"
          verticalAlign="center"
        />
        <Button
          id="newTransporterButton"
          iconBefore="bold/interface-add-circle-alternate"
          text="New"
        >
          <Event
            id="0b314fdb"
            event="click"
            method="run"
            params={{ ordered: [{ src: "await addTransporterModal.show();" }] }}
            pluginId=""
            type="script"
            waitMs="0"
            waitType="debounce"
          />
        </Button>
        <TextInput
          id="transporterSerachInput"
          iconBefore="bold/interface-search"
          label=""
          labelPosition="top"
          placeholder="search transporter"
          showClear={true}
          tooltipText="serach with transporter name"
        >
          <Event
            id="7df977f1"
            event="change"
            method="setValue"
            params={{ map: { value: "{{ self.value }}" } }}
            pluginId="transporterSerachVariable"
            type="state"
            waitMs="0"
            waitType="debounce"
          />
        </TextInput>
      </Header>
      <View id="d03e6" viewKey="View 1">
        <ListViewBeta
          id="transportersListView"
          _primaryKeys="{{ item.transporter_id }}"
          data="{{ getTransporters.data }}"
          heightType="auto"
          itemWidth="200px"
          margin="0"
          numColumns={3}
          padding="0"
        >
          <Container
            id="container24"
            footerPadding="4px 12px"
            headerPadding="4px 12px"
            padding="12px"
            showBody={true}
            style={{
              ordered: [
                {
                  border:
                    "{{ item.transporter_id == selectedTransporterId.value?theme.primary:theme.surfacePrimaryBorder }}",
                },
                {
                  background:
                    "{{ item.transporter_id == selectedTransporterId.value?theme.tertiary:theme.surfacePrimary }}",
                },
              ],
            }}
          >
            <Header>
              <Text
                id="containerTitle22"
                value="#### {{ item }}"
                verticalAlign="center"
              />
            </Header>
            <View id="e6c9f" viewKey="View 1">
              <IconText
                id="iconText8"
                icon="line/shipping-transfer-truck"
                style={{ ordered: [] }}
                text="{{ item.name }}"
              />
            </View>
            <Event
              id="65e06186"
              event="click"
              method="run"
              params={{
                ordered: [
                  {
                    src: "await selectedTransporterId.setValue(item.transporter_id);",
                  },
                ],
              }}
              pluginId=""
              type="script"
              waitMs="0"
              waitType="debounce"
            />
          </Container>
        </ListViewBeta>
      </View>
    </Container>
    <Include src="./manageTransporterContainer.rsx" />
    <Container
      id="skeletonImageTransporter"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      hidden="{{ selectedTransporterId.value != null }}"
      margin="0"
      padding="0"
      showBody={true}
      showBorder={false}
      style={{ ordered: [{ background: "rgba(255, 255, 255, 0)" }] }}
    >
      <View id="9adee" viewKey="View 1">
        <Image
          id="image3"
          heightType="fixed"
          horizontalAlign="center"
          retoolStorageFileId="b98ba2aa-e879-4e27-ae7d-83ebc600eb47"
          src="https://picsum.photos/id/1025/800/600"
          srcType="retoolStorageFileId"
        />
        <Text
          id="text42"
          horizontalAlign="center"
          value="###### Select a transporter to view details"
          verticalAlign="center"
        />
      </View>
    </Container>
  </Frame>
</Screen>
