<Screen
  id="Dashboard"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={10}
  _searchParams={[]}
  browserTitle=""
  title={null}
  urlSlug=""
  uuid="1414c5aa-48d9-4d17-b7e8-42d316355f44"
>
  <Folder id="dashboardOrders">
    <SqlQueryUnified
      id="getTotalOrders"
      query={include("../lib/getTotalOrders.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="chartOrders"
      notificationDuration={4.5}
      query={include("../lib/chartOrders.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
  </Folder>
  <Folder id="dashboardEnquiries">
    <SqlQueryUnified
      id="getTotalEnquiries"
      notificationDuration={4.5}
      query={include("../lib/getTotalEnquiries.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
  </Folder>
  <Folder id="dashboardCustomers">
    <SqlQueryUnified
      id="getTotalCustomers"
      notificationDuration={4.5}
      query={include("../lib/getTotalCustomers.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
  </Folder>
  <SqlQueryUnified
    id="getDashboardStats"
    query={include("../lib/getDashboardStats.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <Frame
    id="$main11"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <Text
      id="customersPageHeading3"
      value="### Dashboard"
      verticalAlign="center"
    />
    <Divider id="divider16" />
    <Text
      id="text74"
      value="  👋 **Hello {{ current_user.firstName || 'friend' }}!** Welcome to your Dashboard."
      verticalAlign="center"
    />
    <Container
      id="totalOrdersStaticContainer"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      hoistFetching={true}
      padding="12px"
      showBody={true}
      showHeader={true}
      style={{ map: { borderRadius: "2px" } }}
    >
      <Header>
        <Text
          id="containerTitle34"
          style={{ map: { color: "primary" } }}
          value="##### Orders"
          verticalAlign="center"
        />
        <Icon
          id="icon4"
          horizontalAlign="right"
          icon="bold/shopping-cart-1-alternate"
          style={{ map: { color: "primary" } }}
        />
      </Header>
      <View id="c52d7" viewKey="View 1">
        <Statistic
          id="deliverNoteStatistic"
          currency="USD"
          label="Total Orders"
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryDecimalPlaces=""
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue="{{ getDashboardStats.data.orders_pct[0] / 100 }}"
          showSeparators={true}
          value="{{ getDashboardStats.data.total_orders }}"
        />
      </View>
    </Container>
    <Container
      id="totalOrdersStaticContainer2"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      hoistFetching={true}
      padding="12px"
      showBody={true}
      showHeader={true}
      style={{ map: { borderRadius: "2px" } }}
    >
      <Header>
        <Text
          id="containerTitle35"
          style={{ map: { color: "primary" } }}
          value="##### Enquiries"
          verticalAlign="center"
        />
        <Icon
          id="icon5"
          horizontalAlign="right"
          icon="bold/mail-chat-bubble-oval-question-alternate"
          style={{ map: { color: "primary" } }}
        />
      </Header>
      <View id="c52d7" viewKey="View 1">
        <Statistic
          id="deliverNoteStatistic2"
          currency="USD"
          label="Total Enquiries"
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue="{{ getDashboardStats.data.enquiries_pct[0] / 100 }}"
          showSeparators={true}
          value="{{ getDashboardStats.data.total_enquiries }}"
        />
      </View>
    </Container>
    <Container
      id="totalOrdersStaticContainer3"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      hoistFetching={true}
      padding="12px"
      showBody={true}
      showHeader={true}
      style={{ map: { borderRadius: "2px" } }}
    >
      <Header>
        <Text
          id="containerTitle36"
          style={{ map: { color: "primary" } }}
          value="##### Customers"
          verticalAlign="center"
        />
        <Icon
          id="icon6"
          horizontalAlign="right"
          icon="bold/interface-user-multiple"
          style={{ map: { color: "primary" } }}
        />
      </Header>
      <View id="c52d7" viewKey="View 1">
        <Statistic
          id="deliverNoteStatistic3"
          currency="USD"
          label="Total Customers"
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue="{{ getDashboardStats.data.customers_pct[0] / 100 }}"
          showSeparators={true}
          value="{{ getDashboardStats.data.total_customers }}"
        />
      </View>
    </Container>
    <Chart
      id="lineChart2"
      barMode="group"
      barOrientation=""
      chartType="line"
      legendPosition="none"
      selectedPoints="[]"
      stackedBarTotalsDataLabelPosition="none"
      style={{ titleTextColor: "primary" }}
      title="Orders (Last 12 Months)"
      xAxisLineWidth={1}
      xAxisRangeMax=""
      xAxisRangeMin=""
      xAxisShowLine={true}
      xAxisShowTickLabels={true}
      xAxisTickFormatMode="gui"
      xAxisTitleStandoff={20}
      yAxis2LineWidth={1}
      yAxis2RangeMax=""
      yAxis2RangeMin=""
      yAxis2ShowTickLabels={true}
      yAxis2TickFormatMode="gui"
      yAxis2TitleStandoff={20}
      yAxisGrid={true}
      yAxisLineWidth={1}
      yAxisRangeMax=""
      yAxisRangeMin=""
      yAxisShowTickLabels={true}
      yAxisTickFormatMode="gui"
      yAxisTitleStandoff={20}
    >
      <Series
        id="0"
        aggregationType="sum"
        colorArray={{ array: [null] }}
        colorArrayDropDown={{ array: [null] }}
        colorInputMode="colorArrayDropDown"
        connectorLineColor="#000000"
        dataLabelPosition="none"
        datasource="{{ chartOrders.data }}"
        datasourceMode="source"
        decreasingBorderColor="{{ theme.danger }}"
        decreasingColor="{{ theme.danger }}"
        filteredGroups={null}
        filteredGroupsMode="source"
        gradientColorArray={{
          array: [
            { array: ["0.0", "{{ theme.success }}"] },
            { array: ["1.0", "{{ theme.primary }}"] },
          ],
        }}
        groupBy={{ array: [] }}
        groupByDropdownType="source"
        groupByStyles={{}}
        hoverTemplate="<b>%{x}</b><br>%{fullData.name}: %{y}<extra></extra>"
        hoverTemplateMode="source"
        increasingBorderColor="{{ theme.success }}"
        increasingColor="{{ theme.success }}"
        lineColor="{{ theme.primary }}"
        lineDash="solid"
        lineShape="spline"
        lineUnderFillMode="gradient"
        lineWidth={2}
        markerBorderColor={null}
        markerBorderWidth={0}
        markerColor="{{ theme.primary }}"
        markerSize={6}
        markerSymbol="circle"
        name="Orders"
        showMarkers={false}
        textTemplate={null}
        textTemplateMode="manual"
        type="line"
        waterfallBase={0}
        waterfallMeasures={null}
        waterfallMeasuresMode="source"
        xData="{{ chartOrders.data.month_start }}"
        xDataMode="source"
        yAxis="y"
        yData="{{ chartOrders.data.order_count }}"
        yDataMode="source"
        zData={null}
        zDataMode="manual"
      />
    </Chart>
  </Frame>
</Screen>
