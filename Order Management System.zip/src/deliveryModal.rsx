<ModalFrame
  id="deliveryModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showFooterBorder={false}
  showHeader={true}
  showHeaderBorder={false}
  showOverlay={true}
>
  <Header>
    <Text
      id="modalTitle11"
      value="### Mark as delivered"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton11"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ ordered: [{ border: "transparent" }] }}
      styleVariant="outline"
    >
      <Event
        id="549b4b70"
        event="click"
        method="setHidden"
        params={{ ordered: [{ hidden: true }] }}
        pluginId="deliveryModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="deliveryOtpInput"
      label="Delivery OTP"
      labelPosition="top"
      placeholder="Enter delivery OTP"
    />
  </Body>
  <Footer>
    <Button
      id="verifyOtpButton"
      style={{ ordered: [{ background: "success" }] }}
      text="Verify OTP"
    >
      <Event
        id="023adc36"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: 'if (deliveryOtpInput.value == getOrders.data.otp[getOrders.data.order_id.indexOf(selectedOrderId.value)]) {\n  await markAsDelivered.trigger();\n  await getOrders.trigger();\n  await deliveryOtpInput.clearValue();\n  await deliveryModal.hide();\n}\nelse {\n  utils.showNotification({title: "Incorrect OTP", notificationType: "warning"});\n  await deliveryOtpInput.clearValue();\n}',
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
