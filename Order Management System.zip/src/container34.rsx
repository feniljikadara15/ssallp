<Container
  id="container34"
  footerPadding="4px 12px"
  headerPadding="12px 12px"
  padding="12px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
  style={{ ordered: [] }}
>
  <Header>
    <Text
      id="containerTitle30"
      value="#### Order Information"
      verticalAlign="center"
    />
  </Header>
  <View id="472d8" viewKey="View 1">
    <Text
      id="text55"
      value="**Name**
{{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedCashBillId.value)])] }}"
      verticalAlign="center"
    />
    <Text
      id="text56"
      value="**Phone**
{{ getCustomers.data.phone[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedCashBillId.value)])] }}"
      verticalAlign="center"
    />
    <Divider id="divider24" />
    <Text
      id="text84"
      value="**Site**
{{ getSites.data.site_name[getSites.data.site_id.indexOf(getCashBillsPending.data.site_id[getCashBillsPending.data.order_id.indexOf(selectedCashBillId.value)])] }}"
      verticalAlign="center"
    />
    <Text id="text86" value="**Delivery Address**" verticalAlign="center" />
    <Text id="text87" value="**Billing Address**" verticalAlign="center" />
    <Text
      id="text85"
      disableMarkdown={true}
      value="{{ getAddresses.data.line1[getAddresses.data.address_id.indexOf(getCashBillsPending.data.shipping_address_id[getCashBillsPending.data.order_id.indexOf(selectedCashBillId.value)])] }}, {{ getAddresses.data.line2[getAddresses.data.address_id.indexOf(getCashBillsPending.data.shipping_address_id[getCashBillsPending.data.order_id.indexOf(selectedCashBillId.value)])] }}, {{ getAddresses.data.city[getAddresses.data.address_id.indexOf(getCashBillsPending.data.shipping_address_id[getCashBillsPending.data.order_id.indexOf(selectedCashBillId.value)])] }}, {{ getAddresses.data.state[getAddresses.data.address_id.indexOf(getCashBillsPending.data.shipping_address_id[getCashBillsPending.data.order_id.indexOf(selectedCashBillId.value)])] }}, {{ getAddresses.data.pincode[getAddresses.data.address_id.indexOf(getCashBillsPending.data.shipping_address_id[getCashBillsPending.data.order_id.indexOf(selectedCashBillId.value)])] }}
"
      verticalAlign="center"
    />
    <Text
      id="text88"
      disableMarkdown={true}
      value="{{ getAddresses.data.line1[getAddresses.data.address_id.indexOf(getCashBillsPending.data.billing_address_id[getCashBillsPending.data.order_id.indexOf(selectedCashBillId.value)])] }}, {{ getAddresses.data.line2[getAddresses.data.address_id.indexOf(getCashBillsPending.data.billing_address_id[getCashBillsPending.data.order_id.indexOf(selectedCashBillId.value)])] }}, {{ getAddresses.data.city[getAddresses.data.address_id.indexOf(getCashBillsPending.data.billing_address_id[getCashBillsPending.data.order_id.indexOf(selectedCashBillId.value)])] }}, {{ getAddresses.data.state[getAddresses.data.address_id.indexOf(getCashBillsPending.data.billing_address_id[getCashBillsPending.data.order_id.indexOf(selectedCashBillId.value)])] }}, {{ getAddresses.data.pincode[getAddresses.data.address_id.indexOf(getCashBillsPending.data.billing_address_id[getCashBillsPending.data.order_id.indexOf(selectedCashBillId.value)])] }}"
      verticalAlign="center"
    />
  </View>
</Container>
