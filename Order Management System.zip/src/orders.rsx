<Screen
  id="orders"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={2}
  _searchParams={[{ ordered: [{ key: "_embed" }, { value: "true" }] }]}
  browserTitle=""
  title="Orders"
  urlSlug="orders"
  uuid="440ad513-ff9d-4417-bb6a-86006cff23ad"
>
  <Folder id="saveOrderDetailsTerms">
    <SqlQueryUnified
      id="updateOrderParameters"
      isMultiplayerEdited={false}
      query={include("../lib/updateOrderParameters.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      successMessage="Order Details Saved Successfully"
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updateWarehouse2"
      isHidden={false}
      query={include("../lib/updateWarehouse2.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updateTransporter2"
      isHidden={false}
      query={include("../lib/updateTransporter2.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updateVehicleNumber"
      isHidden={false}
      query={include("../lib/updateVehicleNumber.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updateDeliveryTerms"
      isHidden={false}
      query={include("../lib/updateDeliveryTerms.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updatePoNumber"
      isHidden={false}
      query={include("../lib/updatePoNumber.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updateSubDealer"
      isHidden={false}
      query={include("../lib/updateSubDealer.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      warningCodes={[]}
    />
  </Folder>
  <Folder id="addNewVehicle2">
    <JavascriptQuery
      id="checkVNforTransporter"
      isMultiplayerEdited={false}
      notificationDuration={4.5}
      query={include("../lib/checkVNforTransporter.js", "string")}
      resourceName="JavascriptQuery"
      showSuccessToaster={false}
    />
    <SqlQueryUnified
      id="addVehicleNumberToTransporter2"
      notificationDuration={4.5}
      query={include("../lib/addVehicleNumberToTransporter2.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
  </Folder>
  <Folder id="cancelLoadingSlips">
    <SqlQueryUnified
      id="cancelLoadingSlip"
      isMultiplayerEdited={false}
      query={include("../lib/cancelLoadingSlip.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      successMessage="Loading Slip {{ cancelLoadingSlip.data.loading_slip_item_id[0] }} Cancelled"
      warningCodes={[]}
    />
    <RESTQuery
      id="cancelLoadingSlipNotification"
      body={
        '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "Cancel Loading Slip",\n  "destination": {{(String(loadingSlipItemsTable.selectedSourceRow.warehouse_keeper_phone).replace("+", ""))}},\n  "userName": {{ String(loadingSlipItemsTable.selectedSourceRow.warehouse_keeper_name)}},\n  "templateParams": [\n    {{ String(loadingSlipItemsTable.selectedSourceRow.warehouse_keeper_name)}},\n    {{ String(loadingSlipItemsTable.selectedSourceRow.loading_slip_file_name)}}\n  ],\n  "source": "retool app",\n  "media": {},\n  "buttons": [],\n  "carouselCards": [],\n  "location": {},\n  "attributes": {},\n  "paramsFallbackValue": {\n    "FirstName": {{ String(loadingSlipItemsTable.selectedSourceRow.warehouse_keeper_name)}}\n  }\n}'
      }
      bodyType="raw"
      headers={'[{"key":"Content-type","value":"application/json"}]'}
      isHidden={false}
      isMultiplayerEdited={false}
      notificationDuration="2"
      resourceDisplayName="WhatsApp API Calls via AiSensy"
      resourceName="8bf4c560-d928-418e-96e1-17235877d9f4"
      runWhenModelUpdates={false}
      showFailureToaster={false}
      successMessage="Loading Slip {{ loadingSlipItemsTable.selectedSourceRow.loading_slip_file_name }} Cancellation Message Sent Successfully"
      type="POST"
    />
  </Folder>
  <Folder id="manageInvoices">
    <WorkflowRun
      id="triggerInvoicingWorkflow"
      isHidden={false}
      isMultiplayerEdited={false}
      queryFailureConditions={
        '[{"condition":"","message":"{{ \\"Invoice Generation Failed\\" }}"}]'
      }
      resourceName="WorkflowRun"
      showFailureToaster={false}
      successMessage="{{ triggerInvoicingWorkflow.data.message }}"
      workflowId="92945d75-94b7-4335-b953-e6dd1607b9c9"
      workflowParams={include("../lib/triggerInvoicingWorkflow.json", "string")}
    />
  </Folder>
  <Folder id="manageLoadingSlips">
    <WorkflowRun
      id="triggerLoadingSlipWorkflow"
      isHidden={false}
      resourceName="WorkflowRun"
      showSuccessToaster={false}
      workflowId="6cfa5dc8-3dc9-4111-bb57-c2ec3abd6300"
      workflowParams={include(
        "../lib/triggerLoadingSlipWorkflow.json",
        "string"
      )}
    />
    <SqlQueryUnified
      id="getLoadingSlips"
      isHidden={false}
      notificationDuration={4.5}
      query={include("../lib/getLoadingSlips.sql", "string")}
      queryDisabled="{{ selectedOrderId.value == null }}"
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="getLoadingSlipItems"
      isHidden={false}
      isMultiplayerEdited={false}
      notificationDuration={4.5}
      query={include("../lib/getLoadingSlipItems.sql", "string")}
      queryDisabled="{{ selectedOrderId.value == null }}"
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="getLoadingSlipItemsString"
      notificationDuration={4.5}
      query={include("../lib/getLoadingSlipItemsString.sql", "string")}
      queryDisabled="{{ selectedOrderId.value == null }}"
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="updateLoadingSlipStatus"
      _additionalScope={["row"]}
      isMultiplayerEdited={false}
      query={include("../lib/updateLoadingSlipStatus.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      successMessage="Loading Slip {{ cancelLoadingSlip.data.loading_slip_item_id[0] }} Sent"
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="query19"
      query={include("../lib/query19.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      warningCodes={[]}
    />
  </Folder>
  <Folder id="addNewVehicle">
    <State id="storeVehicleNumber" value="" />
    <SqlQueryUnified
      id="addVehicleNumberToTransporter"
      notificationDuration={4.5}
      query={include("../lib/addVehicleNumberToTransporter.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <State id="newVehicleID" />
  </Folder>
  <Folder id="exportOrders">
    <SqlQueryUnified
      id="ongoingOrderDetailsForExport"
      isMultiplayerEdited={false}
      notificationDuration={4.5}
      query={include("../lib/ongoingOrderDetailsForExport.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="transitOrderDetailsForExport"
      isMultiplayerEdited={false}
      notificationDuration={4.5}
      query={include("../lib/transitOrderDetailsForExport.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
    <SqlQueryUnified
      id="deliveredOrderDetailsForExport"
      notificationDuration={4.5}
      query={include("../lib/deliveredOrderDetailsForExport.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      showUpdateSetValueDynamicallyToggle={false}
      updateSetValueDynamically={true}
      warningCodes={[]}
    />
  </Folder>
  <Folder id="downloadEinvoiceSendMsg">
    <RESTQuery
      id="downloadInvoice"
      notificationDuration={4.5}
      query="invoices/pdf?organization_id=60031284196&invoice_ids={{ getInvoices.data.zb_invoice_id[getInvoices.data.order_id.indexOf(selectedOrderId.value)] }}

"
      resourceDisplayName="ZB v3"
      resourceName="c5058a3e-b80a-4586-a22f-88cbcba8ab5f"
      resourceTypeOverride=""
      runWhenModelUpdates={false}
      showSuccessToaster={false}
    />
    <RetoolStorageQuery
      id="storeInvoice"
      actionType="upload"
      data="{{ downloadInvoice.data.base64Data }}"
      fileName="{{  getInvoices.data.zb_invoice_id[getInvoices.data.order_id.indexOf(selectedOrderId.value)]  + '.pdf'}}"
      isPublic={true}
      resourceDisplayName="retool_storage"
      resourceName="retool_storage"
      runWhenModelUpdates={false}
      shouldOverwriteOnNameCollision={true}
      uploadBy="programmatic"
    />
    <SqlQueryUnified
      id="updatePDFUrl"
      enableTransformer={true}
      query={include("../lib/updatePDFUrl.sql", "string")}
      resourceDisplayName="retool_db"
      resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
      runWhenModelUpdates={false}
      warningCodes={[]}
    />
    <RESTQuery
      id="sendDeliveryOTP"
      body={
        '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "deliver_otp_new",\n  "destination": {{String(getCustomers.data.phone[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "").replace("+", "")}},\n  "userName": {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] }},\n  "templateParams": [\n    \n    {{ getOrders.data.otp[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}\n  ],\n  "source": "ssallp-retool",\n  "media": {},\n  "buttons": [\n    {\n      "type": "button",\n      "sub_type": "URL",\n      "index": 0,\n      "parameters": [\n        {\n          "type": "text",\n          "text":  {{ getOrders.data.otp[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}\n        }\n      ]\n    }\n  ],\n  "carouselCards": [],\n  "location": {},\n  "attributes": {},\n  "paramsFallbackValue": {\n    "FirstName": "Customer"\n  }\n}'
      }
      bodyType="raw"
      headers={'[{"key":"Content-type","value":"application/json"}]'}
      isHidden={false}
      isMultiplayerEdited={false}
      resourceDisplayName="WhatsApp API Calls via AiSensy"
      resourceName="8bf4c560-d928-418e-96e1-17235877d9f4"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      type="POST"
    />
    <RESTQuery
      id="notifyCustomer3"
      body={
        '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "new_invoice_pdf",\n  "destination": {{ String(getCustomers.data.phone[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "").replace("+", "") }} ,\n  "userName": {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "Customer" }},\n  "templateParams": [\n    {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "Customer" }},\n    {{ String(getInvoices.data.zb_invoice_id[getInvoices.data.invoice_id.indexOf(getOrders.data.invoice_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "") }},\n    {{ getOrderItemsString.data.output_string[0] || "" }},\n    {{ String(getEnquiries.data.delivery_date[getEnquiries.data.enquiry_id.indexOf(getOrders.data.enquiry_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "").split(\'-\').reverse().join(\'-\') }},\n    {{ selectTransporter2.selectedLabel || "" }},\n    {{ getTransporters.data.phone_number[getTransporters.data.transporter_id.indexOf(selectTransporter2.value)] || "" }},\n    {{ selectVehicleNumber.selectedLabel || "" }}\n  ],\n  "source": "ssallp-retool",\n  "media": {\n    "url": "{{ storeInvoice.data.url || "" }}",\n    "filename": "invoice pdf"\n  },\n  "buttons": [],\n  "carouselCards": [],\n  "location": {},\n  "attributes": {},\n  "paramsFallbackValue": {\n    "FirstName": "user"\n  }\n}'
      }
      bodyType="raw"
      headers={'[{"key":"Content-type","value":"application/json"}]'}
      isHidden={false}
      isMultiplayerEdited={false}
      resourceDisplayName="WhatsApp API Calls via AiSensy"
      resourceName="8bf4c560-d928-418e-96e1-17235877d9f4"
      runWhenModelUpdates={false}
      showSuccessToaster={false}
      type="POST"
    />
  </Folder>
  <SqlQueryUnified
    id="getInvoices"
    isHidden={false}
    isMultiplayerEdited={false}
    query={include("../lib/getInvoices.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <State id="selectedOrderId" />
  <SqlQueryUnified
    id="getOrderItems"
    isHidden={false}
    notificationDuration={4.5}
    query={include("../lib/getOrderItems.sql", "string")}
    queryDisabled="{{ selectedOrderId.value == null }}"
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="orderItemsTableSaveHandler"
    actionType="BULK_UPDATE_BY_KEY"
    bulkUpdatePrimaryKey="order_item_id"
    editorMode="gui"
    isHidden={false}
    notificationDuration={4.5}
    records="{{ orderItemsTable.changesetArray }}"
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    tableName="order_items"
  />
  <SqlQueryUnified
    id="getVehicleNumber"
    isHidden={false}
    query={include("../lib/getVehicleNumber.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="generateCashBill"
    isHidden={false}
    isMultiplayerEdited={false}
    query={include("../lib/generateCashBill.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    warningCodes={[]}
  />
  <JavascriptQuery
    id="getTotalAmount"
    isHidden={false}
    notificationDuration={4.5}
    query={include("../lib/getTotalAmount.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <SqlQueryUnified
    id="deleteOrder"
    isHidden={false}
    query={include("../lib/deleteOrder.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="restoreOrder"
    isHidden={false}
    query={include("../lib/restoreOrder.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <RESTQuery
    id="notifyCustomer"
    body={
      '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "[LIVE] Customer Order & OTP Details Notification",\n  "destination": {{ String(getCustomers.data.phone[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "").replace("+", "") }},\n  "userName": {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "Customer" }},\n  "templateParams": [\n    {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "Customer" }},\n    {{ String(getInvoices.data.zb_invoice_number[getInvoices.data.invoice_id.indexOf(getOrders.data.invoice_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "") }},\n    {{ getOrderItemsString.data.output_string[0] || "" }},\n    {{ String(getEnquiries.data.delivery_date[getEnquiries.data.enquiry_id.indexOf(getOrders.data.enquiry_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "").split(\'-\').reverse().join(\'-\') }},\n    {{ selectTransporter2.selectedLabel || "" }},\n    {{ getTransporters.data.phone_number[getTransporters.data.transporter_id.indexOf(getOrders.data.transporter_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "" }},\n    {{ selectVehicleNumber.selectedLabel || "" }},\n    {{ getOrders.data.otp[getOrders.data.order_id.indexOf(selectedOrderId.value)] || "" }}\n  ],\n  "source": "retool app",\n  "media": {},\n  "buttons": [\n    {\n      "type": "button",\n      "sub_type": "URL",\n      "index": 0,\n      "parameters": [\n        {\n          "type": "text",\n          "text": {{ (() => { const invoiceUrl = getInvoices.data.zb_invoice_url[getInvoices.data.invoice_id.indexOf(getOrders.data.invoice_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])]; if (!invoiceUrl) return null; try { const cInvoiceId = new URL(invoiceUrl).searchParams.get(\'CInvoiceID\'); return cInvoiceId?.startsWith(\'2-\') ? cInvoiceId : null; } catch (e) { return null; } })() }}\n        }\n      ]\n    }\n  ],\n  "carouselCards": [],\n  "location": {},\n  "paramsFallbackValue": {\n    "FirstName": "Customer"\n  }\n}'
    }
    bodyType="raw"
    headers={'[{"key":"Content-type","value":"application/json"}]'}
    isHidden={false}
    isMultiplayerEdited={false}
    resourceDisplayName="WhatsApp API Calls via AiSensy"
    resourceName="8bf4c560-d928-418e-96e1-17235877d9f4"
    runWhenModelUpdates={false}
    successMessage={
      'Message Sent to {{(String(getCustomers.data.phone[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])])).replace("+", "")}} '
    }
    type="POST"
  />
  <SqlQueryUnified
    id="getOrderItemsString"
    isHidden={false}
    query={include("../lib/getOrderItemsString.sql", "string")}
    queryDisabled="{{ selectedOrderId.value == null }}"
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="createOtp"
    isHidden={false}
    isMultiplayerEdited={false}
    query={include("../lib/createOtp.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    warningCodes={[]}
  />
  <State id="variable7" />
  <JavascriptQuery
    id="queryTesting"
    isHidden={false}
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/queryTesting.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <RESTQuery
    id="notifyTransporter"
    body={
      '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "[Live] Order Pickup Transporter Notification",\n  "destination": {{ String(getTransporters.data.phone_number[getTransporters.data.transporter_id.indexOf(selectTransporter2.value)] || "").replace("+", "") }},\n  "userName": {{ selectTransporter2.selectedLabel || "Transporter" }},\n  "templateParams": [\n    {{ selectTransporter2.selectedLabel || "Transporter" }},\n    {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "" }},\n    {{ getSites.data.site_person_contact[getSites.data.site_id.indexOf(getEnquiries.data.site_id[getEnquiries.data.enquiry_id.indexOf(getOrders.data.enquiry_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])])] || "" }},\n    {{ [getAddresses.data.line1[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])], getAddresses.data.line2[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])], getAddresses.data.city[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])], getAddresses.data.state[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])], getAddresses.data.pincode[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])]].map(v => v || "Not available").join(", ") }},\n    {{ getOrderItemsString.data.output_string[0] || "" }},\n    {{ selectWarehouse2.selectedLabel || "" }},\n    {{ String(getEnquiries.data.delivery_date[getEnquiries.data.enquiry_id.indexOf(getOrders.data.enquiry_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "").split(\'-\').reverse().join(\'-\') }}\n  ],\n  "source": "retool app",\n  "media": {},\n  "buttons": [],\n  "carouselCards": [],\n  "location": {},\n  "paramsFallbackValue": {\n    "FirstName": "Transporter"\n  }\n}'
    }
    bodyType="raw"
    headers={'[{"key":"Content-type","value":"application/json"}]'}
    isHidden={false}
    isMultiplayerEdited={false}
    notificationDuration="2"
    resourceDisplayName="WhatsApp API Calls via AiSensy"
    resourceName="8bf4c560-d928-418e-96e1-17235877d9f4"
    runWhenModelUpdates={false}
    successMessage="Order details sent to transporter"
    type="POST"
  />
  <SqlQueryUnified
    id="markAsDelivered"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/markAsDelivered.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showUpdateSetValueDynamicallyToggle={false}
    successMessage="Order marked as delivered"
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <RESTQuery
    id="sendInvoiceToTransporter"
    body={
      '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "[Live] Transporter Invoice Notification",\n  "destination": {{ String((selectTransporter2.data || []).find(t => t.transporter_id === selectTransporter2.value)?.transporter_phone || "").replace("+", "") }},\n  "userName": {{ selectTransporter2.selectedLabel }},\n  "templateParams": [\n    {{ selectTransporter2.selectedLabel }},\n    {{ String(getInvoices.data.zb_invoice_number[getInvoices.data.invoice_id.indexOf(getOrders.data.invoice_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "") }},\n    {{ getOrderItemsString.data.output_string[0] || "" }},\n    {{ String(getEnquiries.data.delivery_date[getEnquiries.data.enquiry_id.indexOf(getOrders.data.enquiry_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "").split(\'-\').reverse().join(\'-\') }},\n    {{ [getAddresses.data.line1[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])], getAddresses.data.line2[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])], getAddresses.data.city[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])], getAddresses.data.state[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])], getAddresses.data.pincode[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])]].map(v => v || "Not available").join(", ") }},\n    {{ getAddresses.data.maps_link[getAddresses.data.address_id.indexOf(getOrders.data.shipping_address_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "Not available" }},\n    {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "" }},\n    {{ selectVehicleNumber.selectedLabel }}\n  ],\n  "source": "retool",\n  "media": {},\n  "buttons": [\n    {\n      "type": "button",\n      "sub_type": "URL",\n      "index": 0,\n      "parameters": [\n        {\n          "type": "text",\n          "text": {{ (() => { const invoiceUrl = getInvoices.data.zb_invoice_url[getInvoices.data.invoice_id.indexOf(getOrders.data.invoice_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])]; if (!invoiceUrl) return null; try { const cInvoiceId = new URL(invoiceUrl).searchParams.get(\'CInvoiceID\'); return cInvoiceId?.startsWith(\'2-\') ? cInvoiceId : null; } catch (e) { return null; } })() }}\n        }\n      ]\n    }\n  ],\n  "carouselCards": [],\n  "location": {},\n  "paramsFallbackValue": {\n    "FirstName": "Transporter"\n  }\n}'
    }
    bodyType="raw"
    headers={'[{"key":"Content-type","value":"application/json"}]'}
    isHidden={false}
    isMultiplayerEdited={false}
    resourceDisplayName="WhatsApp API Calls via AiSensy"
    resourceName="8bf4c560-d928-418e-96e1-17235877d9f4"
    runWhenModelUpdates={false}
    successMessage={
      'Message Sent to {{(selectTransporter2.data.find(t => t.transporter_id === selectTransporter2.value)?.transporter_phone).replace("+", "")}} '
    }
    type="POST"
  />
  <SqlQueryUnified
    id="getWarehouseKeepersLs"
    notificationDuration={4.5}
    query={include("../lib/getWarehouseKeepersLs.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
    warningCodes={[]}
  />
  <RESTQuery
    id="sendLoadingSlipToWarehouseKeeper"
    _additionalScope={["row"]}
    body={
      '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "[Live] Loading Slip Warehouse Keeper Notification",\n  "destination": {{ String(row?.warehouse_keeper_phone || "").replace("+", "") }},\n  "userName": {{ row?.warehouse_keeper_name || "Warehouse Keeper" }},\n  "templateParams": [\n    {{ row?.warehouse_keeper_name || "Warehouse Keeper" }},\n    {{ getLoadingSlipItemsString.data.output_string[0] || "" }}\n  ],\n  "source": "retool-app",\n  "media": {\n    "url": {{ row?.url || "" }},\n    "filename": {{ row?.loading_slip_file_name || "loading-slip" }}\n  },\n  "buttons": [],\n  "carouselCards": [],\n  "location": {},\n  "paramsFallbackValue": {\n    "FirstName": {{ row?.warehouse_keeper_name || "Warehouse Keeper" }}\n  }\n}'
    }
    bodyType="raw"
    headers={
      '[{"key":"Content-Type","value":"application/json"},{"key":"","value":""},{"key":"","value":""}]'
    }
    isMultiplayerEdited={false}
    resourceDisplayName="WhatsApp messages via AiSensy"
    resourceName="d5648d82-cd36-4241-9939-115d30d1a9da"
    resourceTypeOverride=""
    runWhenModelUpdates={false}
    successMessage="Loading Slip {{ loadingSlipItemsTable.selectedSourceRow.loading_slip_file_name }} sent to Warehouse Keeper Successfully"
    type="POST"
  />
  <SqlQueryUnified
    id="query2"
    notificationDuration={4.5}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    showUpdateSetValueDynamicallyToggle={false}
    updateSetValueDynamically={true}
  />
  <SqlQueryUnified
    id="getTransportersWarehouseOrder"
    query={include("../lib/getTransportersWarehouseOrder.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="3f50c449-ad35-4d45-a424-5f3b05567a5a"
    warningCodes={[]}
  />
  <RESTQuery
    id="notifyCustomer2"
    body={
      '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "[LIVE] Customer Order & OTP Details Notification",\n  "destination": "918147646289",\n  "userName": {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "Customer" }},\n  "templateParams": [\n    {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "Customer" }},\n    {{ String(getInvoices.data.zb_invoice_id[getInvoices.data.invoice_id.indexOf(getOrders.data.invoice_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "") }},\n    {{ getOrderItemsString.data.output_string[0] || "" }},\n    {{ String(getEnquiries.data.delivery_date[getEnquiries.data.enquiry_id.indexOf(getOrders.data.enquiry_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "").split(\'-\').reverse().join(\'-\') }},\n    {{ selectTransporter2.selectedLabel || "" }},\n    {{ getTransporters.data.phone_number[getTransporters.data.transporter_id.indexOf(selectTransporter2.value)] || "" }},\n    {{ selectVehicleNumber.selectedLabel || "" }},\n    {{ getOrders.data.otp[getOrders.data.order_id.indexOf(selectedOrderId.value)] || "" }}\n  ],\n  "source": "ssallp-retool",\n  "media": {},\n  "buttons": [\n    {\n      "type": "button",\n      "sub_type": "URL",\n      "index": 0,\n      "parameters": [\n        {\n          "type": "text",\n          "text": "2-1dc1eb824f437d5644407d6209820e68f195cfa231e282157d0e533f26f8be862d350dd29e4293b917f3300796bbc6f36642160c57d7582c039eb509f335221bbf747bf136c83d3b"\n        }\n      ]\n    }\n  ],\n  "carouselCards": [],\n  "location": {},\n  "attributes": {},\n  "paramsFallbackValue": {\n    "FirstName": "user"\n  }\n}'
    }
    bodyType="raw"
    headers={'[{"key":"Content-type","value":"application/json"}]'}
    isHidden={false}
    isMultiplayerEdited={false}
    resourceDisplayName="WhatsApp API Calls via AiSensy"
    resourceName="8bf4c560-d928-418e-96e1-17235877d9f4"
    runWhenModelUpdates={false}
    showSuccessToaster={false}
    type="POST"
  />
  <JavascriptQuery
    id="query5"
    notificationDuration={4.5}
    query={include("../lib/query5.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <JavascriptQuery
    id="query6"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/query6.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <JavascriptQuery
    id="query9"
    notificationDuration={4.5}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <JavascriptQuery
    id="query10"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/query10.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <JavascriptQuery
    id="query15"
    notificationDuration={4.5}
    query={include("../lib/query15.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <JavascriptQuery
    id="transporterNumForMsg"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/transporterNumForMsg.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <JavascriptQuery
    id="addNewVehicleNumberOld"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/addNewVehicleNumberOld.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <JavascriptQuery
    id="query16"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/query16.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <RESTQuery
    id="notifyCustomerTest"
    body={
      '{\n  "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWQ5ZDZiMDUyN2ZhMTA3MzRhODk0NSIsIm5hbWUiOiJTUkkgU0FNQkFWQU5BVEggQUdFTkNJRVMgTExQIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2ZWQ5ZDZhMDUyN2ZhMTA3MzRhODkzZSIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzI2ODQ4MzYzfQ.sKb-0uAja3mXpg80n73bQIymyENn_4-QQg7ZMdJzzZE",\n  "campaignName": "[LIVE] Customer Order & OTP Details Notification",\n  "destination": "919901571683",\n  "userName": {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "Customer" }},\n  "templateParams": [\n    {{ getCustomers.data.name[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "Customer" }},\n    {{ String(getInvoices.data.zb_invoice_number[getInvoices.data.invoice_id.indexOf(getOrders.data.invoice_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "") }},\n    {{ getOrderItemsString.data.output_string[0] || "" }},\n    {{ String(getEnquiries.data.delivery_date[getEnquiries.data.enquiry_id.indexOf(getOrders.data.enquiry_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "").split(\'-\').reverse().join(\'-\') }},\n    {{ selectTransporter2.selectedLabel || "" }},\n    {{ getTransporters.data.phone_number[getTransporters.data.transporter_id.indexOf(getOrders.data.transporter_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])] || "" }},\n    {{ selectVehicleNumber.selectedLabel || "" }},\n    {{ getOrders.data.otp[getOrders.data.order_id.indexOf(selectedOrderId.value)] || "" }}\n  ],\n  "source": "retool app",\n  "media": {},\n  "buttons": [\n    {\n      "type": "button",\n      "sub_type": "URL",\n      "index": 0,\n      "parameters": [\n        {\n          "type": "text",\n          "text": {{ (() => { const invoiceUrl = getInvoices.data.zb_invoice_url[getInvoices.data.invoice_id.indexOf(getOrders.data.invoice_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])]; if (!invoiceUrl) return null; try { const cInvoiceId = new URL(invoiceUrl).searchParams.get(\'CInvoiceID\'); return cInvoiceId?.startsWith(\'2-\') ? cInvoiceId : null; } catch (e) { return null; } })() }}\n        }\n      ]\n    }\n  ],\n  "carouselCards": [],\n  "location": {},\n  "paramsFallbackValue": {\n    "FirstName": "Customer"\n  }\n}'
    }
    bodyType="raw"
    headers={'[{"key":"Content-type","value":"application/json"}]'}
    isHidden={false}
    isMultiplayerEdited={false}
    resourceDisplayName="WhatsApp API Calls via AiSensy"
    resourceName="8bf4c560-d928-418e-96e1-17235877d9f4"
    runWhenModelUpdates={false}
    successMessage={
      'Message Sent to {{(String(getCustomers.data.phone[getCustomers.data.customer_id.indexOf(getOrders.data.customer_id[getOrders.data.order_id.indexOf(selectedOrderId.value)])])).replace("+", "")}} '
    }
    type="POST"
  />
  <JavascriptQuery
    id="query18"
    isMultiplayerEdited={false}
    notificationDuration={4.5}
    query={include("../lib/query18.js", "string")}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <JavascriptQuery
    id="query21"
    notificationDuration={4.5}
    resourceName="JavascriptQuery"
    showSuccessToaster={false}
  />
  <Include src="./addNewVehicleModal.rsx" />
  <Include src="./confirmCancelLSModal.rsx" />
  <Include src="./confirmEditTransportDetailsModal.rsx" />
  <Include src="./convertCashBillModal.rsx" />
  <Include src="./deliveryModal.rsx" />
  <Include src="./editTransportDetailsModal.rsx" />
  <Include src="./manageLoadingSlipsModal.rsx" />
  <Include src="./modalFrame3.rsx" />
  <Frame
    id="$main2"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <Include src="./tabbedContainer2.rsx" />
    <Include src="./container14.rsx" />
    <Container
      id="skeletonImageOrders"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      hidden="{{ selectedOrderId.value != null }}"
      margin="0"
      padding="0"
      showBody={true}
      showBorder={false}
      style={{ ordered: [{ background: "rgba(255, 255, 255, 0)" }] }}
    >
      <View id="9adee" viewKey="View 1">
        <Image
          id="image4"
          heightType="fixed"
          horizontalAlign="center"
          retoolStorageFileId="b98ba2aa-e879-4e27-ae7d-83ebc600eb47"
          src="https://picsum.photos/id/1025/800/600"
          srcType="retoolStorageFileId"
        />
        <Text
          id="text43"
          horizontalAlign="center"
          value="###### Select an order to view details"
          verticalAlign="center"
        />
      </View>
    </Container>
  </Frame>
</Screen>
