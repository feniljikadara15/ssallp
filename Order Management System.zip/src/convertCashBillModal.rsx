<ModalFrame
  id="convertCashBillModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="modalTitle43"
      value="### Container title"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton44"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="9e15c70d"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="convertCashBillModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Icon
      id="icon8"
      horizontalAlign="center"
      icon="bold/interface-alert-warning-triangle"
      style={{ map: { color: "highlight" } }}
    />
    <Text
      id="text80"
      horizontalAlign="center"
      value="##### Are you sure you want to convert Order {{ selectedOrderId.value }} to a Cash Bill?"
      verticalAlign="center"
    />
    <Button
      id="confirmCashBillButton"
      style={{ map: { background: "highlight" } }}
      text="Confirm"
    >
      <Event
        id="2da20144"
        event="click"
        method="run"
        params={{
          map: {
            src: "await cashBillingSwitch.setValue(true);\nawait convertCashBillModal.setHidden();",
          },
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="button12"
      style={{ border: "rgba(219, 8, 8, 1)", label: "rgba(175, 8, 8, 1)" }}
      styleVariant="outline"
      text="Cancel"
    >
      <Event
        id="01eb69ec"
        event="click"
        method="hide"
        params={{}}
        pluginId="convertCashBillModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Body>
</ModalFrame>
