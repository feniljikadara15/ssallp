<ModalFrame
  id="addTransporterModal"
  footerPadding="8px 12px"
  headerPadding="12px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showHeaderBorder={false}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text id="modalTitle6" value="### New Transporter" verticalAlign="center" />
    <Button
      id="modalCloseButton6"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ ordered: [{ border: "transparent" }] }}
      styleVariant="outline"
    >
      <Event
        id="5604efbb"
        event="click"
        method="setHidden"
        params={{ ordered: [{ hidden: true }] }}
        pluginId="addTransporterModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <TextInput
      id="newTransporterNameInput"
      label="Name"
      labelPosition="top"
      placeholder="Enter transporter name"
    />
    <PhoneNumberInput
      id="newTransporterPhoneInput"
      _lockSelectedCountry={true}
      label="Phone Number"
      labelPosition="top"
      lockedCountryCode="IN"
    />
    <PhoneNumberInput
      id="newTransporterAdditionalPhoneInput"
      _lockSelectedCountry={true}
      label="Additional Phone Number"
      labelPosition="top"
      lockedCountryCode="IN"
      value="{{ getTransporters.data.phone_number[getTransporters.data.transporter_id.indexOf(selectedTransporterId.value)] }}"
    />
  </Body>
  <Footer>
    <Button
      id="addNewTransporterButton"
      disabled="{{ addNewTransporter.isFetching }}"
      loaderPosition="left"
      loading="{{ addNewTransporter.isFetching }}"
      text="Save"
    >
      <Event
        id="c261b0b7"
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: "await addNewTransporterButton.setDisabled();\nawait addNewTransporter.trigger();\nawait getTransporters.trigger();\nawait selectedTransporterId.setValue(addNewTransporter.data.transporter_id[0]);\nawait newTransporterNameInput.clearValue();\nawait newTransporterPhoneInput.clearValue();\nawait newTransporterAdditionalPhoneInput.clearValue(); \nawait addTransporterModal.setHidden();\nawait addNewTransporterButton.setDisabled(false);",
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
