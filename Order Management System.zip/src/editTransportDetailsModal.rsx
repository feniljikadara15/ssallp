<ModalFrame
  id="editTransportDetailsModal"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="medium"
>
  <Header>
    <Text
      id="modalTitle42"
      value="#### Edit Transport Details for Order - {{ selectedOrderId.value }} "
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton43"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ map: { border: "transparent" } }}
      styleVariant="outline"
    >
      <Event
        id="da49805a"
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="editTransportDetailsModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Select
      id="selectWarehouse3"
      data="{{ getWarehouses.data }}"
      disabled="{{ updateWarehouse2.isFetching || updateTransporter2.isFetching || updatePoNumber.isFetching || updateSubDealer.isFetching || getOrders.isFetching }}"
      emptyMessage="No options"
      iconBefore="bold/shipping-warehouse"
      label="Warehouse"
      labelPosition="top"
      labels="{{ item.name }}"
      overlayMaxHeight={375}
      placeholder="Select a warehouse"
      readOnly=""
      required={true}
      showSelectionIndicator={true}
      value="{{ getOrders.data.warehouse_id[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}"
      values="{{ item.warehouse_id }}"
    />
    <Select
      id="selectTransporter3"
      captionByIndex=""
      data="{{ getTransportersWarehouseOrder.data }}"
      disabled="{{ updateWarehouse2.isFetching || updateTransporter2.isFetching || updatePoNumber.isFetching || updateSubDealer.isFetching || getOrders.isFetching || selectWarehouse2.value == null }}"
      emptyMessage="No options"
      hidden=""
      iconBefore="bold/shipping-transfer-truck"
      label="Transporter"
      labelPosition="top"
      labels="{{ item.transporter_name }}"
      overlayMaxHeight={375}
      placeholder="Select an option"
      readOnly=""
      required={true}
      showSelectionIndicator={true}
      value="{{ getOrders.data.transporter_id[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}"
      values="{{ item.transporter_id }}"
    />
    <Select
      id="selectDeliveryTerms2"
      emptyMessage="No options"
      itemMode="static"
      label="Delivery Terms"
      labelPosition="top"
      overlayMaxHeight={375}
      placeholder="Select an option"
      required={true}
      showSelectionIndicator={true}
      value="{{ getOrders.data.delivery_terms[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}"
    >
      <Option id="00030" value="Delivery" />
      <Option id="00031" value="Ex warehouse" />
    </Select>
    <Select
      id="selectVehicleNumber2"
      allowCustomValue={true}
      data="{{ getVehicleNumber.data }}"
      disabled="{{ updateWarehouse2.isFetching || updateTransporter2.isFetching || updatePoNumber.isFetching || updateSubDealer.isFetching || getOrders.isFetching }}"
      emptyMessage="No options"
      label="Vehicle Number"
      labelPosition="top"
      labels="{{ item.vehicle_number }}"
      overlayMaxHeight={375}
      placeholder="Select a vehicle"
      readOnly=""
      required={true}
      showClear={true}
      showSelectionIndicator={true}
      value="{{ getOrders.data.vehicle_id[getOrders.data.order_id.indexOf(selectedOrderId.value)] }}"
      values="{{ item.vehicle_id }}"
    >
      <Event
        id="8df57504"
        event="inputValueChange"
        method="setValue"
        params={{ map: { value: "{{ selectVehicleNumber2.inputValue }}" } }}
        pluginId="storeVehicleNumber"
        type="state"
        waitMs="0"
        waitType="debounce"
      />
    </Select>
  </Body>
  <Footer>
    <Button id="saveEditTransportDetailsConfirmationButton" text="Save">
      <Event
        id="82fd25e0"
        event="click"
        method="show"
        params={{}}
        pluginId="confirmEditTransportDetailsModal"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</ModalFrame>
